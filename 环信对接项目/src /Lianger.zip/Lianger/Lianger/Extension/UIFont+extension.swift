//
//  UIFont+extension.swift
//  Lianger
//
//  Created by Qidi on 2023/7/10.
//

import UIKit

extension UIFont {
    
    /// 平方常规
    static func PingFangSC(size: CGFloat) -> UIFont{
        return  UIFont(name: "PingFangSC-Regular", size: size) ?? UIFont.systemFont(ofSize: size)
    }
    
    /// 平方中粗
    static func PingFangSCMedium(size: CGFloat) -> UIFont{
        return  UIFont(name: "PingFangSC-Medium", size: size) ?? UIFont.systemFont(ofSize: size, weight: .medium)
    }
    
    /// PingFangSC-Bold
    static func PingFangSCBold(size: CGFloat) -> UIFont{
        return  UIFont(name: "PingFangSC-Bold", size: size) ?? UIFont.systemFont(ofSize: size, weight: .bold)
    }
    
    /// PingFangSC-Semibold
    static func PingFangSCSemibold(size: CGFloat) -> UIFont {
        return  UIFont(name: "PingFangSC-Semibold", size: size) ?? UIFont.systemFont(ofSize: size, weight: .semibold)
    }
    
    /// PingFangSC-Light
    static func PingFangSCLight(size: CGFloat) -> UIFont {
        return  UIFont(name: "PingFangSC-Light", size: size) ?? UIFont.systemFont(ofSize: size, weight: .light)
    }
}
