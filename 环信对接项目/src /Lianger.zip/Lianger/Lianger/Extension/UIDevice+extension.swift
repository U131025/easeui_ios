//
//  UIDevice+extension.swift
//  Lianger
//
//  Created by Qidi on 2023/7/6.
//

import UIKit


let ScreenWidth = UIScreen.main.bounds.size.width
let ScreenHeight = UIScreen.main.bounds.size.height

func kScaleWidth(_ width: CGFloat) -> CGFloat {
    return (width)*ScreenWidth/375.0
}

func kScaleHeight(_ height: CGFloat) -> CGFloat {
    return (ScreenHeight == 812.0 ? (height)*ScreenWidth/375.0 : (ScreenHeight==896 ? (736/667.0)*(height) : (height)*(ScreenHeight/667.0)))
}


extension UIDevice {
    /// 是否全面屏系列
    public static func xzy_isFullSrceen() -> Bool {
        if #available(iOS 11, *) {
            let window = UIApplication.shared.keyWindow
            if let safeInsetTop = window?.safeAreaInsets.top {
                return safeInsetTop > 20.0
            }
            return false
        }
        return false
    }
    
    /// 判断是否5、5s、SE
    public static func xzy_isIphone5_5s_SE() -> Bool {
        return UIScreen.main.bounds.width == 320
    }
    
    /// 获取设备 id
    public static func getDeviceId() -> String {
        if let deviceId = UserDefaults.standard.value(forKey: "DeviceId") {
            return deviceId as! String
        } else {
            let deviceId = NSUUID.init().uuidString
            UserDefaults.standard.setValue(deviceId, forKey: "DeviceId")
            return deviceId
        }
    }
}
extension UIDevice {
    
    /// 顶部安全区高度
    static func xp_safeDistanceTop() -> CGFloat {
        if #available(iOS 13.0, *) {
            let scene = UIApplication.shared.connectedScenes.first
            guard let windowScene = scene as? UIWindowScene else { return 0 }
            guard let window = windowScene.windows.first else { return 0 }
            return window.safeAreaInsets.top
        } else if #available(iOS 11.0, *) {
            guard let window = UIApplication.shared.windows.first else { return 0 }
            return window.safeAreaInsets.top
        }
        return 0;
    }
    
    /// 底部安全区高度
    static func xp_safeDistanceBottom() -> CGFloat {
        if #available(iOS 13.0, *) {
            let scene = UIApplication.shared.connectedScenes.first
            guard let windowScene = scene as? UIWindowScene else { return 0 }
            guard let window = windowScene.windows.first else { return 0 }
            return window.safeAreaInsets.bottom
        } else if #available(iOS 11.0, *) {
            guard let window = UIApplication.shared.windows.first else { return 0 }
            return window.safeAreaInsets.bottom
        }
        return 0;
    }
    
    /// 顶部状态栏高度（包括安全区）
    static func xp_statusBarHeight() -> CGFloat {
        var statusBarHeight: CGFloat = 0
        if #available(iOS 13.0, *) {
            let scene = UIApplication.shared.connectedScenes.first
            guard let windowScene = scene as? UIWindowScene else { return 0 }
            guard let statusBarManager = windowScene.statusBarManager else { return 0 }
            statusBarHeight = statusBarManager.statusBarFrame.height
        } else {
            statusBarHeight = UIApplication.shared.statusBarFrame.height
        }
        return statusBarHeight
    }
    
    /// 导航栏高度
    static func xp_navigationBarHeight() -> CGFloat {
        return 44
    }
    
    /// 状态栏+导航栏的高度
    static func xp_navigationFullHeight() -> CGFloat {
        return UIDevice.xp_statusBarHeight() + UIDevice.xp_navigationBarHeight()
    }
    
    /// 底部导航栏高度
    static func xp_tabBarHeight() -> CGFloat {
        return 49
    }
    
    /// 底部导航栏高度（包括安全区）
    static func xp_tabBarFullHeight() -> CGFloat {
        return UIDevice.xp_tabBarHeight() + UIDevice.xp_safeDistanceBottom()
    }
    
    //是刘海屏系列
    static func isIphoneXSerial() -> Bool {
        return xp_safeDistanceTop() > 0
    }
}

extension UIDevice {
    static func getLocalVersion() -> String {
        var localVersion:String = ""
        //当前版本
        if let v:String = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String{
            localVersion = v
        }
        return localVersion
    }
    
    //app 名字
    static func getAppDisplayName() -> String {
        if let infoDic = Bundle.main.infoDictionary {
            let appDisplayName = infoDic["CFBundleDisplayName"]
            return appDisplayName as! String
        }else{
            return ""
        }
      
    }
    
    static func deviceId() -> String {
        if let diviceId = UIDevice.current.identifierForVendor?.uuidString {
            return diviceId
        }
        return ""
            
    }
}
