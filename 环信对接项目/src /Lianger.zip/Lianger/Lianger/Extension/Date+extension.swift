//
//  Date+extension.swift
//  Lianger
//
//  Created by Cheng on 2023/7/6.
//

import UIKit

extension Date {
    
    /// 日期格式化
    /// - Parameters:
    ///   - format: 格式字符
    /// - Returns: 日期字符串
    func dateToFormatString(format: String? = "yyyy-MM-dd HH:mm:ss") -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        return formatter.string(from: self)
    }
    //MARK: -时间转时间戳函数
    func timeToTimeStamp(time: String ,_ inputFormatter:String? = "yyyy-MM-dd HH:mm:ss") -> Double {
        let dfmatter = DateFormatter()
        //设定时间格式,这里可以设置成自己需要的格式
        dfmatter.dateFormat = inputFormatter
        let last = dfmatter.date(from: time)
        let timeStamp = last?.timeIntervalSince1970
        return timeStamp!
    }
    
    
    /// Date类型转化为日期字符串
    ///
    /// - Parameters:
    ///   - date: Date类型
    ///   - dateFormat: 格式化样式默认“yyyy-MM-dd”
    /// - Returns: 日期字符串
    
    static func dateConvertString(date:Date, dateFormat:String = "yyyy-MM-dd HH:mm:ss") -> String {
        
        let dateFormatter = DateFormatter()

        dateFormatter.dateFormat = dateFormat

        return dateFormatter.string(from: date)
    }
    
    
    /// 日期字符串转化为Date类型
    ///
    /// - Parameters:
    ///   - string: 日期字符串
    ///   - dateFormat: 格式化样式，默认为“yyyy-MM-dd HH:mm:ss”
    /// - Returns: Date类型
    static func stringConvertDate(string:String, dateFormat:String="yyyy-MM-dd HH:mm:ss") -> Date? {
        let dateFormatter = DateFormatter.init()
        dateFormatter.dateFormat = dateFormat
        let date = dateFormatter.date(from: string)
        return date
    }
    
    
    //时间戳转成字符串
    static func timeIntervalChangeToTimeStr(timeInterval:Double, _ dateFormat:String? = "yyyy-MM-dd HH:mm:ss") -> String {
        let date:Date = Date.init(timeIntervalSince1970: timeInterval)
        let formatter = DateFormatter.init()
        if dateFormat == nil {
            formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        }else{
            formatter.dateFormat = dateFormat
        }
        return formatter.string(from: date as Date)
    }
    
    
    // MARK: 日期判断
    
    func isToday(tz: Int? = nil) -> Bool {
        return self.isSameDay(to: Date(), tz: tz)
    }
    
    
    func isSameDay(to compareDate: Date, tz: Int? = nil) -> Bool {
        let calendar = Date.calendar(with: tz)
        let cmps = calendar.dateComponents([.year, .month, .day], from: self)
        let compareCmps = calendar.dateComponents([.year, .month, .day], from: compareDate)
        return (cmps.year! == compareCmps.year!)
            && (cmps.month! == compareCmps.month!)
            && (cmps.day! == compareCmps.day!)
    }
    
    func isSameYear(to compareDate: Date, tz: Int? = nil) -> Bool {
        let calendar = Date.calendar(with: tz)
        let cmps = calendar.dateComponents([.year, .month, .day], from: self)
        let compareCmps = calendar.dateComponents([.year, .month, .day], from: compareDate)
        return cmps.year! == compareCmps.year!
        
    }
    
    static func calendar(with tz: Int? = nil) -> Calendar {
        var calendar = Calendar.current
        if tz != nil, let timeZone = TimeZone(secondsFromGMT: 3600 * tz!) {
            calendar.timeZone = timeZone
        }
        return calendar
    }
    
    static func messageDateConvertString(_ date: Date) -> String {
        if date.isToday() {
            return date.dateToFormatString(format: "HH:mm")
        } else if date.isSameYear(to: Date()) {
            return date.dateToFormatString(format: "MM-dd HH:mm")
        } else {
            return date.dateToFormatString(format: "yyyy-MM-dd")
        }
    }
    
}
