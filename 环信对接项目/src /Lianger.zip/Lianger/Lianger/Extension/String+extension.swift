//
//  String+extension.swift
//  Lianger
//
//  Created by Cheng on 2023/7/6.
//

import UIKit


extension String {
    
    
    func isAllSymbols() -> Bool {//特殊字符
        let symbolSet = CharacterSet.init(charactersIn: "@／ ,.?。，？：；（）¥「」＂、[]{}#%-*+=_\\|~＜＞<>$?^?'@#$%^&*()_+'\"")
        let curString = self.trimmingCharacters(in: symbolSet)
        if curString.count == 0 {
            return true
        } else {
            return false
        }
    }
    
    /// 获取输入子字符串在当前字符串的所有位置范围数组
    ///
    /// - Parameter subStr: 输入要查找的子字符串
    /// - Returns: 包含所有位置范围的数组
    func rangeOfSubString(_ subStr: String) -> Array<NSRange> {
        guard subStr.count > 0, self.contains(subStr) else {
            return []
        }
        var rangeArray = [NSRange]()
        var index: Int = 0
        var ocStr = NSString(string: self)
        while ocStr.contains(subStr) {
            let range = ocStr.range(of: subStr)
            rangeArray.append(NSMakeRange(index + range.location, subStr.count))
            index += NSMaxRange(range)
            ocStr = ocStr.substring(from: NSMaxRange(range)) as NSString
        }
        return rangeArray
    }
    
    func getWordCount() -> Int {
        do {
            //构造正则表达式
            let regular = try NSRegularExpression(pattern: "\\w+", options: .caseInsensitive)
            let matches = regular.matches(in: self, options: [], range: NSMakeRange(0, self.count))
            return matches.count
        } catch _ {
            return 0
        }
    }

}

/// 计算单行/多行文本高度
extension String {
    
    public func xzy_singleLineHeight(_ font: UIFont?) -> CGFloat {
        guard let font = font, count > 0 else { return 0 }
        return self.size(withAttributes: [.font: font]).height
    }
    
    public func xzy_multipleLineHeight(_ font: UIFont?, _ width: CGFloat) -> CGFloat {
        guard let font = font, count > 0 else { return 0 }
        return self.boundingRect(with: CGSize(width: width, height: .greatestFiniteMagnitude), options: .usesLineFragmentOrigin, attributes: [.font: font], context: nil).height
    }
    public func widthWith(font: UIFont) -> CGFloat {
        let str = self as NSString
        return str.size(withAttributes: [NSAttributedString.Key.font:font]).width
    }
}

extension String {
    func contains(find: String) -> Bool{
        return self.range(of: find) != nil
    }

    func containsIgnoringCase(find: String) -> Bool{
        return self.range(of: find, options: .caseInsensitive) != nil
    }
     
    public func getWidthWithFont(_ font: UIFont?) -> CGFloat {
        guard let font = font, count > 0 else { return 0 }
        return self.size(withAttributes: [.font : font]).width
    }
    public func getHeightWithAttributes(_ attributes: [NSAttributedString.Key : Any]? = nil, _ width: CGFloat) -> CGFloat {
        return self.boundingRect(with: CGSize(width: width, height: .greatestFiniteMagnitude), options: .usesLineFragmentOrigin, attributes: attributes, context: nil).size.height
    }
    
    var isBlank: Bool {
        let trimmedStr = self.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmedStr.isEmpty
    }
    
}


// MARK: - 字符串截取
extension String {
    /// String使用下标截取字符串
    /// string[index] 例如："abcdefg"[3] // c
    subscript (i:Int)->String{
        let startIndex = self.index(self.startIndex, offsetBy: i)
        let endIndex = self.index(startIndex, offsetBy: 1)
        return String(self[startIndex..<endIndex])
    }
    /// String使用下标截取字符串
    /// string[index..<index] 例如："abcdefg"[3..<4] // d
    subscript (r: Range<Int>) -> String {
        get {
            let startIndex = self.index(self.startIndex, offsetBy: r.lowerBound)
            let endIndex = self.index(self.startIndex, offsetBy: r.upperBound)
            return String(self[startIndex..<endIndex])
        }
    }
    /// String使用下标截取字符串
    /// string[index,length] 例如："abcdefg"[3,2] // de
    subscript (index:Int , length:Int) -> String {
        get {
            let startIndex = self.index(self.startIndex, offsetBy: index)
            let endIndex = self.index(startIndex, offsetBy: length)
            return String(self[startIndex..<endIndex])
        }
    }
    // 截取 从头到i位置
    func substring(to:Int) -> String{
        return self[0..<to]
    }
    // 截取 从i到尾部
    func substring(from:Int) -> String{
        return self[from..<self.count]
    }
    
}
