//
//  UIColor+extension.swift
//  Lianger
//
//  Created by Cheng on 2023/7/6.
//

import UIKit

extension UIColor {
    
    convenience init(r:UInt32 ,g:UInt32 , b:UInt32 , a:CGFloat = 1.0) {
        self.init(red: CGFloat(r) / 255.0,
                  green: CGFloat(g) / 255.0,
                  blue: CGFloat(b) / 255.0,
                  alpha: a)
    }
    func image() -> UIImage {
        let rect = CGRect(x: 0, y: 0, width: 1, height: 1)
        UIGraphicsBeginImageContext(rect.size)
        let context = UIGraphicsGetCurrentContext()
        context!.setFillColor(self.cgColor)
        context!.fill(rect)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
    convenience init(red: Int, green: Int, blue: Int, alpha: CGFloat = 1.0) {
        self.init(red: CGFloat(red)/255.0, green: CGFloat(green)/255.0, blue: CGFloat(blue)/255.0, alpha: alpha)
    }
    
    /// 根据值范围为0～255的红绿蓝以及透明度构建颜色
    /// UIColor.rgbColor(255, 0, 0)
    /// - Parameters:
    ///   - red: 0～255
    ///   - green: 0～255
    ///   - blue: 0～255
    ///   - alpha: 0～1.0
    /// - Returns: 根据值范围为0～255的红绿蓝以及透明度构建颜色值
    public static func rgbColor(_ red: Int, _ green: Int, _ blue: Int, _ alpha: CGFloat = 1.0) -> UIColor {
        return UIColor(red: CGFloat(red)/255.0, green: CGFloat(green)/255.0, blue: CGFloat(blue)/255.0, alpha: alpha)
    }
    
    /// 根据颜色的十六进制值即透明度构建颜色
    /// UIColor.hexColor(hex: 0xff0000)
    /// - Parameters:
    ///   - hex: 颜色的16进制表示
    ///   - alpha: 0～1.0，透明度
    /// - Returns: 根据颜色的十六进制值构建颜色
    public static func hexColor(hex: Int, alpha: CGFloat = 1.0) -> UIColor {
        let red = (hex >> 16) & 0xFF
        let green = (hex >> 8) & 0xFF
        let blue = hex & 0xFF
        
        return rgbColor(red, green, blue, alpha)
    }
    
    static var main: UIColor { return UIColor.hexColor(hex: 0xDCFF4A) }

    static var mainYellow: UIColor { return UIColor.hexColor(hex: 0xDCFF4A) }
    static var buttonYellow: UIColor { return UIColor.hexColor(hex: 0xA9CD00) }
    static var inputTintColor: UIColor { return UIColor.hexColor(hex: 0xC0EE00) }

    static var blackText: UIColor { return UIColor(r: 0, g: 0, b: 0) }
    static var placeholdColor: UIColor { return UIColor(r: 153, g: 153, b: 153) }
    static var redText: UIColor { return UIColor.hexColor(hex: 0xFF3333) }
    static var linkColor: UIColor { return UIColor.hexColor(hex: 0x569900) }

    static var grey99: UIColor { return UIColor.hexColor(hex: 0x999999) }
    static var grey97: UIColor { return UIColor.hexColor(hex: 0x979797) }
    static var grey98: UIColor { return UIColor.hexColor(hex: 0x989898) }
    static var greyC9: UIColor { return UIColor.hexColor(hex: 0xC9C9C9) }
    static var greyD0: UIColor { return UIColor.hexColor(hex: 0xD0D0D0) }
    static var greyD9: UIColor { return UIColor.hexColor(hex: 0xD9D9D9) }
    static var greyE6: UIColor { return UIColor.hexColor(hex: 0xE6E6E6) }
    static var greyF2: UIColor { return UIColor.hexColor(hex: 0xF2F2F2) }

    
}
