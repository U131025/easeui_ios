//
//  UserInfoModel.swift
//  Lianger
//
//  Created by Qidi on 2023/7/18.
//

import UIKit

class UserInfoModel: BaseModel {
    
    static let shared = UserInfoModel()
    
    var userId: String?
    var phone: String?
    var nickName: String?
    var zoneM: String?
    var avatar: String?
    var zoneL: String?
    var zoneS: String?
    var email: String?
    var introduction: String?
    var zoneSName: String?
    var zoneLName: String?
    var zoneMName: String?

    
    func sharedUserInfoModel(userInfoModel:UserInfoModel) {
        UserInfoModel.shared.userId = userInfoModel.userId
        UserInfoModel.shared.phone = userInfoModel.phone
        UserInfoModel.shared.nickName = userInfoModel.nickName
        UserInfoModel.shared.zoneM = userInfoModel.zoneM
        UserInfoModel.shared.avatar = userInfoModel.avatar
        UserInfoModel.shared.zoneL = userInfoModel.zoneL
        UserInfoModel.shared.zoneS = userInfoModel.zoneS
        UserInfoModel.shared.email = userInfoModel.email
        UserInfoModel.shared.introduction = userInfoModel.introduction
        UserInfoModel.shared.zoneSName = userInfoModel.zoneSName
        UserInfoModel.shared.zoneLName = userInfoModel.zoneLName
        UserInfoModel.shared.zoneMName = userInfoModel.zoneMName
    }

}
