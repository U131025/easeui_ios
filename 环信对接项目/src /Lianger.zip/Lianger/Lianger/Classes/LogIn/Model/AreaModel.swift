//
//  AreaModel.swift
//  Lianger
//
//  Created by Qidi on 2023/8/7.
//

import UIKit


class AreaInfo: NSObject {
    
    var areaList: [AreaModel] = []
    
}

class AreaModel: BaseModel {

    //
    var id: String?
    //
    var parentId: String?
    //
    var areaName: String = ""
    //
    var status: Int?
    //
    var children: [AreaModel] = []

    
}
