//
//  ProtocolWebView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/19.
//

import UIKit
import WebKit

class ProtocolWebView: UIView {

    var closeBlock: (() -> Void)?
    var acceptBlock: (() -> Void)?
    
    private lazy var wkWebView: WKWebView = {
        let wkWebView = WKWebView()
        wkWebView.isOpaque = false
        wkWebView.backgroundColor = .clear
        wkWebView.scrollView.delegate = self
        return wkWebView
    }()
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCBold(size: 19)
        return label
    }()
    
    lazy var closeBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_close"), for: .normal)
        button.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
        return button
    }()
    lazy var acceptBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Accept", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.setTitleColor(UIColor.grey97, for: .disabled)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 18)
        button.backgroundColor = UIColor.greyE6
        button.isEnabled = false
        button.showCorner(30)
        return button
    }()
    
    init(frame: CGRect,title: String,urlString: String) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.showCorner(35)
        self.creatUI()
        self.titleLabel.text = title
        guard let url = URL(string: urlString) else { return }
        let request = URLRequest(url: url)
        self.wkWebView.load(request)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    @objc private func closeAction() {
        
    }
    
    
    private func creatUI() {
        
        addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(35)
        }
        
        addSubview(closeBtn)
        closeBtn.snp.makeConstraints { make in
            make.top.right.equalToSuperview().inset(24)
        }
        addSubview(wkWebView)
        wkWebView.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(30)
            make.top.equalTo(titleLabel.snp.bottom).offset(30)
            make.bottom.equalToSuperview().offset(-50)
        }
        
        addSubview(acceptBtn)
        acceptBtn.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(25)
            make.height.equalTo(60)
            make.bottom.equalToSuperview().offset(-57)
        }
        
    }
    
    

}


extension ProtocolWebView: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        
        if offsetY + scrollView.height >= scrollView.contentSize.height {
            self.acceptBtn.isEnabled = true
            self.acceptBtn.backgroundColor = .black
        }
        
    }
}
