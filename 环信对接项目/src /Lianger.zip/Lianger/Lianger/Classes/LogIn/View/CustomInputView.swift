//
//  CustomInputView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/10.
//

import UIKit
import QMUIKit
import SnapKit

class CustomInputView: UIView {
    
    enum InputType: Int {
        case phone  //手机号
        case verCode  //获取验证码
        case password  // 密码
        case selete // 选择
        case normal // 只有输入

    }
    var seletedBlock: (() -> Void)?
    
    var textValue: String? {
        set {
            self.textFeild.text = newValue
        }
        get {
            return self.textFeild.text
        }
    }
    
    private var leftIcon: String?
    private var rightIcon: String?
    private var type: InputType = .normal
    
    
    private lazy var leftIconBtn: UIButton = {
        let button = UIButton(type: .custom)
        return button
    }()
    
    private lazy var chooseBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("+61", for: .normal)
        button.setTitleColor(UIColor.buttonYellow, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCMedium(size: 15)
        button.setImage(UIImage(named: "seleted_normal"), for: .normal)
        return button
    }()
    
    
    private lazy var textFeild: QMUITextField = {
        let textFeild = QMUITextField()
        textFeild.placeholderColor = UIColor.placeholdColor
        textFeild.textColor = UIColor.blackText
        textFeild.font = UIFont.PingFangSC(size: 14)
        textFeild.borderStyle = .none
        textFeild.tintColor = UIColor.inputTintColor
        textFeild.adjustsFontSizeToFitWidth = true
        textFeild.delegate = self
        return textFeild
    }()
    private lazy var lineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.greyC9
        return view
    }()
    private lazy var rightButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(buttonClick(button:)), for: .touchUpInside)
        return button
    }()
    lazy var timingButton: TimingButton = {
        let button = TimingButton.init(title: "Get verify code", times: 60)
        button.backgroundColor = UIColor.main
        button.titleLabel?.font = UIFont.PingFangSC(size: 13)
        button.showCorner(17)
        return button
    }()
    
    
    init(frame: CGRect,type: InputType,leftIcon: String?,placeholder: String?,maxLenght: UInt = UInt.max,keyboardType: UIKeyboardType = .default) {
        super.init(frame: frame)
        
        self.type = type
        self.leftIcon = leftIcon
        self.textFeild.maximumTextLength = maxLenght
        self.textFeild.placeholder = placeholder
        self.textFeild.keyboardType = keyboardType
        self.setUpSubViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    
    func setUpSubViews() {
        
        var tfLeft:CGFloat = 10.0
        var tfRight:CGFloat = 10.0
        
        if let iconName = self.leftIcon { //左边图标
            self.addSubview(leftIconBtn)
            leftIconBtn.setImage(UIImage(named: "\(iconName)_normal"), for: .normal)
            leftIconBtn.setImage(UIImage(named: "\(iconName)_seleted"), for: .selected)
            leftIconBtn.snp.makeConstraints { make in
                make.centerY.equalToSuperview()
                make.left.equalTo(10)
            }
            tfLeft = 40
        }
        
     if type == .verCode {
            tfRight = 138
            self.addSubview(timingButton)
            timingButton.snp.makeConstraints { make in
                make.centerY.equalToSuperview()
                make.width.equalTo(128)
                make.height.equalTo(34)
                make.right.equalToSuperview()
            }
        } else if type == .phone {
            self.addSubview(chooseBtn)
            chooseBtn.snp.makeConstraints { make in
                make.left.equalToSuperview().offset(tfLeft)
                make.centerY.equalToSuperview()
                make.width.equalTo(70)
                make.height.equalTo(30)
            }
            self.chooseBtn.layoutButtonWithEdgeInsetsStyle(style: .XZYButtonEdgeInsetsStyleRight, imageTitleSpace: 10)
            tfLeft += 70
        } else if type == .password {
            self.addSubview(rightButton)
            rightButton.setImage(UIImage(named: "eyes_close"), for: .normal)
            rightButton.setImage(UIImage(named: "eyes_open"), for: .selected)
            rightButton.snp.makeConstraints { make in
                make.centerY.equalToSuperview()
                make.right.equalToSuperview().offset(-18)
            }
            self.textFeild.isSecureTextEntry = true
            tfRight = 56
        } else if type == .selete {
            self.textFeild.isEnabled = false
            self.addSubview(rightButton)
            rightButton.setImage(UIImage(named: "seleted_normal"), for: .normal)
            rightButton.setImage(UIImage(named: "seleted_seleted"), for: .selected)
            rightButton.snp.makeConstraints { make in
                make.centerY.equalToSuperview()
                make.right.equalToSuperview().offset(-18)
            }
            tfRight = 56
            let tap = UITapGestureRecognizer(target: self, action: #selector(seletedAction))
            self.addGestureRecognizer(tap)
        }
        self.addSubview(textFeild)
        textFeild.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(tfLeft)
            make.right.equalToSuperview().offset(-tfRight)
            make.top.bottom.equalToSuperview()
        }
        self.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(1)
        }

    }
    
    
    
    @objc func buttonClick(button: UIButton) {
        if type == .password {
            button.isSelected = !button.isSelected
            self.textFeild.isSecureTextEntry = !button.isSelected
        }
        
        
    }
    @objc func seletedAction() {
        self.seletedBlock?()
    }
    
}


extension CustomInputView: QMUITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        self.lineView.backgroundColor = UIColor.blackText
        self.leftIconBtn.isSelected = true
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        self.lineView.backgroundColor = UIColor.greyC9
        self.leftIconBtn.isSelected = false

        return true
    }
    
}
