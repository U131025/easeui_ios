//
//  TimingButton.swift
//  Lianger
//
//  Created by Qidi on 2023/7/10.
//

import UIKit

class TimingButton: UIButton {

    private lazy var timer = ASCountDownTimer(interval: .seconds(1), times: times, handler: { [weak self] (tmr, left) in
        if left > 0 {
                self?.refreshCounting(leftTimes: left)
        } else {
            self?.reset()
        }
    })
    
    private let times: Int
    
    var isCounting:Bool = false
    required init(title: String, times: Int = 60 ) {
        
        self.times = times
        super.init(frame: .zero)
        setTitle(title, for: .normal)
        setTitleColor(UIColor.blackText, for: .normal)
        setTitleColor(UIColor.grey99, for: .disabled)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    @objc func startCountingDown() {
        
        if timer.leftTimes == 0 {
            timer.reCountDown()
        }
        
        timer.start()
        
        refreshCounting(leftTimes: times)
    }
    
    @objc  private func refreshCounting(leftTimes: Int) {
        isEnabled = false
        isCounting = true
        setTitle("\(leftTimes)s", for: .disabled)
        setTitleColor(UIColor.white, for: .disabled)
        self.alpha = 0.5
    }
    
   
    
    @objc private func reset() {
        isEnabled = true
        setTitle("Get verify code", for: .normal)
        isCounting = false
        setTitleColor(UIColor.blackText, for: .normal)
        self.alpha = 1
    }
    

}
