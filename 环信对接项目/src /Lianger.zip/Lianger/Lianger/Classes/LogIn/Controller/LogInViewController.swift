//
//  LogInViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/7.
//

import UIKit
import MCToast
import SwiftyUserDefaults
import HyphenateChat

class LogInViewController: BaseViewController {
    
    lazy var bgImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "login_bg"))
        return imageView
    }()
    
    lazy var logoImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "app_logo"))
        return imageView
    }()
    
    lazy var phoneView: CustomInputView = {
        let inputView = CustomInputView(frame: .zero,type: .phone, leftIcon: nil, placeholder: "Mobile Phone Number",keyboardType: .numberPad)
        
        return inputView
    }()
    lazy var passwordView: CustomInputView = {
        let inputView = CustomInputView(frame: .zero,type: .verCode, leftIcon: nil, placeholder: "Verification code",keyboardType: .numberPad)
        inputView.timingButton.addTarget(self, action: #selector(clickGetMsgCodeBtn), for: .touchUpInside)
        return inputView
    }()

    
    lazy var loginBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Login in", for: .normal)
        button.setTitleColor(UIColor.blackText, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCMedium(size: 18)
        button.backgroundColor = UIColor.main
        button.showCorner(30)
        button.addTarget(self, action: #selector(loginAction), for: .touchUpInside)

        return button
    }()
    lazy var registerBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Register", for: .normal)
        button.setTitleColor(UIColor.blackText, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCMedium(size: 18)
        button.backgroundColor = UIColor.clear
        button.showCorner(30, borderWidth: 1, borderColor: UIColor.blackText)
        button.addTarget(self, action: #selector(registerAction), for: .touchUpInside)
        return button
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        self.creartUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBar.isHidden = false
    }
    
    
    // MARK:  Action
    
    @objc func clickGetMsgCodeBtn() {
        guard let mobile = phoneView.textValue,mobile.isBlank == false else {
            MCToast.mc_text("Please enter Phone Number")
            return
        }
        ApiManager.sendVerCode(phonenumber: mobile) { success, errorMsg in
            if success {
                MCToast.mc_text("Verification code sent successfully")
            } else {
                if let msg = errorMsg {
                    MCToast.mc_text(msg)
                }
            }
        }
    }
    
    @objc func registerAction() {
        let vc = RegisterViewController()
        
        self.navigationController?.pushViewController(vc, animated: true)
        
        #if DEBUG
        guard let mobile = phoneView.textValue,mobile.isBlank == false else {
            return
        }
        #endif
    }
    
    @objc private func loginAction() {
        
        guard let mobile = phoneView.textValue,mobile.isBlank == false else {
            MCToast.mc_text("Please enter Phone Number")
            return
        }
        guard let msgCode = passwordView.textValue,msgCode.isBlank == false else {
            MCToast.mc_text("Please enter Verification code")
            return
        }
        ApiManager.login(mobile: mobile, msgCode: msgCode) { sucess,error  in
            if sucess {
                var app:AppDelegate!
                app = (UIApplication.shared.delegate as! AppDelegate)
                let animation:()->() = {
                    app.window?.rootViewController =  BaseTabBarController()
                }
                UIView.transition(with: app.window! , duration: TimeInterval(0.5) , options: UIView.AnimationOptions.transitionFlipFromLeft  , animations: animation, completion: nil)
//                ApiManager.ImLogin { success, errorMsg in
//                    if sucess {
//                    }
//                }
                
                EaseIMHelper.shared.login()
                
            } else {
                MCToast.mc_text(error ?? "Verification code error!")
            }
        }
    }
    
    
    // MARK:  ui
    
    func creartUI() {
        
        self.view.addSubview(bgImageView)
        bgImageView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        self.view.addSubview(logoImageView)
        logoImageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(UIDevice.xp_safeDistanceTop() + 56)
        }
        
        self.view.addSubview(phoneView)
        phoneView.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(55)
            make.height.equalTo(56)
            make.top.equalTo(logoImageView.snp.bottom).offset(65)
        }
        
        self.view.addSubview(passwordView)
        passwordView.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(55)
            make.height.equalTo(56)
            make.top.equalTo(phoneView.snp.bottom).offset(20)
        }
        
        self.view.addSubview(loginBtn)
        loginBtn.snp.makeConstraints { make in
            make.height.equalTo(60)
            make.left.right.equalToSuperview().inset(25)
            make.top.equalTo(passwordView.snp.bottom).offset(80)
        }
        self.view.addSubview(registerBtn)
        registerBtn.snp.makeConstraints { make in
            make.height.equalTo(60)
            make.left.right.equalToSuperview().inset(25)
            make.top.equalTo(loginBtn.snp.bottom).offset(20)
        }
        
    }

   
}
