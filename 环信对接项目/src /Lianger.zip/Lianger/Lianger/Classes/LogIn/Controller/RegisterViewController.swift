//
//  RegisterViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/13.
//

import UIKit
import TYAlertController
import MCToast

class RegisterViewController: BaseViewController {

    private var areaList: [AreaModel] = []
    private var isAgreeRegistration: Bool = false
    private var isAgreePrivacy: Bool = false
    private var zoneL: String?
    private var zoneM: String?
    private var zoneS: String?

    lazy var lineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.greyE6
        return view
    }()
    lazy var accountView: CustomInputView = {
        let inputView = CustomInputView(frame: .zero,type: .phone, leftIcon: "phone", placeholder: "Mobile Phone Number",maxLenght: 11,keyboardType: .numberPad)
        return inputView
    }()
    lazy var verCodeView: CustomInputView = {
        let inputView = CustomInputView(frame: .zero,type: .verCode, leftIcon: "vercode", placeholder: "Verification code",maxLenght: 6,keyboardType: .numberPad)
        inputView.timingButton.addTarget(self, action: #selector(clickGetMsgCodeBtn), for: .touchUpInside)
        return inputView
    }()

    lazy var addressView: CustomInputView = {
        let inputView = CustomInputView(frame: .zero,type: .selete, leftIcon: "address", placeholder: "Suburb")
        inputView.seletedBlock = { [weak self] in
            self?.chooseAddress()
        }
        return inputView
    }()
    
    lazy var agreementBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_nocheck"), for: .normal)
        button.setImage(UIImage(named: "icon_check"), for: .selected)
        button.tag = 10
        button.addTarget(self, action: #selector(chooseButtonActio(button:)), for: .touchUpInside)
        return button
    }()
    
    lazy var agreementContentBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Registration Agreement", for: .normal)
        button.setTitleColor(UIColor.hexColor(hex: 0xA9CD00), for: .normal)
        button.titleLabel?.font = UIFont.PingFangSC(size: 14)
        button.tag = 11
        button.addTarget(self, action: #selector(chooseButtonActio(button:)), for: .touchUpInside)
        return button
    }()
    
    lazy var policytBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_nocheck"), for: .normal)
        button.setImage(UIImage(named: "icon_check"), for: .selected)
        button.tag = 12
        button.addTarget(self, action: #selector(chooseButtonActio(button:)), for: .touchUpInside)
        return button
    }()
    
    lazy var policytContentBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Privacy Policy", for: .normal)
        button.setTitleColor(UIColor.hexColor(hex: 0xA9CD00), for: .normal)
        button.titleLabel?.font = UIFont.PingFangSC(size: 14)
        button.tag = 13
        button.addTarget(self, action: #selector(chooseButtonActio(button:)), for: .touchUpInside)
        return button
    }()
    lazy var registerBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Register", for: .normal)
        button.setTitleColor(UIColor.white, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCMedium(size: 16)
        button.backgroundColor = .black
        button.showCorner(30)
        button.addTarget(self, action: #selector(registerAction), for: .touchUpInside)
        return button
    }()
    lazy var chooseAddressView: ChooseAddressView = {
        let view = ChooseAddressView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 335+UIDevice.xp_safeDistanceBottom()))
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Register"

        self.creartUI()
        
        self.loadAreaData()
    }
    
    
    // MARK:  load
    
    func loadAreaData() {
        ApiManager.loadAreaTree { list, error in
            if list != nil {
                self.areaList = list!
            }
        }
    }
    
    
    // MARK:  action
    @objc func clickGetMsgCodeBtn() {
        guard let mobile = accountView.textValue,mobile.isBlank == false else {
            MCToast.mc_text("Please enter Phone Number")
            return
        }
        ApiManager.sendVerCode(phonenumber: mobile) { success, errorMsg in
            MCToast.mc_text("Verification code sent successfully")
        }
    }
    
    @objc func chooseButtonActio(button: UIButton) {
        if button.tag == 10 {
            button.isSelected = !button.isSelected
            self.isAgreeRegistration = button.isSelected
        } else if button.tag == 11 {
            let webVc = CustomWebViewController(type: .registration,showBottom: true)
            webVc.acceptBlock = {
                self.isAgreeRegistration = true
                self.agreementBtn.isSelected = true
            }
            self.navigationController?.pushViewController(webVc, animated: true)
  
        } else if button.tag == 12 {
            button.isSelected = !button.isSelected
            self.isAgreePrivacy = button.isSelected
        } else {
            let webVc = CustomWebViewController(type: .privacy,showBottom: true)
            webVc.acceptBlock = {
                self.isAgreePrivacy = true
                self.policytBtn.isSelected = true
            }
            self.navigationController?.pushViewController(webVc, animated: true)
        }
    }
    
    
    @objc func registerAction() {
        guard let phone = accountView.textValue,phone.isBlank == false else {
            MCToast.mc_text("Please enter Phone Number")
            return
        }
        guard let smsCode = verCodeView.textValue,smsCode.isBlank == false else {
            MCToast.mc_text("Please enter Verification code")
            return
        }
        guard let zoneL = self.zoneL else {
            MCToast.mc_text("Please select Suburb")
            return
        }
        if !self.isAgreeRegistration {
            MCToast.mc_text("Please check Registration Agreement")
            return
        }
        if !self.isAgreePrivacy {
            MCToast.mc_text("Please check Privacy Policy")
            return
        }
        
        var params = [String : Any]()
        params["phone"] = phone
        params["smsCode"] = smsCode
        params["zoneL"] = zoneL
        params["zoneM"] = zoneM
        params["zoneS"] = zoneS
        ApiManager.register(params: params) { success, errorMsg in
            if success  {
                MCToast.mc_text("Register success") {
                    self.navigationController?.popViewController(animated: true)
                }
            } else {
                if let msg = errorMsg {
                    MCToast.mc_text(msg)
                }
            }
        }

    }
    @objc func chooseAddress() {
        self.view.endEditing(true)
        let alertVc = TYAlertController(alert: self.chooseAddressView, preferredStyle: .actionSheet)
        self.chooseAddressView.areaList = self.areaList
        alertVc?.backgoundTapDismissEnable = true
        self.chooseAddressView.cancelBlock = {
            alertVc?.dismiss(animated: true)
        }
        self.chooseAddressView.okBlock = { [weak self] (stateIndex,cityIndex,suburbIndex) in
            guard let wSelf = self else { return }
            alertVc?.dismiss(animated: true)
            wSelf.setZoonId(stateIndex: stateIndex, cityIndex: cityIndex, suburbIndex: suburbIndex)
        }
        self.present(alertVc!, animated: true)
    }
    
    
    private func setZoonId(stateIndex: Int,cityIndex: Int,suburbIndex: Int) {
        var address = ""
        if self.areaList.count > stateIndex {
            let stateModel = self.areaList[stateIndex]
            self.zoneL = stateModel.id
            address = stateModel.areaName + " "
            
            if stateModel.children.count > cityIndex {
                let cityModel = stateModel.children[cityIndex]
                self.zoneM = cityModel.id
                address += cityModel.areaName + " "
                if cityModel.children.count > suburbIndex {
                    let suburbModel = cityModel.children[suburbIndex]
                    self.zoneS = suburbModel.id
                    address += suburbModel.areaName
                } else {
                    self.zoneS = nil
                }
                
            } else {
                self.zoneM = nil
            }
        } else {
            self.zoneL = nil
        }
        self.addressView.textValue = address
    }
    
    
    // MARK:  ui
    func creartUI() {
        self.view.addSubview(lineView)
        self.view.addSubview(accountView)
        self.view.addSubview(verCodeView)
        self.view.addSubview(addressView)
        
        self.view.addSubview(agreementBtn)
        self.view.addSubview(agreementContentBtn)
        self.view.addSubview(policytBtn)
        self.view.addSubview(policytContentBtn)
        self.view.addSubview(registerBtn)
        
        lineView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(1)
        }
        
        accountView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(60)
            make.left.right.equalToSuperview().inset(55)
            make.height.equalTo(44)
        }
        verCodeView.snp.makeConstraints { make in
            make.top.equalTo(accountView.snp.bottom).offset(45)
            make.left.right.equalToSuperview().inset(55)
            make.height.equalTo(44)
        }
        addressView.snp.makeConstraints { make in
            make.top.equalTo(verCodeView.snp.bottom).offset(45)
            make.left.right.equalToSuperview().inset(55)
            make.height.equalTo(44)
        }
        
        agreementBtn.snp.makeConstraints { make in
            make.left.equalTo(55)
            make.width.height.equalTo(20)
            make.top.equalTo(addressView.snp.bottom).offset(120)
        }
        agreementContentBtn.snp.makeConstraints { make in
            make.centerY.equalTo(agreementBtn)
            make.left.equalTo(agreementBtn.snp.right).offset(12)
        }
        
        policytBtn.snp.makeConstraints { make in
            make.left.equalTo(55)
            make.width.height.equalTo(20)
            make.top.equalTo(agreementBtn.snp.bottom).offset(20)
        }
        policytContentBtn.snp.makeConstraints { make in
            make.centerY.equalTo(policytBtn)
            make.left.equalTo(policytBtn.snp.right).offset(12)
        }
        
        registerBtn.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(25)
            make.height.equalTo(60)
            make.top.equalTo(policytBtn.snp.bottom).offset(40)
        }
   
    }

  

}
