//
//  CustomWebViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/8/11.
//

import UIKit
import WebKit
import MCToast

/// web 加载 类型
enum WebLoadType: Int {
    /// 注册协议
    case registration = 1
    /// 隐私政策
    case privacy
    /// 关于我们
    case about
   
    
}

class CustomWebViewController: BaseViewController {
    var acceptBlock: (() -> Void)?

    private var model: WebModel?
    private var type: WebLoadType = .registration
    private var showBottom: Bool = false
    private lazy var wkWebView: WKWebView = {
        let wkWebView = WKWebView()
        wkWebView.isOpaque = false
        wkWebView.backgroundColor = .clear
        return wkWebView
    }()
    
    init(type: WebLoadType,showBottom: Bool = false) {
        super.init(nibName: nil, bundle: nil)
        self.type = type
        self.showBottom = showBottom
    }
    
    lazy var bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        let button = UIButton(type: .custom)
        button.setTitle("Accept", for: .normal)
        button.setTitleColor(UIColor.white, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 18)
        button.addTarget(self, action: #selector(bottomButtonAction(button:)), for: .touchUpInside)
        button.backgroundColor = UIColor.black
        button.showCorner(30)
        view.addSubview(button)
        button.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.right.equalToSuperview().inset(25)
            make.height.equalTo(60)
        }
        let lineView = UIView()
        lineView.backgroundColor = UIColor.greyE6
        view.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(1)
        }
        return view
    }()
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.showLine()
        self.creatUI()
        self.loadData()
    }
    
    
    override func loadData() {
        
        if self.type == .registration {
            ApiManager.getPlatform { model, errorMsg in
                if model != nil {
                    self.model = model
                    self.reloadData()
                } else {
                    if let msg = errorMsg {
                        MCToast.mc_text(msg)
                    }
                }
            }
        } else if self.type == .privacy {
            ApiManager.getPrivacy { model, errorMsg in
                if model != nil {
                    self.model = model
                    self.reloadData()
                } else {
                    if let msg = errorMsg {
                        MCToast.mc_text(msg)
                    }
                }
            }
        } else if self.type == .about {
            ApiManager.getAbout { model, errorMsg in
                if model != nil {
                    self.model = model
                    self.reloadData()
                } else {
                    if let msg = errorMsg {
                        MCToast.mc_text(msg)
                    }
                }
            }
        }
        
    }
    
    private func reloadData() {
        guard let model = self.model else { return }
        
        self.navigationItem.title = model.title
        
        guard let decodedData = Data(base64Encoded: model.content,options: NSData.Base64DecodingOptions.ignoreUnknownCharacters) else { return }
        let decodedString = NSString(data: decodedData, encoding: NSUTF8StringEncoding)! as String
        let htmlStr = self.formatHtml(str: decodedString)
        
        self.wkWebView.loadHTMLString(htmlStr, baseURL: nil)
        
    }

    
    @objc dynamic func formatHtml(str: String) -> String {
        // 为图片路径添加domain
        let body = str
        let style = "<style type=\"text/css\">" +
                "html{margin:0;padding:20px 30px;}" +
                "body {" +
                "margin: 0;" +
                "padding: 0;" +
                "font-size: 20px;" +
                "}" +
                "img{" +
                "width: 100%;" +
                "height: auto;" +
                "display: block;" +
                "margin-left: auto;" +
                "margin-right: auto;" +
                "}" +
                "</style>"
        let headerString : String = "<header><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no'>\(style)</header>"
        let content = headerString + body
        
        return content
    }
    
    @objc private func bottomButtonAction(button: UIButton) {
        self.acceptBlock?()
        self.navigationController?.popViewController(animated: true)
    }

    private func creatUI() {
        
        if self.showBottom {
            self.view.addSubview(bottomView)
            bottomView.snp.makeConstraints { make in
                make.left.right.equalToSuperview()
                make.height.equalTo(88)
                make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
            }
            self.view.addSubview(wkWebView)
            wkWebView.snp.makeConstraints { make in
                make.left.right.equalToSuperview()
                make.top.equalTo(1)
                make.bottom.equalTo(bottomView.snp.top)
            }
        } else {
            self.view.addSubview(wkWebView)
            wkWebView.snp.makeConstraints { make in
                make.edges.equalToSuperview()
                make.top.equalTo(1)
            }
        }
        
        
    }

}
