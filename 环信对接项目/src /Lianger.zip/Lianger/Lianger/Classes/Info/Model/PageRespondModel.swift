//
//  PageRespondModel.swift
//  Lianger
//
//  Created by 屋联-神兽 on 2023/9/21.
//

import Foundation
import HandyJSON

class RespondModel<T>: BaseModel {
    var msg: String?
    var data: T?
    var code: Int = 0
}

class PageRespondModel<T>: BaseModel {
    var pages: Int = 0
    var searchAfter: [String]?
    var list: [T]?
    var pageSize: Int = 0
    var total: Int = 0
    var nextSearchAfter: [String]?
}

extension String {
    public var url: URL? {
        return URL(string: self)
    }
}
