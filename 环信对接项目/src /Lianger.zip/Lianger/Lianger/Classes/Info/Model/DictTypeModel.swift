//
//  DictTypeModel.swift
//  Lianger
//
//  Created by Qidi on 2023/8/23.
//

import UIKit


class DictTypeModel: BaseModel {

    var createTime:String?
    ///
    var dictSort:Int = 0
    ///
    var dictCode:String?
    ///字段名称
    var dictLabel:String?
    ///字典值
    var dictValue:String?
    ///
    var dictType:String?
    ///
    var cssClass:String?
    ///
    var listClass:String?
    ///
    var isDefault:String?
    ///
    var status:String?
    ///
    var remark:String?

}

class UserModel: BaseModel {
    ///关注状态（0未关注 1关注）
    var followStatus:Int = 0
    ///用户昵称
    var nickName:String?
    ///头像
    var avatar:String?
    ///用户ID
    var userId:String?
    ///用户简介
    var introduction:String?
    ///小区域名称
    var zoneSName:String?
    /// 环信用户名
    var hxUserName: String?
}
