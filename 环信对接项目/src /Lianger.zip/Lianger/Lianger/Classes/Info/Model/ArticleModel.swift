//
//  ArticleModel.swift
//  Lianger
//
//  Created by Qidi on 2023/8/7.
//

import UIKit

class ArticleModel: BaseModel{
    
    ///摘要
    var summary:String?
    ///时间
    var createTime:String?
    ///名称
    var nickName:String?
    ///作者id
    var articleId:String?
    ///图片
    var banner:String?
    ///作者头像
    var avatar:String?
    ///收藏数
    var collection:Int = 0
    ///
    var userId:String?
    ///
    var zoneSName:String?
    ///查看数量
    var views:Int = 0
    ///
    var status:Int?
}


class ArticleDetailModel: BaseModel{
    
    ///摘要
    var summary:String?
    ///文章内容
    var content:String?
    ///时间
    var createTime:String?
    ///文章作者
    var userName:String?
    ///主键id
    var articleId:String?
    ///L分类信息ID
    var channelLId:String?
    ///S分类信息ID
    var channelSId:String?
    ///文章标记（0普通文章 1推荐文章）
    var flag:Int = 0
    ///图片
    var banner:String?
    ///作者头像
    var avatar:String?
    ///收藏数
    var collection:Int = 0
    ///
    var userId:String?
    ///查看数量
    var views:Int = 0
    ///状态（0正常 1禁用）
    var status:Int = 0
    ///当前文章收藏状态（0未收藏 1收藏）
    var collectionStatus:Int = 0
    ///大区域
    var zoneL:String?
    ///中区域
    var zoneM:String?
    ///小区域
    var zoneS:String?
    ///小区域名称
    var zoneSName:String?
}


class ArticleCommentModel: BaseModel {
    ///
    var id:String?
    ///
    var articleId:String?
    ///评论人ID
    var userId:String?
    ///评论内容
    var content:String?
    ///创建时间
    var createTime:String?
    ///昵称
    var nickName:String?
    ///头像
    var avatar:String?
    
}
