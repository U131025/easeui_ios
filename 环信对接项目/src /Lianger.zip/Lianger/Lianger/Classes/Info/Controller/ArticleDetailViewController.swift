//
//  ArticleDetailViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/8/10.
//

import UIKit
import MCToast
import IQKeyboardManagerSwift
import SwiftyUserDefaults

class ArticleDetailViewController: BaseViewController {
    
    var articleId: String?
    private var commentsDataArray: [ArticleCommentModel] = []

    private var articleModel: ArticleDetailModel?
    
    private lazy var headerView: ArticleDetailHeaderView = {
        let view = ArticleDetailHeaderView.init(frame: .zero)
        
        return view
    }()
    private var avatarImageView: UIImageView!
    private var nameLabel: UILabel!
    private lazy var commentCountLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCBold(size: 14)
        label.textAlignment = .center
        label.textColor = UIColor.blackText
        return label
    }()
    
    private lazy var userInfoView: UIView = {
        let view = UIView()
        avatarImageView = UIImageView()
        view.addSubview(avatarImageView)
        avatarImageView.snp.makeConstraints { make in
            make.width.height.equalTo(24)
            make.centerY.equalToSuperview()
            make.left.equalToSuperview()
            make.top.equalTo(10)
        }
        avatarImageView.showCorner(12)
        nameLabel = UILabel()
        nameLabel.textColor = UIColor.blackText
        nameLabel.font = UIFont.PingFangSCBold(size: 14)
        view.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(avatarImageView.snp.right).offset(5)
            make.right.equalToSuperview().offset(-5)
        }
        let tap = UITapGestureRecognizer(target: self, action: #selector(lookAuthorInfo(tap:)))
        view.addGestureRecognizer(tap)

        return view
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .grouped)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.bounces = false
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.uFoot = URefreshFooter.init(refreshingBlock: { [weak self] in
            self?.loadCommentData(isLoadMore: true)
        })
        tableView.register(ReplyInfoCell.self, forCellReuseIdentifier: "ReplyInfoCell")
        return tableView
    }()
    private lazy var bottomTool: MeesageToolView = {
        let view = MeesageToolView()
        view.sendMessageBlock = { content in
            self.sendCommentAction(content: content)
        }
        return view
    }()
    private var readIds: [String] = []
    private var collectBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.creartUI()
        self.loadData()
        self.loadCommentData(isLoadMore: false)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        IQKeyboardManager.shared.enable = false
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        IQKeyboardManager.shared.enable = true
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    
    // MARK:  请求
    override func loadData() {
        guard let articleId = self.articleId else { return }
        ///存储id
        var readIds:[String] = Defaults.readIds
        if !readIds.contains(articleId) {
            readIds.append(articleId)
            Defaults.readIds = readIds
        }        
        ApiManager.getArticleDetail(articleId: articleId) { model, errorMsg in
            self.articleModel = model
            if model != nil {
                self.articleModel = model
                self.refreshData()
            } else {
                if let msg = errorMsg {
                    MCToast.mc_text(msg)
                }
            }
        }
        
        
    }
    
    private func loadCommentData(isLoadMore: Bool) {
        guard let articleId = self.articleId else { return }
        ApiManager.getArticleCommentCount(articleId: articleId) { count, errMsg in
            self.commentCountLabel.text = "\(count) comments"
        }
        var params = [String : Any]()
        params["pageSize"] = 20
        if isLoadMore {
            if self.commentsDataArray.isEmpty { return }
            params["baseTime"] = self.commentsDataArray.last!.createTime
        } else {
            let date = Date(timeInterval: 100, since: Date())
            params["baseTime"] = date.dateToFormatString()
            self.commentsDataArray.removeAll()
        }
        params["articleId"] = articleId
        ApiManager.getArticleCommentLoadmore(params: params) { list,error in
            if list != nil {
                self.commentsDataArray.append(contentsOf: list!)
                if self.commentsDataArray.count < 20 { //无更多数据
                    self.tableView.uFoot.endRefreshingWithNoMoreData()
                } else {
                    self.tableView.uFoot.state = .idle
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
        }
        
    }
    private func sendCommentAction(content: String?) {
        if let contentText = content,contentText.isBlank == false,let articleId = self.articleId  {
            var params = [String : Any]()
            params["articleId"] = articleId
            params["content"] = contentText
            ApiManager.addArticleComment(params: params) { success, errorMsg in
                if success {
                    self.loadCommentData(isLoadMore: false)
                } else {
                    if let msg = errorMsg {
                        MCToast.mc_text(msg)
                    }
                }
                
            }
        }
        
    }
    
    private func refreshData() {
        guard let articleModel = self.articleModel else { return }
        self.nameLabel.text = articleModel.userName
        if let avatar = articleModel.avatar {
            self.avatarImageView.kf.setImage(with: URL(string: avatar),placeholder: UIImage(named: "me_defaut"))
        } else {
            self.avatarImageView.image = UIImage(named: "me_defaut")
        }
        self.collectBtn.isSelected = articleModel.collectionStatus == 1 ? true : false
   
        self.headerView.model = articleModel
        let height = CGFloat(self.headerView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize).height)
        self.headerView.frame = CGRect(x: 0, y: 0, width: ScreenWidth, height: height)
        self.tableView.tableHeaderView = self.headerView
        
    }
    
    
    // MARK:  Action
    @objc private func collectionAction(button: UIButton) {
        guard let articleId = self.articleId else { return }
        ApiManager.collectionArticle(articleId: articleId) { success, errorMsg in
            if success {
                if let collectionStatus = self.articleModel?.collectionStatus {
                    if collectionStatus == 0 {
                        self.articleModel?.collectionStatus = 1
                        self.collectBtn.isSelected = true
                        MCToast.mc_text("collect sucess")
                    } else {
                        self.collectBtn.isSelected = false
                        self.articleModel?.collectionStatus = 0
                        MCToast.mc_text("cancel collect sucess")
                    }
                }
            } else {
                if let msg = errorMsg {
                    MCToast.mc_text(msg)
                }
            }
        }
    }
    
    @objc private func messageAction(button: UIButton) {
        guard let hxUserName = self.articleModel?.hxUserName, let articleModel = self.articleModel else { return }

        let chatVc = EMChatViewController(conversationId: hxUserName, article: articleModel)
        self.navigationController?.pushViewController(chatVc, animated: true)
    }
    @objc private func lookAuthorInfo(tap: UITapGestureRecognizer) {
        guard let articleModel = self.articleModel,let userId = articleModel.userId else { return }
        let authorVc = AuthorInfoViewController()
        authorVc.userId = userId
        self.navigationController?.pushViewController(authorVc, animated: true)
        
    }

    // MARK:  UI
    private func creartUI() {
        self.setUpNavBar()
        
        self.view.addSubview(bottomTool)
        bottomTool.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
        }
       
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview()
            make.bottom.equalTo(bottomTool.snp.top)
        }
        
    }
    
    func setUpNavBar() {
        let backBtn = UIButton(type: .custom)
        backBtn.setImage(UIImage(named: "nav_back"), for: .normal)
        backBtn.addTarget(self, action: #selector(goBack), for: .touchUpInside)

        backBtn.size = CGSize(width: 30, height: 30)
        let backItem = UIBarButtonItem(customView: backBtn)
        let userItem = UIBarButtonItem(customView: self.userInfoView)

        self.navigationItem.leftBarButtonItems = [backItem,userItem]

        collectBtn = UIButton(type: .custom)
        collectBtn.setImage(UIImage(named: "icon_collect"), for: .normal)
        collectBtn.setImage(UIImage(named: "icon_collect_seleted"), for: .selected)
        collectBtn.addTarget(self, action: #selector(collectionAction(button:)), for: .touchUpInside)
        let collectItem = UIBarButtonItem(customView: collectBtn)

        let messageBtn = UIButton(type: .custom)
        messageBtn.setImage(UIImage(named: "icon_msg"), for: .normal)
        messageBtn.addTarget(self, action: #selector(messageAction(button:)), for: .touchUpInside)
        let messageItem = UIBarButtonItem(customView: messageBtn)
        
        self.navigationItem.rightBarButtonItems = [collectItem,messageItem]
        
    }

}
extension ArticleDetailViewController {
    
    @objc private func keyboardWillShow(_ notification: Notification) {
        self.handleKeyboardNotification(notification, isShow: true)
    }
    @objc private func keyboardWillHide(_ notification: Notification) {
        self.handleKeyboardNotification(notification, isShow: false)

    }
    private func handleKeyboardNotification(_ notification: Notification,isShow: Bool) {
        
        if let info = notification.userInfo {
            let animationDuration = info[UIResponder.keyboardAnimationDurationUserInfoKey] as? TimeInterval ?? 0.25
            if let kbFrame = info[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
                if isShow {
                    UIView.animate(withDuration: animationDuration) {
                        self.bottomTool.snp.updateConstraints { make in
                            make.bottom.equalToSuperview().offset(-kbFrame.height)
                        }
                    }
                } else {
                    UIView.animate(withDuration: animationDuration) {
                        self.bottomTool.snp.updateConstraints { make in
                            make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
                        }
                    }
                }
            }
        }
    }
    
    
}

extension ArticleDetailViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.commentsDataArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: ReplyInfoCell = tableView.dequeueReusableCell(withIdentifier: "ReplyInfoCell") as! ReplyInfoCell
        if indexPath.row < self.commentsDataArray.count {
            cell.model = self.commentsDataArray[indexPath.row]
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = UIView()
        header.addSubview(self.commentCountLabel)
        commentCountLabel.snp.makeConstraints { make in
            make.center.equalToSuperview()
        }
        return header
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}
