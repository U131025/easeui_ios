//
//  HomeInfoViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/7.
//

import UIKit
import MCToast
import SwiftyUserDefaults

class HomeInfoViewController: BaseViewController {

    private lazy var navView: HomeNavView = {
        let navView = HomeNavView(frame: .zero)
        return navView
    }()
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.register(ArticleCell.self, forCellReuseIdentifier: "ArticleCell")
        tableView.uHead = URefreshNormalHeader.init(refreshingBlock: { [weak self] in
            self?.loadData()
        })
        tableView.uFoot = URefreshFooter.init(refreshingBlock: { [weak self] in
            self?.loadMoreData()
        })
        self.placeholdView.title = "No content"
        self.placeholdView.placeType(.nodata)
        tableView.backgroundView = self.placeholdView
        tableView.backgroundView?.isHidden = true
        tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 10))
        return tableView
    }()
    
    private let sortVc = HomeSortViewController()
    private var channelLIds: [String] = []
    private var channelSIds: [String] = []
    
    private var dataArray: [ArticleModel] = []
    private let pageSize = 20
    private var zoneType = "m"
    private var zoneId = UserInfoModel.shared.zoneM
    private var readIds: [String] = []
    private var channelModel: ChannelModel?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.creatUI()
        self.sortVc.chooseComplect = { [weak self] in
            self?.setSortCatoryData()
        }
        self.loadData()
        self.loadChannelData()
        NotificationCenter.default.addObserver(self, selector: #selector(didUserAreaChanged), name: NotiKey.didUserAreaChanged, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        self.readIds = Defaults.readIds
        self.tableView.reloadData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: false)

    }
    
    // MARK:  请求数据
    override func loadData()  {
        var params: [String : Any] = [String : Any]()
        params["zoneId"] = zoneId
        params["zoneType"] = zoneType
        params["pageSize"] = pageSize
        params["baseTime"] = "1970-01-01 00:00:00"
        params["channelLIds"] = self.channelLIds
        params["channelSIds"] = self.channelSIds
        
        ApiManager.loadNewArticle(params: params) { list,error in
            self.tableView.uHead.endRefreshing()
            if list != nil {
                self.dataArray = list!
                self.tableView.backgroundView?.isHidden = !self.dataArray.isEmpty
                if self.dataArray.count < self.pageSize { //无更多数据
                    self.tableView.uFoot.endRefreshingWithNoMoreData()
                } else {
                    self.tableView.uFoot.state = .idle
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
        }
        
    }
    
    func loadMoreData() {
        var params: [String : Any] = [String : Any]()
        params["zoneId"] = zoneId
        params["zoneType"] = zoneType
        params["pageSize"] = pageSize
        params["baseTime"] = self.dataArray.last?.createTime
        params["channelLIds"] = self.channelLIds
        params["channelSIds"] = self.channelSIds

        ApiManager.loadMoreArticle(params: params) { list,error in
            self.tableView.uFoot.endRefreshing()
            if list != nil {
                self.dataArray.append(contentsOf: list!)
                if list!.count < self.pageSize {
                    self.tableView.uFoot.endRefreshingWithNoMoreData()
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
            
        }
    }
    
    func loadChannelData() {
        ApiManager.getChannelList() { model,errMsg in
            self.channelModel = model
        }
    }
    
    @objc func didUserAreaChanged() {
        self.navView.upDateAreaInfo()
        if self.zoneType == "m" {
            self.zoneId = UserInfoModel.shared.zoneM
        } else {
            self.zoneId = UserInfoModel.shared.zoneS
        }
        self.loadData()
    }

    private func setSortCatoryData() {
        guard let channelModel = self.channelModel else { return }
        self.channelLIds.removeAll()
        for model in channelModel.CategoryL {
            if model.isChoose, let chId = model.chId {
                self.channelLIds.append(chId)
            }
        }
        self.channelSIds.removeAll()
        for model in channelModel.CategoryS {
            if model.isChoose, let chId = model.chId {
                self.channelSIds.append(chId)
            }
        }
        if self.channelLIds.isEmpty && self.channelSIds.isEmpty {
            self.navView.sortBtn.isSelected = false
        } else {
            self.navView.sortBtn.isSelected = true
        }
        self.loadData()
        
    }
    

    func creatUI() {
        self.view.addSubview(navView)
        navView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.height.equalTo(UIDevice.xp_navigationBarHeight())
            make.top.equalTo(UIDevice.xp_safeDistanceTop())
        }
        navView.navButtonClickAction = { [weak self] index in
            guard let self = self else { return }
            self.navButtonClick(index: index)
        }
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.bottom.equalToSuperview()
            make.top.equalTo(navView.snp.bottom)
        }
    }

    func navButtonClick(index: Int) {
        if index == 0 {
            self.zoneId = UserInfoModel.shared.zoneM
            self.zoneType = "m"
            self.loadData()
        } else if index == 1 {
            self.zoneId = UserInfoModel.shared.zoneS
            self.zoneType = "s"
            self.loadData()
        } else if index == 3 {
            let searchVc = HomeSearchViewController()
            self.navigationController?.pushViewController(searchVc, animated: true)
        } else if index == 2 {
            self.sortVc.channelModel = self.channelModel
            self.navigationController?.pushViewController(self.sortVc, animated: true)
        }
        
    }
    
}

extension HomeInfoViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 134
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: ArticleCell = tableView.dequeueReusableCell(withIdentifier: "ArticleCell") as! ArticleCell
        if self.dataArray.count > indexPath.row {
            let model = self.dataArray[indexPath.row]
            if let articleId = model.articleId {
                cell.isRead = self.readIds.contains(articleId)
            }
            cell.model = self.dataArray[indexPath.row]
        }
        cell.hiddenCount = true
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let nextVc = ArticleDetailViewController()
        nextVc.articleId = self.dataArray[indexPath.row].articleId
        self.navigationController?.pushViewController(nextVc, animated: true)
    }
    
}
