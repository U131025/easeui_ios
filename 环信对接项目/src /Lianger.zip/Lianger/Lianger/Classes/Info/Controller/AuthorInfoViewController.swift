//
//  AuthorInfoViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/20.
//

import UIKit
import MCToast
import SwiftyUserDefaults

class AuthorInfoViewController: BaseViewController {
    
    var userId: String?
    private var dataArray: [ArticleModel] = []
    private var userModel: UserModel?
    private let pageSize = 20
    lazy var headerView: AuthorInfoHeaderView = {
        let header = AuthorInfoHeaderView()
        return header
    }()
    lazy var followBtn: UIButton = {
        let followBtn = UIButton(type: .custom)
        followBtn.setTitle("Follow", for: .normal)
        followBtn.setTitle("Following", for: .selected)
        followBtn.setTitleColor(UIColor.blackText, for: .normal)
        followBtn.titleLabel?.font = UIFont.PingFangSCMedium(size: 15)
        followBtn.showCorner(16, borderWidth: 1, borderColor: UIColor.blackText)
        return followBtn
    }()
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.register(ArticleCell.self, forCellReuseIdentifier: "ArticleCell")
        tableView.uHead = URefreshNormalHeader.init(refreshingBlock: { [weak self] in
            self?.loadData()
        })
        tableView.uFoot = URefreshFooter.init(refreshingBlock: { [weak self] in
            self?.loadMoreData()
        })
        self.placeholdView.title = "Post your first content."
        self.placeholdView.placeType(.nodata)
        tableView.backgroundView = self.placeholdView
        tableView.backgroundView?.isHidden = true
        tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 10))

        return tableView
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setUpNavBar()
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview()
            make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
        }
                
        self.loadUserInfoData()
        self.loadData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    
    func loadUserInfoData() {
        guard let userId = self.userId else { return }
        ///获取用户信息
        ApiManager.getUserInfo(userId: userId) { model, errorMsg in
            self.headerView.model = model
            self.userModel = model
            if let followStatus = model?.followStatus, followStatus == 1 {
                self.followBtn.showCorner(16, borderWidth: 0, borderColor: UIColor.clear)
                self.followBtn.backgroundColor = UIColor.mainYellow
                self.followBtn.isSelected = true
            }
            let height = CGFloat(self.headerView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize).height)
            self.headerView.frame = CGRect(x: 0, y: 0, width: ScreenWidth, height: height)
            self.tableView.tableHeaderView = self.headerView
        }
    }
    
    override func loadData()  {
        guard let userId = self.userId else { return }

        var params = [String : Any]()
        params["pageSize"] = pageSize
        params["baseTime"] = "1970-01-01 00:00:00"
        params["userId"] = userId
        ApiManager.getNewsArticleList(params: params) { list,error in
            self.tableView.uHead.endRefreshing()
            if list != nil {
                self.dataArray = list!
                self.tableView.backgroundView?.isHidden = !self.dataArray.isEmpty
                if self.dataArray.count < self.pageSize { //无更多数据
                    self.tableView.uFoot.isHidden = true
                } else {
                    self.tableView.uFoot.isHidden = false
                    self.tableView.uFoot.state = .idle
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
            
        }
        
    }
    
    func loadMoreData() {
        guard let userId = self.userId else { return }
        var params = [String : Any]()
        params["baseTime"] = self.dataArray.last?.createTime
        params["userId"] = userId
        params["pageSize"] = pageSize

        ApiManager.getMoreNewsArticleList(params: params) { list,error in
            self.tableView.uFoot.endRefreshing()
            if list != nil {
                self.dataArray.append(contentsOf: list!)
                if list!.count < self.pageSize {
                    self.tableView.uFoot.endRefreshingWithNoMoreData()
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
            
        }
    }
    
    // MARK:  action
    @objc private func messageAction(button: UIButton) {
        guard let hxUserName = self.userModel?.hxUserName else { return }

        let chatVc = EMChatViewController(conversationId: hxUserName)
        chatVc.userModel = self.userModel
        self.navigationController?.pushViewController(chatVc, animated: true)
    }
    @objc private func followAction(button: UIButton) {
        guard let userId = self.userId else { return }
        ApiManager.followUser(userId: userId) { success, errorMsg in
            if success {
                button.isSelected = !button.isSelected
                if button.isSelected {
                    button.showCorner(16, borderWidth: 0, borderColor: UIColor.clear)
                    button.backgroundColor = UIColor.mainYellow
                } else {
                    button.showCorner(16, borderWidth: 1, borderColor: UIColor.blackText)
                    button.backgroundColor = UIColor.clear
                }
            } else {
                if let msg = errorMsg {
                    MCToast.mc_text(msg)
                }
            }
        }
    }
    
    // MARK:  UI
    
    func setUpNavBar() {
        
        let messageBtn = UIButton(type: .custom)
        messageBtn.setImage(UIImage(named: "icon_msg"), for: .normal)
        messageBtn.addTarget(self, action: #selector(messageAction(button:)), for: .touchUpInside)
        let messageItem = UIBarButtonItem(customView: messageBtn)
        
        
        followBtn.size = CGSize(width: 92, height: 32)
        
        followBtn.addTarget(self, action: #selector(followAction(button:)), for: .touchUpInside)
        let followItem = UIBarButtonItem(customView: followBtn)
        
        self.navigationItem.rightBarButtonItems = [followItem,messageItem]
        
    }

 

}


extension AuthorInfoViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 134
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: ArticleCell = tableView.dequeueReusableCell(withIdentifier: "ArticleCell") as! ArticleCell
        if self.dataArray.count > indexPath.row {
            let model = self.dataArray[indexPath.row]
            cell.model = model
        }
        cell.hiddenCount = true
        cell.userView.isUserInteractionEnabled = false
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let nextVc = ArticleDetailViewController()
        nextVc.articleId = self.dataArray[indexPath.row].articleId
        self.navigationController?.pushViewController(nextVc, animated: true)
    }
}
