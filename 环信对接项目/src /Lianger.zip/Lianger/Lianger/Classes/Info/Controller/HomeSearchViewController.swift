//
//  HomeSearchViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/19.
//

import UIKit

class HomeSearchViewController: BaseViewController {

    
    private var showAuthor: Bool = false
    private var seletedBtn: UIButton!
    private var lineView: UIView!
    

    private lazy var navView: SearchNavView = {
        let view = SearchNavView(frame: .zero)
        view.cancelBlock = { [weak self] in
            self?.navigationController?.popViewController(animated: true)
        }
        return view
    }()
    
    
    lazy var titleView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        let titleArr = ["Post","Author"]
        let buttonH: CGFloat = 50.0
        let buttonW: CGFloat = 90.0
        let bottomLine = UIView()
        bottomLine.backgroundColor = UIColor.greyD0
        view.addSubview(bottomLine)
        bottomLine.snp.makeConstraints { make in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(1)
        }
        lineView = UIView()
        lineView.backgroundColor = UIColor.blackText
        for i in 0..<titleArr.count {
            let button = UIButton.init(type: .custom)
            button.setTitle(titleArr[i], for: .normal)
            button.setTitleColor(UIColor.grey98, for: .normal)
            button.setTitleColor(UIColor.blackText, for: .disabled)
            button.titleLabel?.font = UIFont.PingFangSCBold(size: 16)
            button.tag = 100 + i
            button.addTarget(self, action: #selector(sortAction(button:)), for: .touchUpInside)
            button.frame = CGRect(x: CGFloat(i) * buttonW, y: 0, width: buttonW, height: buttonH)
            view.addSubview(button)
            if i == 0 {
                button.isEnabled = false
                seletedBtn = button
                view.addSubview(lineView)
                lineView.snp.makeConstraints { make in
                    make.width.equalTo(buttonW)
                    make.height.equalTo(2.5)
                    make.centerX.equalTo(button)
                    make.bottom.equalToSuperview()
                }
            }
        }
        
        return view
    }()

    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .white
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.bounces = false
        tableView.contentInsetAdjustmentBehavior = .never

        tableView.register(HomeCityCell.self, forCellReuseIdentifier: "HomeCityCell")
        tableView.register(SearchAuthorCell.self, forCellReuseIdentifier: "SearchAuthorCell")

        
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
        self.creatUI()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBar.isHidden = false

    }
    
    @objc private func sortAction(button: UIButton) {
        button.isEnabled = false
        seletedBtn.isEnabled = true
        seletedBtn = button
        
        UIView.animate(withDuration: 0.2) {
            self.lineView.centerX = button.centerX
        }
        self.showAuthor = button.tag == 101
        self.tableView.reloadData()
 
    }

    
    // MARK:  UI
    func creatUI() {
        
        self.view.addSubview(navView)
        navView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().offset(UIDevice.xp_safeDistanceTop())
            make.height.equalTo(50)
        }
        
        self.view.addSubview(titleView)
        titleView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalTo(navView.snp.bottom)
            make.height.equalTo(50)
        }
        
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.bottom.equalToSuperview()
            make.top.equalTo(titleView.snp.bottom)
        }
        
    }
    


}



extension HomeSearchViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if showAuthor {
            return 68
        } else {
            return 134
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if showAuthor {
            let cell: SearchAuthorCell = tableView.dequeueReusableCell(withIdentifier: "SearchAuthorCell") as! SearchAuthorCell
            
            return cell
        } else {
            let cell: HomeCityCell = tableView.dequeueReusableCell(withIdentifier: "HomeCityCell") as! HomeCityCell
            return cell
        }
        
    }
    
    
}
