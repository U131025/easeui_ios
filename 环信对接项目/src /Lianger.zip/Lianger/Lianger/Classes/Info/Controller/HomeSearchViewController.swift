//
//  HomeSearchViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/19.
//

import UIKit
import RxSwift
import RxCocoa
import MCToast
import SwiftyUserDefaults

class HomeSearchViewController: BaseViewController {
    
    private var showAuthor: Bool = false
    private var seletedBtn: UIButton!
    private var lineView: UIView!
    
    private lazy var navView: SearchNavView = {
        let view = SearchNavView(frame: .zero)
        view.cancelBlock = { [weak self] in
            self?.navigationController?.popViewController(animated: true)
        }
        return view
    }()
    
    
    lazy var titleView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        let titleArr = ["Post","Author"]
        let buttonH: CGFloat = 50.0
        let buttonW: CGFloat = 90.0
        let bottomLine = UIView()
        bottomLine.backgroundColor = UIColor.greyD0
        view.addSubview(bottomLine)
        bottomLine.snp.makeConstraints { make in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(1)
        }
        lineView = UIView()
        lineView.backgroundColor = UIColor.blackText
        for i in 0..<titleArr.count {
            let button = UIButton.init(type: .custom)
            button.setTitle(titleArr[i], for: .normal)
            button.setTitleColor(UIColor.grey98, for: .normal)
            button.setTitleColor(UIColor.blackText, for: .disabled)
            button.titleLabel?.font = UIFont.PingFangSCBold(size: 16)
            button.tag = 100 + i
            button.addTarget(self, action: #selector(sortAction(button:)), for: .touchUpInside)
            button.frame = CGRect(x: CGFloat(i) * buttonW, y: 0, width: buttonW, height: buttonH)
            view.addSubview(button)
            if i == 0 {
                button.isEnabled = false
                seletedBtn = button
                view.addSubview(lineView)
                lineView.snp.makeConstraints { make in
                    make.width.equalTo(buttonW)
                    make.height.equalTo(2.5)
                    make.centerX.equalTo(button)
                    make.bottom.equalToSuperview()
                }
            }
        }
        
        return view
    }()

    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .white
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.bounces = false
        tableView.contentInsetAdjustmentBehavior = .never
        
        self.placeholdView.title = "No content"
        self.placeholdView.placeType(.nodata)
        tableView.backgroundView = self.placeholdView
        tableView.backgroundView?.isHidden = true
        tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 10))
        
        tableView.register(HomeCityCell.self, forCellReuseIdentifier: "HomeCityCell")
        tableView.register(SearchAuthorCell.self, forCellReuseIdentifier: "SearchAuthorCell")
        tableView.register(ArticleCell.self, forCellReuseIdentifier: "ArticleCell")

        
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
        self.creatUI()

//        _ = self.navView.textFeild.rx.text.orEmpty
//            .take(until: rx.deallocated)
//            .throttle(.milliseconds(500), scheduler: MainScheduler.instance)
//            .subscribe {[weak self] text in
//                self?.searchAction(text)
//            }
        
        navView.searchBlock = {[weak self] keyword in
            guard let self = self else { return }
            
            if self.showAuthor {
                self.authorCurPageModel = nil
            } else {
                self.articleCurPageModel = nil
            }
            self.searchAction(keyword ?? "")
        }
        
        tableView.uHead = URefreshNormalHeader.init(refreshingBlock: { [weak self] in
            guard let self = self else { return }
            
            if self.showAuthor {
                self.authorCurPageModel = nil
            } else {
                self.articleCurPageModel = nil
            }            
            self.loadData()
        })
        tableView.uFoot = URefreshFooter.init(refreshingBlock: { [weak self] in
            self?.loadData()
        })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBar.isHidden = false

    }
    
    @objc private func sortAction(button: UIButton) {
        button.isEnabled = false
        seletedBtn.isEnabled = true
        seletedBtn = button
        
        UIView.animate(withDuration: 0.2) {
            self.lineView.centerX = button.centerX
        }
        self.showAuthor = button.tag == 101
        self.updateTableStatus()
        
        self.tableView.reloadData()
    }
    
    // MARK:  UI
    func creatUI() {
        
        self.view.addSubview(navView)
        navView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().offset(UIDevice.xp_safeDistanceTop())
            make.height.equalTo(50)
        }
        
        self.view.addSubview(titleView)
        titleView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalTo(navView.snp.bottom)
            make.height.equalTo(50)
        }
        
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.bottom.equalToSuperview()
            make.top.equalTo(titleView.snp.bottom)
        }
    }
    
    // MARK: loadData
    var articleDatas: [ArticleModel] = []
    var authorDatas: [ArticleCommentModel] = []
    var articleCurPageModel: PageRespondModel<ArticleModel>?
    var authorCurPageModel: PageRespondModel<ArticleCommentModel>?
    
    private let pageSize = 20
    
    override func loadData() {
        searchAction(navView.textFeild.text ?? "")
    }
       
    func searchAction(_ keyword: String) {
        
        var params: [String : Any] = [String : Any]()
        params["searchWords"] = keyword
        params["pageSize"] = pageSize
        if showAuthor {
            params["nextSearchAfter"] = authorCurPageModel?.nextSearchAfter ?? []
            
            ApiManager.searchUser(params: params) {[weak self] model, errorMsg in
                
                if let model = model {
                    self?.authorCurPageModel = model
                    
                    if model.pages == 1 {
                        self?.authorDatas.removeAll()
                    }
                    if let datas = model.list {
                        self?.authorDatas += datas
                    }
                    self?.updateTableStatus()
                } else if let msg = errorMsg {
                    MCToast.mc_text(msg)
                }
            }
        } else {
            params["nextSearchAfter"] = articleCurPageModel?.nextSearchAfter ?? []
            ApiManager.searchArticle(params: params) {[weak self] model, errorMsg in
                
                if let model = model {
                    self?.articleCurPageModel = model
                    
                    if model.pages == 1 {
                        self?.articleDatas.removeAll()
                    }
                    if let datas = model.list {
                        self?.articleDatas += datas
                    }
                    self?.updateTableStatus()
                } else if let msg = errorMsg {
                    MCToast.mc_text(msg)
                }
            }
        }
    }
    
    func updateTableStatus() {
        
        if showAuthor, let model = self.authorCurPageModel {
            self.tableView.backgroundView?.isHidden = !self.authorDatas.isEmpty
            
            if self.authorDatas.count == model.total {
                self.tableView.uFoot.endRefreshingWithNoMoreData()
            } else {
                self.tableView.uFoot.state = .idle
            }
           
        } else if let model = self.articleCurPageModel {
            
            self.tableView.backgroundView?.isHidden = !articleDatas.isEmpty
            
            if self.articleDatas.count == model.total {
                self.tableView.uFoot.endRefreshingWithNoMoreData()
            } else {
                self.tableView.uFoot.state = .idle
            }
        }
        self.tableView.reloadData()
    }
}

extension HomeSearchViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if showAuthor {
            return self.authorDatas.count
        } else {
            return self.articleDatas.count
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if showAuthor {
            return 68
        } else {
            return 134
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if showAuthor {
            let cell: SearchAuthorCell = tableView.dequeueReusableCell(withIdentifier: "SearchAuthorCell") as! SearchAuthorCell
            
            let model = self.authorDatas[indexPath.row]
            cell.nameLabel.text = model.nickName
            if let url = model.avatar?.url {
                cell.iconImageView.kf.setImage(with: url, placeholder: UIImage(named: "me_defaut")!)
            } else {
                cell.iconImageView.image = UIImage(named: "me_defaut")!
            }
            
            return cell
        } else {
            
            let cell: ArticleCell = tableView.dequeueReusableCell(withIdentifier: "ArticleCell") as! ArticleCell
            if self.articleDatas.count > indexPath.row {
                let model = self.articleDatas[indexPath.row]
                if let articleId = model.articleId {
                    cell.isRead = Defaults.readIds.contains(articleId)
                }
                cell.model = self.articleDatas[indexPath.row]
            }
            cell.hiddenCount = true
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if showAuthor {
            
            
            let authorVc = AuthorInfoViewController()
            authorVc.userId = self.authorDatas[indexPath.row].userId
            self.navigationController?.pushViewController(authorVc, animated: true)
        } else {
            let nextVc = ArticleDetailViewController()
            nextVc.articleId = self.articleDatas[indexPath.row].articleId
            self.navigationController?.pushViewController(nextVc, animated: true)
        }
    }
}
