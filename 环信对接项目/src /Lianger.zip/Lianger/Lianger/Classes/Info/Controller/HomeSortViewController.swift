//
//  HomeSortViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/19.
//

import UIKit
import MCToast

class HomeSortViewController: BaseViewController {

    var chooseComplect:(() -> Void)?

    var channelModel: ChannelModel?

    lazy var headerView: HomeSortHeaderView = {
        let headerView = HomeSortHeaderView(frame: .zero)
        return headerView
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.register(HomeSortCell.self, forCellReuseIdentifier: "HomeSortCell")
        return tableView
    }()
    lazy var bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        let button = UIButton(type: .custom)
        button.setTitle("Confirm", for: .normal)
        button.setTitleColor(UIColor.white, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 18)
        button.addTarget(self, action: #selector(bottomButtonAction(button:)), for: .touchUpInside)
        button.backgroundColor = UIColor.blackText
        button.showCorner(30)
        view.addSubview(button)
        button.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.right.equalToSuperview().inset(25)
            make.height.equalTo(60)
        }
        let lineView = UIView()
        lineView.backgroundColor = UIColor.greyE6
        view.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(1)
        }
        return view
    }()
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.showLine()
        self.creartUI()
        self.setCategoryData()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    

    
    private func setCategoryData() {
        if let channelModel = self.channelModel {
           
            if !channelModel.CategoryL.isEmpty {
                let count = (channelModel.CategoryL.count + 1) / 2
                let height = CGFloat(count) * 74.0 + 12.0 * CGFloat(count - 1) + 30.0
                self.headerView.frame = CGRect(x: 0, y: 0, width: ScreenWidth, height: height)
                self.tableView.tableHeaderView = self.headerView
                self.headerView.items = channelModel.CategoryL
            } else {
                self.tableView.tableHeaderView = nil
            }
            self.tableView.reloadData()
        }
    }
    
    @objc private func bottomButtonAction(button: UIButton) {
//        var seletedArr: []
//        for model in self.categoryArray {
//
//        }
        self.chooseComplect?()
        self.navigationController?.popViewController(animated: true)

    }

    private func creartUI() {
        
        self.view.addSubview(bottomView)
        bottomView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
            make.height.equalTo(88)
        }
       
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().offset(1)
            make.bottom.equalTo(bottomView.snp.top)
        }

    }
    

}


extension HomeSortViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let channelModel = self.channelModel {
            return channelModel.CategoryS.count
        }
        return 0
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 64
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: HomeSortCell = tableView.dequeueReusableCell(withIdentifier: "HomeSortCell") as! HomeSortCell
        
        if let channelModel = self.channelModel,channelModel.CategoryS.count > indexPath.row {
            cell.model = channelModel.CategoryS[indexPath.row]
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let channelModel = self.channelModel,channelModel.CategoryS.count > indexPath.row {
            let model = channelModel.CategoryS[indexPath.row]
            model.isChoose = !model.isChoose
            self.tableView.reloadData()
        }
    }
 
    
}
