//
//  HomeNavView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/17.
//

import UIKit

class HomeNavView: UIView {
    
    var navButtonClickAction:((Int) -> Void)?
    
    var seleteBtn: UIButton!

    lazy var cityLine: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black
        return view
    }()
    lazy var cityBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle(UserInfoModel.shared.zoneMName, for: .normal)
        button.setTitleColor(.black, for: .disabled)
        button.setTitleColor(UIColor.grey97, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 16)
        button.tag = 10
        button.addTarget(self, action: #selector(navButtonClick(button:)), for: .touchUpInside)
        return button
    }()
    
    lazy var suburbBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle(UserInfoModel.shared.zoneSName, for: .normal)
        button.setTitleColor(.black, for: .disabled)
        button.setTitleColor(UIColor.grey97, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 16)
        button.tag = 11
        button.addTarget(self, action: #selector(navButtonClick(button:)), for: .touchUpInside)
        return button
    }()
    lazy var suburbLine: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black
        return view
    }()
    lazy var searchBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_search_black"), for: .normal)
        button.setImage(UIImage(named: "icon_sort_seleted"), for: .selected)
        button.tag = 13
        button.addTarget(self, action: #selector(navButtonClick(button:)), for: .touchUpInside)
        return button
    }()
    lazy var sortBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_sort"), for: .normal)
        button.setImage(UIImage(named: "icon_sort_seleted"), for: .selected)
        button.tag = 12
        button.addTarget(self, action: #selector(navButtonClick(button:)), for: .touchUpInside)
        return button
    }()
    
    func upDateAreaInfo() {
        print("\(UserInfoModel.shared.zoneMName)")
        self.cityBtn.setTitle(UserInfoModel.shared.zoneMName, for: .normal)
        self.suburbBtn.setTitle(UserInfoModel.shared.zoneSName, for: .normal)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.creatUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func creatUI()  {
        
        addSubview(cityBtn)
        cityBtn.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.right.equalTo(self.snp.centerX).offset(-10)
        }
        cityBtn.isEnabled = false
        seleteBtn = cityBtn
        
        addSubview(suburbBtn)
        suburbBtn.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(cityBtn.snp.right).offset(20)
        }
        self.insertSubview(cityLine, belowSubview: cityBtn)
        cityLine.snp.makeConstraints { make in
            make.height.equalTo(2)
            make.bottom.equalToSuperview().offset(-5)
            make.centerX.equalTo(cityBtn)
            make.width.equalTo(30)
        }
        self.insertSubview(suburbLine, belowSubview: suburbBtn)
        suburbLine.snp.makeConstraints { make in
            make.height.equalTo(2)
            make.bottom.equalToSuperview().offset(-5)
            make.centerX.equalTo(suburbBtn)
            make.width.equalTo(30)
        }
        cityLine.isHidden = false
        suburbLine.isHidden = true
        addSubview(sortBtn)
        sortBtn.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-20)
        }
        
        addSubview(searchBtn)
        searchBtn.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().offset(20)
        }
        
    }
    
    
    
    @objc func navButtonClick(button: UIButton) {
        
        if button.tag < 12 {
            button.isEnabled = false
            button.titleLabel?.font = UIFont.PingFangSCMedium(size: 16)
            seleteBtn.isEnabled = true
            seleteBtn.titleLabel?.font = UIFont.PingFangSCMedium(size: 14)
            seleteBtn = button
            if button.tag == 10 {
                cityLine.isHidden = false
                suburbLine.isHidden = true
            } else if button.tag == 11 {
                cityLine.isHidden = true
                suburbLine.isHidden = false
            }
        }
        self.navButtonClickAction?(button.tag - 10)
        
    }

}
