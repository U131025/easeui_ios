//
//  MeesageToolView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/20.
//

import UIKit
import QMUIKit

class MeesageToolView: UIView,QMUITextViewDelegate{
    
    var isChat: Bool = false {
        didSet {
            if isChat {
                self.emojiBtn.setImage(UIImage(named: "icon_image"), for: .normal)
            } else {
                self.emojiBtn.setImage(UIImage(named: "icon_emoji"), for: .normal)
            }
        }
    }
    
    var sendMessageBlock: ((String) ->Void)?
    var sendDataBlock:(() ->Void)?
    private lazy var textView: QMUITextView = {
        let textView = QMUITextView()
        textView.tintColor = UIColor.inputTintColor
        textView.font = UIFont.PingFangSCMedium(size: 14)
        textView.textColor = UIColor.blackText
        textView.backgroundColor = UIColor.greyF2
        textView.showCorner(4)
        textView.returnKeyType = .send
        textView.delegate = self
        return textView
    }()
    
    private lazy var emojiBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_emoji"), for: .normal)
        button.addTarget(self, action: #selector(sendDataAction), for: .touchUpInside)
        return button
    }()
    
    private lazy var sendBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_send"), for: .normal)
        button.backgroundColor = UIColor.mainYellow
        button.showCorner(8)
        button.addTarget(self, action: #selector(sendMessageAction), for: .touchUpInside)
        return button
    }()
    
    lazy var lineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.greyE6
        return view
    }()
    
    
    @objc func sendMessageAction() {
        self.sendMessageBlock?(textView.text)
        textView.text = nil
        textView.endEditing(true)
    }
    @objc func sendDataAction() {
        self.sendDataBlock?()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.creatUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    private func creatUI()  {
        
        addSubview(emojiBtn)
        emojiBtn.snp.makeConstraints { make in
            make.width.height.equalTo(24)
            make.bottom.equalToSuperview().offset(-23)
            make.left.equalTo(15)
        }
        
        addSubview(textView)
        textView.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(56)
            make.right.equalToSuperview().offset(-93)
            make.centerY.equalToSuperview()
            make.height.equalTo(40)
            make.bottom.equalToSuperview().offset(-15)
        }
        
        addSubview(sendBtn)
        sendBtn.snp.makeConstraints { make in
            make.width.equalTo(68)
            make.height.equalTo(40)
            make.bottom.equalToSuperview().offset(-15)
            make.right.equalToSuperview().offset(-12)
        }
        addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(1)
        }
        
    }
    
    func textView(_ textView: QMUITextView!, newHeightAfterTextChanged height: CGFloat) {
        var textH = height
        if textH > 40 {
            textH = textH > 95 ? 95 : textH
            self.textView.snp.updateConstraints { make in
                make.height.equalTo(textH)
            }
        } else {
            self.textView.snp.updateConstraints { make in
                make.height.equalTo(40)
            }
        }
        
    }

}
