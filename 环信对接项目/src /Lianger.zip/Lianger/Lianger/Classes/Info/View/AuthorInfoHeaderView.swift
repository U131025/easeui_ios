//
//  AuthorInfoHeaderView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/20.
//

import UIKit

class AuthorInfoHeaderView: UIView {
    
    lazy var iconImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCBold(size: 19)
        return label
    }()
    lazy var suburbLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSCMedium(size: 13)
        return label
    }()
    lazy var lineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.greyE6
        return view
    }()
    lazy var contentLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCMedium(size: 14)
        label.numberOfLines = 0
        return label
    }()
    
    var model: UserModel? {
        didSet {
            guard let model = model else { return }
            if let avatar = model.avatar {
                iconImageView.kf.setImage(with: URL(string: avatar),placeholder: UIImage(named: "me_defaut"))
            } else {
                iconImageView.image = UIImage(named: "me_defaut")
            }
            nameLabel.text = model.nickName
            suburbLabel.text = model.zoneSName
            contentLabel.text = model.introduction
            
        }
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.creatUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    private func creatUI()  {
        
        self.addSubview(iconImageView)
        iconImageView.snp.makeConstraints { make in
            make.left.equalTo(47)
            make.top.equalTo(75)
            make.width.height.equalTo(80)
        }
        
        self.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.left.equalTo(iconImageView.snp.right).offset(22)
            make.bottom.equalTo(iconImageView.snp.centerY)
            make.right.lessThanOrEqualToSuperview().offset(-20)
        }
        
        self.addSubview(suburbLabel)
        
        suburbLabel.snp.makeConstraints { make in
            make.left.equalTo(nameLabel)
            make.top.equalTo(nameLabel.snp.bottom).offset(4)
            make.right.lessThanOrEqualToSuperview().offset(-20)
        }
        
        self.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(47)
            make.height.equalTo(1)
            make.top.equalTo(iconImageView.snp.bottom).offset(23)
        }
        
        self.addSubview(contentLabel)
        contentLabel.snp.makeConstraints { make in
            make.left.equalToSuperview().inset(60)
            make.width.equalTo(ScreenWidth - 120)
            make.top.equalTo(lineView.snp.bottom).offset(12)
            make.bottom.equalToSuperview().offset(-12)
        }
        
    }
    
    
}
