//
//  SearchNavView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/19.
//

import UIKit
import QMUIKit

class SearchNavView: UIView,QMUITextFieldDelegate{

    var cancelBlock: (() -> Void)?
    var searchBlock: ((String?) -> Void)?
    
    private lazy var searchView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.greyF2
        view.showCorner(4)
        return view
    }()
    private lazy var searchIcon: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "search_icon"))
        return imageView
    }()
    lazy var textFeild: QMUITextField = {
        let textFeild = QMUITextField()
        textFeild.placeholderColor = UIColor.placeholdColor
        textFeild.placeholder = "search"
        textFeild.font = UIFont.PingFangSCMedium(size: 15)
        textFeild.returnKeyType = .search
        textFeild.delegate = self
        textFeild.clearButtonMode = .whileEditing
        return textFeild
    }()
    
    private lazy var cancelBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Cancel", for: .normal)
        button.setTitleColor(UIColor.blackText, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCMedium(size: 15)
        button.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)
        return button
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.creatUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    @objc private func cancelAction() {
        self.cancelBlock?()
    }
    
    private func creatUI()  {
        
        addSubview(searchView)
        searchView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(19)
            make.height.equalTo(46)
            make.right.equalToSuperview().offset(-77)
        }
        
        searchView.addSubview(searchIcon)
        searchIcon.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(15)
            make.width.height.equalTo(15)
        }
        
        searchView.addSubview(textFeild)
        textFeild.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(42)
            make.top.bottom.right.equalToSuperview()
        }
        
        addSubview(cancelBtn)
        cancelBtn.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-15)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        searchBlock?(textField.text)
        return true
    }
}
