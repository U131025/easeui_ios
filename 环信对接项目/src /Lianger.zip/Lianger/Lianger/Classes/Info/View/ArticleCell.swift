//
//  ArticleCell.swift
//  Lianger
//
//  Created by Qidi on 2023/8/10.
//

import UIKit

class ArticleCell: UITableViewCell {

    lazy var infoView: UIView = {
        let view = UIView()
        view.showCorner(8, borderWidth: 1, borderColor: UIColor.greyD0)
        return view
    }()
    
    lazy var tipsView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.init(r: 0, g: 0, b: 0,a: 0.8)
        view.showCorner(8)
        return view
    }()
    lazy var tipsImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "tips_offline"))
        return imageView
    }()
    lazy var tipsLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.mainYellow
        label.font = UIFont.PingFangSCMedium(size: 20)
        label.text = "Be blocked by the platform"
        return label
    }()
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSC(size: 14)
        label.numberOfLines = 3
        return label
    }()
    
    lazy var rightImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        return imageView
    }()
    lazy var userView: UIView = {
        let view = UIView()
        let tap = UITapGestureRecognizer(target: self, action: #selector(gotoUserInfo))
        view.addGestureRecognizer(tap)
        return view
    }()
    lazy var iconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "me_defaut")
        imageView.showCorner(12)
        return imageView
    }()
    lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCMedium(size: 12)
        return label
    }()
    
    lazy var areaLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSC(size: 10)
        return label
    }()
    
    lazy var collectBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "collect_gray"), for: .disabled)
        button.setTitle("0", for: .disabled)
        button.setTitleColor(UIColor.white, for: .disabled)
        button.isEnabled = false
        button.titleLabel?.font = UIFont.PingFangSCMedium(size: 12)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: -5, bottom: 0, right: 0)
        return button
    }()
    lazy var viewBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "view_gray"), for: .disabled)
        button.setTitle("0", for: .disabled)
        button.setTitleColor(UIColor.white, for: .disabled)
        button.isEnabled = false
        button.titleLabel?.font = UIFont.PingFangSCMedium(size: 12)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: -5, bottom: 0, right: 0)
        return button
    }()
    var hiddenCount: Bool = false {
        didSet {
            self.collectBtn.isHidden = self.hiddenCount
            self.viewBtn.isHidden = self.hiddenCount
        }
    }
    //设置已读
    var isRead: Bool = false {
        didSet {
            if isRead {
                self.titleLabel.textColor = UIColor.grey99
                self.nameLabel.textColor = UIColor.grey99
                self.infoView.alpha = 0.8
            } else {
                self.titleLabel.textColor = UIColor.blackText
                self.nameLabel.textColor = UIColor.blackText
                self.infoView.alpha = 1.0
            }
        }
    }
    
    var model: ArticleModel? {
        didSet {
            guard let model = model else { return }
            
            titleLabel.text = model.summary
            if let avatar = model.avatar {
                iconImageView.kf.setImage(with: URL(string: avatar),placeholder: UIImage(named: "me_defaut"))
            } else {
                iconImageView.image = UIImage(named: "me_defaut")
            }
            nameLabel.text = model.nickName
            areaLabel.text = model.zoneSName
            if let banner = model.banner,banner.isBlank == false, let fisrtImage = banner.components(separatedBy: ",").first{
                rightImageView.isHidden = false
                rightImageView.snp.updateConstraints { make in
                    make.width.equalTo(134)
                }
                titleLabel.snp.remakeConstraints({ make in
                    make.left.equalTo(15)
                    make.top.equalTo(14)
                    make.right.equalTo(rightImageView.snp.left).offset(-12)
                })
                rightImageView.kf.setImage(with: URL(string: fisrtImage),placeholder: UIColor.grey99.image())
                collectBtn.setImage(UIImage(named: "collect_white"), for: .disabled)
                let collectText = Utils.convertNumberText(count: model.collection)
                collectBtn.setTitle(collectText, for: .disabled)
                collectBtn.setTitleColor(.white, for: .disabled)
                
                viewBtn.setImage(UIImage(named: "view_white"), for: .disabled)
                let viewText = Utils.convertNumberText(count: model.views)
                viewBtn.setTitle(viewText, for: .disabled)
                viewBtn.setTitleColor(.white, for: .disabled)

            } else {
                rightImageView.snp.updateConstraints { make in
                    make.width.equalTo(0)
                }
                rightImageView.isHidden = true
                titleLabel.snp.remakeConstraints({ make in
                    make.left.equalTo(15)
                    make.top.equalTo(14)
                    make.right.equalToSuperview().offset(-12)
                })
                collectBtn.setImage(UIImage(named: "collect_gray"), for: .disabled)
                let collectText = Utils.convertNumberText(count: model.collection)
                collectBtn.setTitle(collectText, for: .disabled)
                collectBtn.setTitleColor(UIColor.grey99, for: .disabled)

                viewBtn.setImage(UIImage(named: "view_gray"), for: .disabled)
                let viewText = Utils.convertNumberText(count: model.views)
                viewBtn.setTitle(viewText, for: .disabled)
                viewBtn.setTitleColor(UIColor.grey99, for: .disabled)

            }
            if model.status == 0 {
                self.tipsView.isHidden = true
            } else {
                self.tipsView.isHidden = false
            }
        }
    }
    
    
    @objc func gotoUserInfo() {
        guard let userId = model?.userId else { return }
        let authorVc = AuthorInfoViewController()
        authorVc.userId = userId
        self.viewController().navigationController?.pushViewController(authorVc, animated: true)
    }
 
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var frame: CGRect {
        didSet {
            var newFrame = frame
            newFrame.origin.y += 8
            newFrame.size.height -= 8
            super.frame = newFrame
        }
    }
    
    
    func creartUI() {
        
        contentView.addSubview(infoView)
        infoView.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(20)
            make.top.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        infoView.addSubview(rightImageView)
        rightImageView.snp.makeConstraints { make in
            make.top.right.bottom.equalToSuperview()
            make.width.equalTo(134)
        }
        
        infoView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.left.equalTo(15)
            make.top.equalTo(14)
            make.right.equalTo(rightImageView.snp.left).offset(-12)
        }
        
        
        infoView.addSubview(iconImageView)
        iconImageView.snp.makeConstraints { make in
            make.width.height.equalTo(24)
            make.left.equalTo(15)
            make.bottom.equalToSuperview().offset(-10)
        }
        infoView.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.top.equalTo(iconImageView).offset(-4)
            make.left.equalTo(iconImageView.snp.right).offset(8)
            make.right.lessThanOrEqualTo(rightImageView.snp.left).offset(-12)
        }
        
        infoView.addSubview(areaLabel)
        areaLabel.snp.makeConstraints { make in
            make.left.equalTo(nameLabel)
            make.top.equalTo(nameLabel.snp.bottom)
            make.right.lessThanOrEqualTo(rightImageView.snp.left).offset(-12)
        }
        
        infoView.addSubview(viewBtn)
        viewBtn.snp.makeConstraints { make in
            make.right.equalToSuperview().offset(-11)
            make.bottom.equalToSuperview().offset(-15)
            
        }
        
        infoView.addSubview(collectBtn)
        collectBtn.snp.makeConstraints { make in
            make.centerY.equalTo(viewBtn)
            make.right.equalTo(viewBtn.snp.left).offset(-11)
        }
        infoView.addSubview(userView)
        userView.snp.makeConstraints { make in
            make.left.equalTo(0)
            make.top.equalTo(nameLabel)
            make.bottom.equalTo(areaLabel)
            make.right.equalTo(rightImageView.snp.left).offset(-12)
        }
        
        infoView.addSubview(tipsView)
        tipsView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        tipsView.addSubview(tipsImageView)
        tipsImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(17)
            make.width.height.equalTo(38)
        }
        tipsView.addSubview(tipsLabel)
        tipsLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(tipsImageView.snp.right).offset(15)
            make.right.lessThanOrEqualToSuperview().offset(-15)
        }
    }
    
}
