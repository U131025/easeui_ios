//
//  HomeSortHeaderView.swift
//  Lianger
//
//  Created by Qidi on 2023/8/23.
//

import UIKit

class HomeSortHeaderView: UIView {

    
    
    var items: [CategoryModel] = [] {
        didSet {
            self.subviews.forEach{ $0.removeFromSuperview() }
            
            self.creartUI()
            
        }
        
    }
    
   
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
            
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func categorySeleted(button: UIButton) {
        button.isSelected = !button.isSelected
        let index = button.tag
        let model = items[index]
        model.isChoose = button.isSelected
        
        if button.isSelected {
            button.backgroundColor = UIColor.mainYellow
            button.showCorner(25, borderWidth: 0, borderColor: UIColor.clear)
        } else {
            button.backgroundColor = .clear
            button.showCorner(25, borderWidth: 1, borderColor: UIColor.blackText)
        }
        
    }

    private func creartUI() {
        
        let buttonW:CGFloat = (ScreenWidth - 78.0) / 2.0
        let buttonH:CGFloat = 74.0
        for i in 0..<items.count {
            let model = items[i]
            let button = UIButton(type: .custom)
            button.setTitle(model.chName, for: .normal)
            button.setTitleColor(UIColor.blackText, for: .normal)
            button.titleLabel?.font = UIFont.PingFangSCMedium(size: 15)
            button.titleLabel?.numberOfLines = 2
            button.tag = i
            button.addTarget(self, action: #selector(categorySeleted(button:)), for: .touchUpInside)
            button.backgroundColor = .clear
            button.showCorner(25, borderWidth: 1, borderColor: UIColor.blackText)
            
            let buttonX = CGFloat(i % 2) * (10.0 + buttonW) + 34.0
            let buttonY = CGFloat(i / 2) * (12.0 + buttonH) + 15.0
            button.frame = CGRect(x: buttonX, y: buttonY, width: buttonW, height: buttonH)
            self.addSubview(button)
        }
        
        let lineView = UIView()
        lineView.backgroundColor = UIColor.greyE6
        
        self.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(1)
        }
        
    }
    
}
