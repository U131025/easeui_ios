//
//  ArticleDetailHeaderView.swift
//  Lianger
//
//  Created by Qidi on 2023/8/10.
//

import UIKit

class ArticleDetailHeaderView: UIView,SDCycleScrollViewDelegate {


    private lazy var bannerView: SDCycleScrollView = {
        let scrollView = SDCycleScrollView.init(frame: .zero)
        scrollView.backgroundColor = .clear
        scrollView.delegate = self
        scrollView.autoScrollTimeInterval = 5
        
        return scrollView
    }()
    
    lazy var contentLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCMedium(size: 14)
        label.numberOfLines = 0
        return label
    }()
    
    lazy var timeLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSCMedium(size: 12)
        return label
    }()
    lazy var viewButton: UIButton = {
        let button = UIButton(type: .custom)
        button.isEnabled = false
        button.setTitle("", for: .disabled)
        button.setTitleColor(UIColor.grey99, for: .disabled)
        button.titleLabel?.font = UIFont.PingFangSCMedium(size: 12)
        button.setImage(UIImage(named: "view_count"), for: .disabled)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: -5, bottom: 0, right: 0)
        return button
    }()
    
    lazy var lineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.grey99
        return view
    }()
    
    var model: ArticleDetailModel? {
        didSet {
            guard let model = model else { return }
            
            self.contentLabel.text = model.content
            if let banner = model.banner,banner.isBlank == false {
                self.bannerView.isHidden = false
                self.bannerView.imageURLStringsGroup = banner.components(separatedBy: ",")

            } else {
                self.bannerView.isHidden = true
                self.bannerView.snp.updateConstraints { make in
                    make.height.equalTo(0)
                }
            }
            if let zoneSName = model.zoneSName, let time = model.createTime {
                timeLabel.text = "\(zoneSName) · \(time)"
            }
            let viewText = Utils.convertNumberText(count: model.views)
            self.viewButton.setTitle(viewText, for: .disabled)
            
        }
    }
    
    
    
 
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = .white
        
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func creartUI() {
        
        self.addSubview(bannerView)
        bannerView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(260)
        }
        
        self.addSubview(contentLabel)
        contentLabel.snp.makeConstraints { make in
            make.left.equalToSuperview().inset(28)
            make.width.equalTo(ScreenWidth - 56)
            make.top.equalTo(bannerView.snp.bottom).offset(16)
            make.bottom.equalToSuperview().offset(-58)
        }
        
        self.addSubview(timeLabel)
        timeLabel.snp.makeConstraints { make in
            make.left.equalTo(28)
            make.bottom.equalToSuperview().offset(-20)
        }
        
        self.addSubview(viewButton)
        viewButton.snp.makeConstraints { make in
            make.right.equalToSuperview().offset(-28)
            make.centerY.equalTo(timeLabel)
        }
        
        self.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(64)
            make.height.equalTo(1)
            make.bottom.equalToSuperview()
        }
        
    }

}
