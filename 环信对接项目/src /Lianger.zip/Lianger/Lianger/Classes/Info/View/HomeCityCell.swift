//
//  HomeCityCell.swift
//  Lianger
//
//  Created by Qidi on 2023/7/17.
//

import UIKit

class HomeCityCell: UITableViewCell {

    lazy var infoView: UIView = {
        let view = UIView()
        view.showCorner(8, borderWidth: 1, borderColor: UIColor.greyD0)
        return view
    }()
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSC(size: 14)
        label.numberOfLines = 3
        label.text = "Sunak remains the only one to have reached this number of backers, he will automatically become the Conservative Party’s new ..."
        return label
    }()
    
    lazy var rightImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = .gray
        return imageView
    }()
    
    lazy var iconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.showCorner(12)
        imageView.backgroundColor = .yellow
        return imageView
    }()
    lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCMedium(size: 12)
        label.text = "Name001name"
        return label
    }()
    
    lazy var areaLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSC(size: 10)
        label.text = "Area"
        return label
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var frame: CGRect {
        didSet {
            var newFrame = frame
            newFrame.origin.y += 8
            newFrame.size.height -= 8
            super.frame = newFrame
        }
    }
    
    
    func creartUI() {
        
        contentView.addSubview(infoView)
        infoView.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(20)
            make.top.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        infoView.addSubview(rightImageView)
        rightImageView.snp.makeConstraints { make in
            make.top.right.bottom.equalToSuperview()
            make.width.equalTo(134)
        }
        
        infoView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.left.equalTo(15)
            make.top.equalTo(14)
            make.right.lessThanOrEqualTo(rightImageView.snp.left).offset(-12)
        }
        
        infoView.addSubview(iconImageView)
        iconImageView.snp.makeConstraints { make in
            make.width.height.equalTo(24)
            make.left.equalTo(15)
            make.bottom.equalToSuperview().offset(-10)
        }
        infoView.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.top.equalTo(iconImageView)
            make.left.equalTo(iconImageView.snp.right).offset(8)
            make.right.lessThanOrEqualTo(rightImageView.snp.left).offset(-12)
            make.height.equalTo(10)
        }
        
        infoView.addSubview(areaLabel)
        areaLabel.snp.makeConstraints { make in
            make.left.equalTo(nameLabel)
            make.top.equalTo(nameLabel.snp.bottom)
            make.right.lessThanOrEqualTo(rightImageView.snp.left).offset(-12)
        }
        
    }
}
