//
//  SearchAuthorCell.swift
//  Lianger
//
//  Created by Qidi on 2023/7/19.
//

import UIKit

class SearchAuthorCell: UITableViewCell {

    lazy var iconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = UIColor.gray
        imageView.showCorner(15)
        imageView.image = UIImage(named: "me_defaut")!
        return imageView
    }()
    
    lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCBold(size: 17)
        label.text = "Name01"
        return label
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    
    private func creartUI() {
        
        contentView.addSubview(iconImageView)
        iconImageView.snp.makeConstraints { make in
            make.width.height.equalTo(45)
            make.centerY.equalToSuperview()
            make.left.equalTo(28)
        }
        
        contentView.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(iconImageView.snp.right).offset(15)
        }
    }
}
