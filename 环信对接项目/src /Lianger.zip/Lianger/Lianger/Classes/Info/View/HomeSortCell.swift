//
//  HomeSortCell.swift
//  Lianger
//
//  Created by Qidi on 2023/8/23.
//

import UIKit

class HomeSortCell: UITableViewCell {
    
    lazy var infoView: UIView = {
        let view = UIView()
        return view
    }()
    lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCMedium(size: 15)
        return label
    }()
    
    
    var model: CategoryModel? {
        didSet {
            guard let model = model else { return }
            nameLabel.text = model.chName
            if model.isChoose {
                self.infoView.showCorner(25, borderWidth: 0, borderColor: UIColor.clear)
                self.infoView.backgroundColor = UIColor.mainYellow
            } else {
                self.infoView.showCorner(25, borderWidth: 1, borderColor: UIColor.blackText)
                self.infoView.backgroundColor = UIColor.clear
            }
        }
    }
    

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private func creartUI() {
        contentView.addSubview(infoView)
        infoView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.right.equalToSuperview().inset(34)
            make.height.equalTo(50)
        }
        
        infoView.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(22)
            make.right.lessThanOrEqualToSuperview().offset(-22)
        }
        
    }
        
}
