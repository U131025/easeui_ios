//
//  ReplyInfoCell.swift
//  Lianger
//
//  Created by Qidi on 2023/7/24.
//

import UIKit

class ReplyInfoCell: UITableViewCell {

    lazy var iconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.showCorner(11)
        return imageView
    }()
    
    lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCBold(size: 14)
        return label
    }()
    
    lazy var timeLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSCMedium(size: 12)
        return label
    }()
    lazy var contentLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCMedium(size: 14)

        label.numberOfLines = 0
        return label
    }()
    
    var model: ArticleCommentModel? {
        didSet {
            guard let model = model else { return }
            contentLabel.text = model.content
            if let avatar = model.avatar {
                iconImageView.kf.setImage(with: URL(string: avatar),placeholder: UIImage(named: "me_defaut"))
            } else {
                iconImageView.image = UIImage(named: "me_defaut")
            }
            nameLabel.text = model.nickName
            timeLabel.text = model.createTime
            
        }
    }
    
    

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    
    private func creartUI() {
        
        contentView.addSubview(iconImageView)
        iconImageView.snp.makeConstraints { make in
            make.width.height.equalTo(22)
            make.left.equalTo(28)
            make.top.equalTo(14)
        }
        
        contentView.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.top.equalTo(8)
            make.left.equalTo(iconImageView.snp.right).offset(14)
        }
        contentView.addSubview(timeLabel)
        timeLabel.snp.makeConstraints { make in
            make.left.equalTo(nameLabel)
            make.top.equalTo(nameLabel.snp.bottom).offset(5)
        }
        contentView.addSubview(contentLabel)
        contentLabel.snp.makeConstraints { make in
            make.left.equalTo(nameLabel)
            make.right.equalToSuperview().offset(-28)
            make.bottom.equalToSuperview().offset(-10)
            make.top.equalTo(timeLabel.snp.bottom).offset(10)
        }
    }

}
