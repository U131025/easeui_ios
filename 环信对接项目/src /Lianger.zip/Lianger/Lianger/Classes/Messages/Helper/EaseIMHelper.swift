//
//  HxUserHelper.swift
//  Lianger
//
//  Created by 屋联-神兽 on 2023/9/27.
//

import Foundation
import HyphenateChat
import EaseIMKit
import MCToast

extension EMUserInfo: EaseUserDelegate {
    public var easeId: String {
        return userId ?? ""
    }
    public var showName: String {
        return nickname ?? userId ?? ""
    }
    
    public var avatarURL: String {
        return avatarUrl ?? ""
    }
    public var defaultAvatar: UIImage {
        return UIImage(named: "me_defaut")!
    }
}

class EaseIMHelper:NSObject, EMChatManagerDelegate, EMLocalNotificationDelegate, UNUserNotificationCenterDelegate {
    static let shared = EaseIMHelper()
    var hxUserDic: [String: EMUserInfo] = [:]
    
    override init() {
        super.init()
    }
    
    func initSDK() {
        let options = EMOptions(appkey: "1148230911209666#lianger")
        #if DEBUG
        options.apnsCertName = "lianger_dev"
        #else
        options.apnsCertName = "lianger_pro"
        #endif
        EMClient.shared().initializeSDK(with: options)
        
        print("EMClient version: \(EMClient.shared().version)")
        
        listen()
    }
    
    func listen() {
        EMClient.shared().chatManager?.add(self, delegateQueue: nil)
        EMLocalNotificationManager.shared().launch(with: self)
    }
    
    func login() {
        if let hxUser = HXUserModel.recover(), let userName = hxUser.hxUserName, let token = hxUser.hxUserToken {
            
            EMClient.shared().login(withUsername: userName, token: token) { name, error in
                
                if let errorStr = error?.description {
                    MCToast.mc_text(errorStr)
                }
                print("hxUserName: \(name)")
                
                // 推送设置
                EMClient.shared().pushManager?.update(.simpleBanner)
                
                EaseIMHelper.shared.updateUnReadCount()
            }
        }
        
        self.registerApns()
    }
    
    func registerApns() {
        
        let notifiCenter = UNUserNotificationCenter.current()
        notifiCenter.delegate = self
        notifiCenter.requestAuthorization(options: [.alert,.sound,.badge]) { (accepted, error) in
            if accepted {
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            }
        }
    }
    
    func getUserInfo(_ id: String) -> EMUserInfo {
        return hxUserDic[id] ?? EMUserInfo().then { obj in
            obj.userId = id
        }
    }
    
    func syncUserInfo(complete: @escaping () -> Void) {
        
        var ids: [String] = []
        let allConv: [EMConversation] = EMClient.shared().chatManager?.getAllConversations() ?? []
        for conv in allConv {
            ids.append(conv.conversationId)
        }
        
        EMClient.shared().userInfoManager?.fetchUserInfo(byId: ids, completion: { userDatas, error in
            if let error = error?.errorDescription {
                print(error)
            } else if let userDatas = userDatas {
                let keys = userDatas.keys
                for keyword in keys {
                    if let keyword = keyword as? String, let obj = userDatas[keyword] as? EMUserInfo {
                        self.hxUserDic[keyword] = obj
                    }
                }
            }
            
            complete()
        })
    }
    
    func readAllMessage(complete: @escaping () -> Void) {
        MCToast.mc_loading()        
        let allConv: [EMConversation] = EMClient.shared().chatManager?.getAllConversations() ?? []
        for conv in allConv where conv.unreadMessagesCount > 0 {
                        
            conv.markAllMessages(asRead: nil)
            
            EMClient.shared().chatManager?.ackConversationRead(conv.conversationId, completion: { error in
                if let error = error?.errorDescription {
                    print(error)
                }
            })
        }
        DispatchQueue.main.async {
            MCToast.mc_remove()
        }
        complete()
    }
    
    func updateUnReadCount() {
        if let app = UIApplication.shared.delegate as? AppDelegate, let tabbarVc: BaseTabBarController = app.window?.rootViewController as? BaseTabBarController {
            tabbarVc.updateUnReadCount()
        }
    }
    
    // EMChatManagerDelegate
    func messagesDidReceive(_ aMessages: [EMChatMessage]) {
        updateUnReadCount()
    }
    
    //EMLocalNotificationDelegate
    
    // UNUserNotificationCenterDelegate
    func userNotificationCenter(_ center: UNUserNotificationCenter,  willPresent notification: UNNotification, withCompletionHandler   completionHandler: @escaping (_ options:   UNNotificationPresentationOptions) -> Void) {
        print("Handle push from foreground")
        
//        let dic = notification.request.content.userInfo
//        let apsDic = dic["aps"] as? [String:Any]
       
//        let alert = apsDic?["alert"] as! [String:Any]
//        let body = alert["body"] as! String
//        let title = alert["title"] as! String
        
//        self.presentAlertVc(confirmBtn: nil, message: body, title: title, cancelBtn: "好的")
        print("\(notification.request.content.userInfo)")
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print("Handle push from background or closed")
        // if you set a member variable in didReceiveRemoteNotification, you  will know if this is from closed or background
        print("\(response.notification.request.content.userInfo)")
    }
}
