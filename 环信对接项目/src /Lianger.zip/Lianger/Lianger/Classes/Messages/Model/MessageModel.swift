//
//  MessageModel.swift
//  Lianger
//
//  Created by Qidi on 2023/9/4.
//

import UIKit

class MessageModel: BaseModel {

    //频道ID
    var channel_id: String?
    //频道类型 1.单聊 2.群聊 3.客服
    var channel_type: Int = 0
    //消息未读数量
    var unread: Int = 0
    //10位到秒的时间戳
    var timestamp: Double = 0
    //最后一条消息的message_seq
    var last_msg_seq: Int = 0
    //最后一条消息的客户端消息编号
    var last_client_msg_no: String?
    //
    var offset_msg_seq: Int = 0
    //数据版本编号
    var version: Int?
    //最近N条消息
    var recents: [RecentsMessageModel] = []
    //对话对象
    var user: MessageUserModel = MessageUserModel()
}

class MessageUserModel: BaseModel {
    //消息对象昵称
    var nick_name: String?
    //消息对象头像
    var avatar: String?
}

class RecentsMessageModel: BaseModel {
    
    //消息设置 消息设置是一个 uint8的数字类型 为1个字节，完全由第三方自定义 比如定义第8位为已读未读回执标记，开启则为0000 0001 = 1
    var setting: Int?
    //消息全局唯一ID
    var message_id: String?
    //客户端定义的消息编号(一般为32位的uuid)
    var client_msg_no: Int?
    //消息序列号 （频道唯一，有序递增）
    var message_seq: Int = 0
    //数据版本编号
    var from_uid: String?
    //数据版本编号
    var channel_id: String?
    //频道类型 1.个人频道 2.群频道
    var channel_type: Int = 0
    //数据版本编号
    var timestamp: Int?
    //base64编码的消息内容
    var payload: String?
    //消息头
    var header: MessageHeaderModel?
    //消息内容
    var content: String {
        guard let value = self.payload else { return "" }
        guard let decodedData = Data(base64Encoded: value,options: NSData.Base64DecodingOptions.ignoreUnknownCharacters) else { return  ""}
        
        do {
            let dic: [String : Any] = try JSONSerialization.jsonObject(with: decodedData, options: .mutableContainers) as? [String : Any] ?? ["content" : ""]
            if let text = dic["content"] as? String {
                return text
            } else {
                return ""
            }
        } catch {
            return ""
        }
    }
    
}

class MessageHeaderModel: BaseModel {
    //是否不存储消息 0.存储 1.不存储
    var no_persist: Int = 0
    //是否显示红点计数，0.不显示 1.显示
    var red_dot: Int = 0
    //是否是写扩散，这里一般是0，只有cmd消息才是1
    var sync_once: Int = 0
    
}

class ChatDataModel: BaseModel {
    
    var more: Int = 0
    //是否是写扩散，这里一般是0，只有cmd消息才是1
    var end_message_seq: Int = 0
    //
    var messages: [ChatMessageModel] = []
    
}

class ChatMessageModel: BaseModel {
    
    var header:MessageHeaderModel = MessageHeaderModel()
    //
    var client_msg_no: String = ""
    //
    var message_idstr: String?
    //
    var payload: String?
    //
    var channel_type: Int = 0
    //
    var setting: Int = 0
    //
    var channel_id: String = ""
    //
    var message_id: String?
    //
    var timestamp: Int = 0
    //
    var from_uid: String = ""
    var to_uid: String = ""

    //
    var message_seq: Int?

    //消息内容
    var content: String {
        guard let value = self.payload else { return "" }
        guard let decodedData = Data(base64Encoded: value,options: NSData.Base64DecodingOptions.ignoreUnknownCharacters) else { return  ""}
        
        do {
            let dic: [String : Any] = try JSONSerialization.jsonObject(with: decodedData, options: .mutableContainers) as? [String : Any] ?? ["content" : ""]
            if let text = dic["content"] as? String {
                return text
            } else {
                return ""
            }
        } catch {
            return ""
        }
    }
   
}

class ChannelMessageModel: BaseModel {
    
    //
    var start_message_seq: UInt32 = 0
    //
    var end_message_seq: UInt32 = 0
    //
    var messages: [ChatMessageModel] = []
    //
    var more: Int = 0
}
