//
//  MessageViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/7.
//

import UIKit

class MessageViewController: BaseViewController {

    private var dataArray: [MessageModel] = []
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.contentInsetAdjustmentBehavior = .never
        self.placeholdView.title = "No Message"
        self.placeholdView.placeType(.nodata)
        tableView.backgroundView = self.placeholdView
        tableView.backgroundView?.isHidden = true
        tableView.register(MessageListCell.self, forCellReuseIdentifier: "MessageListCell")
        return tableView
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Messages"
        
        self.creatUI()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.loadData()
        let app:AppDelegate! = (UIApplication.shared.delegate as! AppDelegate)
        if  let tabbarVc: BaseTabBarController = app.window?.rootViewController as? BaseTabBarController {
            tabbarVc.redView.isHidden = true
        }
    }
    
    
    override func loadData() {
        let params = ["version": 0,"msgCount" : 10]
        self.dataArray.removeAll()
        ApiManager.getMessageConversation(params: params) { list, errorMsg in
            if list != nil {
                self.dataArray = list!
            } else {
            }
            self.tableView.reloadData()
        }
    }
    
    @objc func redAllAction() {
        
    }
    
    
    private func creatUI() {
        
        let redButton = UIButton(type: .custom)
        redButton.setTitle("All read", for: .normal)
        redButton.setTitleColor(UIColor.blackText, for: .normal)
        redButton.titleLabel?.font = UIFont.PingFangSCMedium(size: 17)
        redButton.setImage(UIImage(named: ""), for: .normal)
        redButton.addTarget(self, action: #selector(redAllAction), for: .touchUpInside)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: redButton)
        
        self.showLine()
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(1)
        }
    }
    

  

}


extension MessageViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: MessageListCell = tableView.dequeueReusableCell(withIdentifier: "MessageListCell") as! MessageListCell
        
        if self.dataArray.count > indexPath.row {
            cell.model = self.dataArray[indexPath.row]
        }
        return cell
    }
    
 
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.dataArray.count > indexPath.row {
            let model = self.dataArray[indexPath.row]
            let chatVc = ChatViewController()
            chatVc.chatName = model.user.nick_name ?? ""
            chatVc.chatUserId = model.channel_id!
            chatVc.chatUserAvatar = model.user.avatar
            self.navigationController?.pushViewController(chatVc, animated: true)
        }
       
    }
    
}
