//
//  EMChatViewController.swift
//  Lianger
//
//  Created by 屋联-神兽 on 2023/9/16.
//

import UIKit
import SwiftyUserDefaults
import MCToast
import IQKeyboardManagerSwift
import HyphenateChat
import EaseIMKit
import LEEAlert
import RZColorfulSwift

extension ArticleDetailModel: EaseUserDelegate {
        
    var easeId: String {
        return hxUserName ?? ""
    }
    var showName: String {
        return userName ?? ""
    }
    var avatarURL: String {
        return avatar ?? ""
    }
    var defaultAvatar: UIImage {
        return UIImage(named: "me_defaut")!
    }
}

extension UserInfoModel: EaseUserDelegate {
    var easeId: String {
        return hxUserName ?? ""
    }
    var showName: String {
        return nickName ?? ""
    }
    var avatarURL: String {
        return avatar ?? ""
    }
    var defaultAvatar: UIImage {
        return UIImage(named: "me_defaut")!
    }
}

extension UserModel : EaseUserDelegate {
    var easeId: String {
        return hxUserName ?? ""
    }
    var showName: String {
        return nickName ?? ""
    }
    var avatarURL: String {
        return avatar ?? ""
    }
    var defaultAvatar: UIImage {
        return UIImage(named: "me_defaut")!
    }
}

class EMChatViewController: BaseViewController, EaseChatViewControllerDelegate, EaseMessageCellDelegate {
    
    var conversationId: String?
    var chatController: EaseChatViewController?
    var conversation: EMConversation?
    var conversationModel: EaseConversationModel?
    var moreMsgId: String?
    var viewModel = EaseChatViewModel()
    
    var article: ArticleDetailModel? // 文章聊天对象
    var userModel: UserModel? // 聊天对象
    var emUserInfo: EMUserInfo? // 聊天对象
    
    let toolBar = EMChatToolBar()
    
    func getUserName() -> String? {
        return article?.showName ?? userModel?.showName ?? emUserInfo?.showName
    }
    
    convenience init(conversationId: String, conversationType: EMConversationType = .chat, article: ArticleDetailModel? = nil) {
        self.init()
        self.conversationId = conversationId
        self.article = article
        self.conversation = EMClient.shared().chatManager?.getConversation(conversationId, type: conversationType, createIfNotExist: true)
        
        if let conversation = self.conversation {
            self.conversationModel = EaseConversationModel.init(conversation: conversation)
        }
        
//        let viewModel = EaseChatViewModel()
        self.viewModel.receiveBubbleBgPicture = UIImage(named: "chat_receive_em")!
        self.viewModel.sendBubbleBgPicture = UIImage(named: "chat_send_em")!
        self.viewModel.avatarStyle = .Circular
        self.viewModel.inputBarStyle = .custom
        self.viewModel.chatBarBgColor = .white
        self.viewModel.chatBarLeftButtonImage = UIImage(named: "icon_image")!
        self.viewModel.chatBarRightButtonImage = UIImage(named: "icon_send")!
        self.viewModel.inputBgColor = UIColor.greyF2
        self.viewModel.defaultAvatarPicture = UIImage(named: "me_defaut")!
        
        self.chatController = EaseChatViewController.initWithConversationId(conversationId, conversationType: conversationType, chatViewModel: viewModel)
        
        self.chatController?.setEditingStatusVisible(false)
        self.chatController?.delegate = self
                
        self.loadData(true)
        
        // 设置已读
        if let conversation = self.conversation, conversation.unreadMessagesCount > 0 {
            
            conversation.markAllMessages(asRead: nil)
            
//            EMClient.shared().chatManager?.ackConversationRead(conversation.conversationId, completion: { error in
//                if let error = error?.errorDescription {
//                    print(error)
//                }
//            })
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if let chatVC = chatController {
            addChild(chatVC)
            view.addSubview(chatVC.view)
            chatVC.view.snp.makeConstraints { make in
                make.edges.equalToSuperview()
            }
        }
        
        showSendLinkAlert()
        
        title = getUserName() ?? self.conversationModel?.showName
    }
    
    func loadData(_ isScrollBottom: Bool) {
        guard let conversation = conversation else {
            return
        }
       
        conversation.loadMessagesStart(fromId: moreMsgId, count: 10, searchDirection: .up) {[weak self] aMessages, error in
            
            DispatchQueue.main.async {
                if let messages = aMessages {
                    self?.chatController?.refreshTableView(withData: messages, isInsertBottom: false, isScrollBottom: isScrollBottom)
                }
            }
        }
    }
    
    func loadMoreMessageData(_ firstMessageId: String, currentMessageList messageList: [EMChatMessage]) {
        
        moreMsgId = firstMessageId
        loadData(true)
    }

    // MARK: EaseChatViewControllerDelegate
    func cell(forItem tableView: UITableView, messageModel: EaseMessageModel) -> UITableViewCell? {
        
        if messageModel.direction == .receive {
            if let article = article {
                messageModel.userDataDelegate = article
            }
            if let userModel = userModel {
                messageModel.userDataDelegate = userModel
            }
            if let userModel = emUserInfo {
                messageModel.userDataDelegate = userModel
            }
        } else {
            messageModel.userDataDelegate = UserInfoModel.shared
        }
        
        if messageModel.type != .custom {
            return nil
        }

        let cell = EMChatLinkMessageCell.init(direction: messageModel.direction, chatType: .chat, messageType: messageModel.type, viewModel: viewModel)
        cell.model = messageModel
        cell.delegate = self

        return cell
    }
    
    // EaseMessageCellDelegate
    func messageCellDidSelected(_ aCell: EaseMessageCell) {
        if let body = aCell.model.message.body as? EMCustomMessageBody {
           
            if let id = body.customExt["id"] {
                // 跳转到文章详情
                let nextVc = ArticleDetailViewController()
                nextVc.articleId = id
                self.navigationController?.pushViewController(nextVc, animated: true)
            }
        }
    }
    
    func errorEventNotfiy(_ error: EMError) {
        MCToast.mc_text(error.errorDescription)
    }
    
    // Link
    func showSendLinkAlert() {
        guard let article = self.article else {
            return
        }
        
        let label = UILabel()
        label.numberOfLines = 2
        label.rz.colorfulConfer { confer in
            confer.text(article.content)?.font(.PingFangSC(size: 13)).textColor(.hexColor(hex: 0x569900))
                .underlineStyle(NSUnderlineStyle.single)
        }

        let size = label.sizeThatFits(CGSize(width: ScreenWidth - 80, height: CGFloat(MAXFLOAT)))
        label.frame = CGRect(origin: .zero, size: size)

        let offsetY = (ScreenHeight - size.height - 80) / 2 - 130

        let alert = LEEAlert.alert()
        _ = alert.config
            .leeCustomView(label)
            .leeAlertCenterOffset(CGPoint(x: 0, y: offsetY))
            .leeMaxWidth(ScreenWidth - 40)
            .leeHeaderColor(.white)
            .leeCornerRadius(8)
            .leeBackgroundStyleTranslucent(0)
            .leeCloseAnimationStyle(.fade)
            .leePresentation(LEEPresentation.viewController(self))
            .leeAddAction({ action in
                action.title = "Cancel"
                action.type = .default
                action.borderColor = UIColor.black
                action.borderWidth = 1
                action.backgroundColor = .white
                action.titleColor = .black
                action.insets = UIEdgeInsets(top: 10, left: 30, bottom: 16, right: 15)
                action.cornerRadius = 4
                action.height = 42
                action.borderPosition = [.top, .bottom, .left, .right]
            })
            .leeAddAction({ action in
                action.title = "Send Link"
                action.type = .default
                action.borderColor = UIColor.black
                action.backgroundColor = .black
                action.titleColor = .white
                action.insets = UIEdgeInsets(top: 10, left: 15, bottom: 16, right: 30)
                action.cornerRadius = 4
                action.height = 42

                action.clickBlock = {[weak self] in
                    self?.sendArticle(article)
                }
            })
            .leeShow()
    }
    
    func sendArticle(_ article: ArticleDetailModel) {
                
        let body = EMCustomMessageBody(event: "article", customExt: ["content": article.content ?? "", "id": article.articleId ?? ""])
        chatController?.sendMessage(with: body, ext: nil)
    }
    
    func sendLink(_ linkStr: String) {
       
        let body = EMTextMessageBody(text: linkStr)
        chatController?.sendMessage(with: body, ext: nil)
    }
}
