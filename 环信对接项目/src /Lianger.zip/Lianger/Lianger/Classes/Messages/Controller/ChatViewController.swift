//
//  ChatViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/25.
//

import UIKit
import SwiftyUserDefaults
import MCToast
import IQKeyboardManagerSwift
import HyphenateChat
import EaseIMKit

class ChatViewController: BaseViewController {

    var chatName: String = ""
    var chatUserId: String = ""
    var chatUserAvatar: String?
 
    private let limit:Int32 = 20

    private lazy var bottomTool: MeesageToolView = {
        let view = MeesageToolView(frame: .zero)
        view.isChat = true
        view.sendDataBlock = { [weak self] in
            self?.chooseImage()
        }
        return view
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = UIColor.greyE6
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.register(ChatCell.self, forCellReuseIdentifier: "ChatCell")
        tableView.uHead = URefreshNormalHeader.init(refreshingBlock: { [weak self] in
        })
        tableView.uFoot = URefreshFooter.init(refreshingBlock: { [weak self] in
        })
        tableView.uFoot.isHidden = true
        return tableView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = self.chatName
        self.creatUI()
                  
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        IQKeyboardManager.shared.enable = false
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        IQKeyboardManager.shared.enable = true
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    
    // MARK:  网络数据
    
    override func loadData() {
        
    }
      
    

    

    
    private func sendTextMessage(_ text: String) {
        if text.isBlank == true { return }
        
    
    }
    private func sendImageMessage(_ image: UIImage) {

    }
    
   
    private func scrollToBttom() {
 
    }
    
    private func chooseImage() {
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        cameraPicker.sourceType = .photoLibrary
        self.present(cameraPicker, animated: true, completion: nil)
    }
    

    
    // MARK:  UI
    private func creatUI() {
        self.view.addSubview(bottomTool)
        bottomTool.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
        }
        bottomTool.sendMessageBlock = { [weak self] text in
            guard let wSelf = self else { return  }
            wSelf.sendTextMessage(text)
        }
        
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview()
            make.bottom.equalTo(bottomTool.snp.top)
        }
    }
    
    

}
extension ChatViewController {
    
    @objc private func keyboardWillShow(_ notification: Notification) {
        self.handleKeyboardNotification(notification, isShow: true)
    }
    @objc private func keyboardWillHide(_ notification: Notification) {
        self.handleKeyboardNotification(notification, isShow: false)

    }
    private func handleKeyboardNotification(_ notification: Notification,isShow: Bool) {
        
        if let info = notification.userInfo {
            let animationDuration = info[UIResponder.keyboardAnimationDurationUserInfoKey] as? TimeInterval ?? 0.25
            if let kbFrame = info[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
                if isShow {
                    UIView.animate(withDuration: animationDuration) {
                        self.bottomTool.snp.updateConstraints { make in
                            make.bottom.equalToSuperview().offset(-kbFrame.height)
                        }
                    } completion: { _ in
                        self.scrollToBttom()
                    }
                } else {
                    UIView.animate(withDuration: animationDuration) {
                        self.bottomTool.snp.updateConstraints { make in
                            make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
                        }
                    } completion: { _ in
                        self.scrollToBttom()
                    }
                }
            }
        }
    }
    
    
}



extension ChatViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell: ChatCell = tableView.dequeueReusableCell(withIdentifier: "ChatCell") as! ChatCell

        return cell
    }
    
 
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
       
    }
    
}




extension ChatViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)

        let image = info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.originalImage)] as! UIImage
        self.sendImageMessage(image)
        picker.dismiss(animated: true, completion: nil)
       
    }
}
fileprivate func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
    return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromUIImagePickerControllerInfoKey(_ input: UIImagePickerController.InfoKey) -> String {
    return input.rawValue
}


