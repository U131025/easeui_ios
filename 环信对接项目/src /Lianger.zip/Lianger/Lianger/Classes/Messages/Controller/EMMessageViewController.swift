//
//  EMMessageViewController.swift
//  Lianger
//
//  Created by 屋联-神兽 on 2023/9/17.
//

import UIKit
import HyphenateChat
import EaseIMKit
import Then
import MCToast

class EMMessageViewController: BaseViewController, EaseConversationsViewControllerDelegate {
    
    let viewModel = EaseConversationViewModel().then { vm in
        vm.canRefresh = true
        vm.badgeLabelPosition = .avatarTopRight
        vm.avatarSize = CGSize(width: 70, height: 70)
    }
    lazy var easeConvsVC = EaseConversationsViewController(model: viewModel)

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.loadData()
        self.updateUnReadCount()
                
        EaseIMHelper.shared.syncUserInfo(complete: { [weak self] in
            self?.easeConvsVC.refreshTabView()
        })
    }
    
    func updateUnReadCount() {
        EaseIMHelper.shared.updateUnReadCount()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.title = "Messages"
        
        let redButton = UIButton(type: .custom)
        redButton.setTitle("All read", for: .normal)
        redButton.setTitleColor(UIColor.blackText, for: .normal)
        redButton.titleLabel?.font = UIFont.PingFangSCMedium(size: 17)
        redButton.setImage(UIImage(named: ""), for: .normal)
        redButton.addTarget(self, action: #selector(redAllAction), for: .touchUpInside)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: redButton)
        
        self.showLine()
        
        addChild(easeConvsVC)
        easeConvsVC.delegate = self
        view.addSubview(easeConvsVC.view)
        easeConvsVC.view.snp.makeConstraints { make in
            make.left.right.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(1)
        }
       
        _ = NotificationCenter.default.rx
            .notification(Notification.Name(rawValue: CONVERSATIONLIST_UPDATE))
            .take(until: rx.deallocated)
            .subscribe(onNext: {[weak self] _ in
                self?.updateUnReadCount()
            })
        
        _ = NotificationCenter.default.rx
            .notification(Notification.Name(rawValue: ACCOUNT_LOGIN_CHANGED))
            .take(until: rx.deallocated)
            .subscribe(onNext: {[weak self] _ in
                self?.updateUnReadCount()
            })
    }
    
    @objc func redAllAction() {
        // 一键已读
        EaseIMHelper.shared.readAllMessage {[weak self] in
            self?.easeConvsVC.refreshTable()
            self?.updateUnReadCount()
        }
    }
       
    // EaseConversationsViewControllerDelegate
    func easeTableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let identifier =  "EMMessageCell"
        var cell = tableView.dequeueReusableCell(withIdentifier: identifier) as? EMMessageCell
        if cell == nil {
            cell = EMMessageCell.init(style: .default, reuseIdentifier: identifier)
        }
        if let model = easeConvsVC.dataAry[indexPath.row] as? EaseConversationModel {
            cell?.convModel = model
        }
        return cell!
    }
    
    func easeTableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if let model = easeConvsVC.dataAry[indexPath.row] as? EaseConversationModel {
            
            let chatVC = EMChatViewController(conversationId: model.easeId)
            chatVC.emUserInfo = EaseIMHelper.shared.getUserInfo(model.easeId)
            self.navigationController?.pushViewController(chatVC, animated: true)
        }
    }
    
    func easeTableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    // 头像，昵称等数据
    func easeUserDelegate(atConversationId conversationId: String, conversationType type: EMConversationType) -> EaseUserDelegate {
        return EaseIMHelper.shared.getUserInfo(conversationId)
    }
}
