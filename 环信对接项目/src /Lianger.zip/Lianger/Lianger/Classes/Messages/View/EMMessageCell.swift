//
//  EMMessageCell.swift
//  Lianger
//
//  Created by 屋联-神兽 on 2023/9/17.
//

import Foundation
import EaseIMKit

class EMMessageCell: MessageListCell {
    
    var convModel: EaseConversationModel? {
        didSet {
            guard let convModel = convModel else { return }
            nameLabel.text = convModel.showName
            
            iconImageView.kf.setImage(with: URL(string: convModel.avatarURL),placeholder: UIImage(named: "me_defaut"))
           
            let date = Date(timeIntervalSince1970: TimeInterval(convModel.lastestUpdateTime/1000))
            if date.isToday()  {
                timeLabel.text = date.dateToFormatString(format: "HH:mm")
            } else {
                timeLabel.text = date.dateToFormatString(format: "MM-dd")
            }
                       
            self.msgLabel.attributedText = convModel.showInfo
            
            if convModel.unreadMessagesCount > 0 { //未读消息
                self.redView.isHidden = false
                self.msgLabel.snp.remakeConstraints { make in
                    make.left.equalTo(iconImageView.snp.right).offset(28)
                    make.bottom.equalTo(iconImageView).offset(-2)
                    make.right.equalToSuperview().offset(-99)
                }
                
            } else {
                self.redView.isHidden = true
                self.msgLabel.snp.remakeConstraints { make in
                    make.left.equalTo(iconImageView.snp.right).offset(15)
                    make.bottom.equalTo(iconImageView).offset(-2)
                    make.right.equalToSuperview().offset(-99)
                }
            }
        }
    }    
}
