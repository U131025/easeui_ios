//
//  MessageListCell.swift
//  Lianger
//
//  Created by Qidi on 2023/7/25.
//

import UIKit

class MessageListCell: UITableViewCell {

  
    lazy var iconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = UIColor.grey99
        imageView.showCorner(8)
        return imageView
    }()
    
    lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCBold(size: 17)
        label.textColor = UIColor.blackText
        return label
    }()
    
    lazy var msgLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCMedium(size: 13)
        return label
    }()
    
    lazy var timeLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.text = "12:03"
        return label
    }()
    lazy var redView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.red
        view.showCorner(3)
        return view
    }()
    
    var model: MessageModel? {
        didSet {
            guard let model = model else { return }
            self.nameLabel.text = model.user.nick_name
            if let avatar = model.user.avatar {
                iconImageView.kf.setImage(with: URL(string: avatar),placeholder: UIImage(named: "me_defaut"))
            } else {
                iconImageView.image = UIImage(named: "me_defaut")
            }
            let date = Date(timeIntervalSince1970: model.timestamp)
            if date.isToday()  {
                timeLabel.text = date.dateToFormatString(format: "HH:mm")
            } else {
                timeLabel.text = date.dateToFormatString(format: "MM-dd")
            }
            if model.recents.count > 0, let recents = model.recents.first {
                if recents.content.hasPrefix("http://3.104.87.77:9000") {
                    msgLabel.text = "[photo]"
                } else {
                    msgLabel.text = recents.content
                }
            }
            if model.unread > 0 { //未读消息
                self.redView.isHidden = false
                self.msgLabel.snp.remakeConstraints { make in
                    make.left.equalTo(iconImageView.snp.right).offset(28)
                    make.bottom.equalTo(iconImageView).offset(-2)
                    make.right.equalToSuperview().offset(-99)
                }
                
            } else {
                self.redView.isHidden = true
                self.msgLabel.snp.remakeConstraints { make in
                    make.left.equalTo(iconImageView.snp.right).offset(15)
                    make.bottom.equalTo(iconImageView).offset(-2)
                    make.right.equalToSuperview().offset(-99)
                }
            }
                    
        }
    }
    

   
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    private func creartUI() {
        
        contentView.addSubview(iconImageView)
        
        iconImageView.snp.makeConstraints { make in
            make.width.height.equalTo(45)
            make.centerY.equalToSuperview()
            make.left.equalTo(28)
        }
        
        contentView.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            
            make.left.equalTo(iconImageView.snp.right).offset(15)
            make.top.equalTo(iconImageView).offset(2)
            make.right.equalToSuperview().offset(-80)
        }
                
        contentView.addSubview(msgLabel)
        msgLabel.snp.makeConstraints { make in
            make.left.equalTo(iconImageView.snp.right).offset(15)
            make.bottom.equalTo(iconImageView).offset(-2)
            make.right.equalToSuperview().offset(-99)
        }
        
        contentView.addSubview(redView)
        redView.snp.makeConstraints { make in
            make.width.height.equalTo(6)
            make.centerY.equalTo(msgLabel)
            make.left.equalTo(nameLabel)
        }
        
        contentView.addSubview(timeLabel)
        timeLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-39)
        }
    } 
}
