//
//  EMChatLinkMessageCell.swift
//  Lianger
//
//  Created by 屋联-神兽 on 2023/9/18.
//

import Foundation
import EaseIMKit

class EMChatLinkMessageCell: EaseMessageCell {
    
    var content: String?
    var id: String?
    
    var viewModel: EaseChatViewModel?
    var messageType: EMMessageType?
    
    override init(direction aDirection: EMMessageDirection, chatType aChatType: EMChatType, messageType aMessageType: EMMessageType, viewModel: EaseChatViewModel) {
        self.viewModel = viewModel
        self.messageType = aMessageType
        super.init(direction: aDirection, chatType: aChatType, messageType: aMessageType, viewModel: viewModel)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
