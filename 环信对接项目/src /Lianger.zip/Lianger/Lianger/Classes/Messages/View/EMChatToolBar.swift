//
//  EMChatToolBar.swift
//  Lianger
//
//  Created by 屋联-神兽 on 2023/9/17.
//

import Foundation
import EaseIMKit

class EMChatToolBar: EMBaseChatBar {
    
    private lazy var emojiBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_emoji"), for: .normal)
        button.addTarget(self, action: #selector(sendDataAction), for: .touchUpInside)
        return button
    }()
    
    private lazy var sendBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_send"), for: .normal)
        button.backgroundColor = UIColor.mainYellow
        button.showCorner(8)
        button.addTarget(self, action: #selector(sendMessageAction), for: .touchUpInside)
        return button
    }()
    
    lazy var lineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.greyE6
        return view
    }()
    
    override func _setupSubviews() {
        
        backgroundColor = .systemYellow
        
        addSubview(emojiBtn)
        emojiBtn.snp.makeConstraints { make in
            make.width.height.equalTo(24)
            make.bottom.equalToSuperview().offset(-23)
            make.left.equalTo(15)
        }
        
        addSubview(textView)
        textView.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(56)
            make.right.equalToSuperview().offset(-93)
            make.centerY.equalToSuperview()
            make.height.equalTo(40)
            make.bottom.equalToSuperview().offset(-15)
        }
        
        addSubview(sendBtn)
        sendBtn.snp.makeConstraints { make in
            make.width.equalTo(68)
            make.height.equalTo(40)
            make.bottom.equalToSuperview().offset(-15)
            make.right.equalToSuperview().offset(-12)
        }
        addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(1)
        }
    }
    
    @objc func sendMessageAction() {
        
    }
    @objc func sendDataAction() {
        
    }
}
