//
//  ChatCell.swift
//  Lianger
//
//  Created by Qidi on 2023/7/25.
//

import UIKit


class ChatCell: UITableViewCell {

    
    lazy var avatarImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = UIColor.grey99
        imageView.showCorner(21)
        return imageView
    }()
    
    lazy var arrowImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    lazy var timeLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSCMedium(size: 14)
        return label
    }()
    lazy var contentLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 14)
        label.textColor = UIColor.blackText
        label.numberOfLines = 0
        return label
    }()
    
    lazy var msgImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    
    lazy var bubbleView: UIView = {
        let view = UIView()
        view.showCorner(8)
        return view
    }()
    
    var avatar: String?
    var showTime: Bool = false
    
//    var message: WKMessage? {
//        didSet {
//            guard let message = message else { return }
//            var top:CGFloat = 15.0
//            if self.showTime {
//                top = 55.0
//                contentView.addSubview(timeLabel)
//                timeLabel.snp.makeConstraints { make in
//                    make.centerX.equalToSuperview()
//                    make.height.equalTo(20)
//                    make.top.equalTo(10)
//                }
//                let date = Date(timeIntervalSince1970: Double(message.timestamp))
//                timeLabel.text = Date.messageDateConvertString(date)
//            } else {
//                timeLabel.removeFromSuperview()
//            }
//            if message.isSend() { //发送方
//                if let avatar = UserInfoModel.shared.avatar {
//                    avatarImageView.kf.setImage(with: URL(string: avatar),placeholder: UIImage(named: "me_defaut"))
//                } else {
//                    avatarImageView.image = UIImage(named: "me_defaut")
//                }
//                avatarImageView.snp.remakeConstraints { make in
//                    make.top.equalTo(top)
//                    make.right.equalToSuperview().offset(-12)
//                    make.width.height.equalTo(42)
//                }
//                arrowImageView.image = UIImage(named: "chat_send")
//
//                arrowImageView.snp.remakeConstraints { make in
//                    make.centerY.equalTo(avatarImageView)
//                    make.right.equalTo(avatarImageView.snp.left)
//                    make.width.equalTo(8)
//                    make.height.equalTo(10)
//                }
//                bubbleView.backgroundColor = UIColor.mainYellow
//                bubbleView.snp.remakeConstraints { make in
//                    make.top.equalTo(avatarImageView)
//                    make.right.equalTo(arrowImageView.snp.left)
//                    make.bottom.equalToSuperview().offset(-15)
//                    make.left.greaterThanOrEqualToSuperview().offset(104)
//                }
//
//            } else {
//                if let avatar = self.avatar {
//                    avatarImageView.kf.setImage(with: URL(string: avatar),placeholder: UIImage(named: "me_defaut"))
//                } else {
//                    avatarImageView.image = UIImage(named: "me_defaut")
//                }
//                avatarImageView.snp.remakeConstraints { make in
//                    make.top.equalTo(top)
//                    make.left.equalToSuperview().offset(12)
//                    make.width.height.equalTo(42)
//                }
//                arrowImageView.image = UIImage(named: "chat_receive")
//                arrowImageView.snp.remakeConstraints { make in
//                    make.centerY.equalTo(avatarImageView)
//                    make.left.equalTo(avatarImageView.snp.right)
//                    make.width.equalTo(8)
//                    make.height.equalTo(10)
//                }
//                bubbleView.backgroundColor = .white
//                bubbleView.snp.remakeConstraints { make in
//                    make.top.equalTo(avatarImageView)
//                    make.left.equalTo(arrowImageView.snp.right)
//                    make.bottom.equalToSuperview().offset(-15)
//                    make.right.lessThanOrEqualToSuperview().offset(-104)
//                }
//
//            }
//            bubbleView.subviews.forEach{ $0.removeFromSuperview() }
//            if message.content.isKind(of: WKTextContent.self) {
//                let textContent:WKTextContent = message.content as! WKTextContent
//
//                if let format = textContent.format,!format.isEmpty {
//                    self.contentLabel.removeFromSuperview()
//                    let arr = format.components(separatedBy: ",")
//                    if arr.count >= 3 {
//                        let originalImageW: Double = Double(arr[1])!
//                        let originalImageH: Double = Double(arr[2])!
//                        var imageW: CGFloat = 0
//                        var imageH: CGFloat = 0
//                        let maxWidth = ScreenWidth - 186
//                        if originalImageW > maxWidth {
//                            imageW = maxWidth
//                            imageH = maxWidth * originalImageH / originalImageW
//                        } else {
//                            imageW = originalImageW
//                            imageH = originalImageH
//                        }
//                        self.bubbleView.addSubview(self.msgImageView)
//                        self.msgImageView.snp.remakeConstraints { make in
//                            make.width.equalTo(imageW)
//                            make.height.equalTo(imageH)
//                            make.left.top.right.bottom.equalToSuperview().inset(10)
//                        }
//                        self.msgImageView.kf.setImage(with: URL(string: textContent.content))
//                    } else {
//                        self.bubbleView.addSubview(self.msgImageView)
//                        self.msgImageView.image = UIImage(named: "msg_image_fail")
//                        self.msgImageView.snp.remakeConstraints { make in
//                            make.width.equalTo(180)
//                            make.height.equalTo(180)
//                            make.left.top.right.bottom.equalToSuperview().inset(10)
//                        }
//                    }
//
//
//                } else {
//                    self.bubbleView.addSubview(self.contentLabel)
//                    self.msgImageView.removeFromSuperview()
//                    contentLabel.snp.remakeConstraints { make in
//                        make.left.right.equalToSuperview().inset(15)
//                        make.top.bottom.equalToSuperview().inset(18)
//                    }
//                    contentLabel.text = textContent.content
//                }
//
//            }
//        }
//    }
    

   
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = UIColor.clear
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func creartUI() {
        contentView.addSubview(avatarImageView)
        contentView.addSubview(arrowImageView)
        contentView.addSubview(bubbleView)
        
    }
    
    
    
    
    

}
