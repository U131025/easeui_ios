//
//  LinkAlertView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/27.
//

import UIKit

class LinkAlertView: UIView {
    
    lazy var lineLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.linkColor
        label.font = UIFont.PingFangSCMedium(size: 14)
        label.numberOfLines = 0
        return label
    }()
    
    lazy var cancelBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Cancel", for: .normal)
        button.setTitleColor(UIColor.blackText, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCMedium(size: 15)
        button.showCorner(4, borderWidth: 1, borderColor: UIColor.blackText)
        return button
    }()
    lazy var sendBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Send Link", for: .normal)
        button.setTitleColor(UIColor.white, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCMedium(size: 15)
        button.backgroundColor = UIColor.blackText
        button.showCorner(4)
        return button
    }()
    

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.showCorner(8)
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    private func creartUI() {
        
        self.addSubview(lineLabel)
        lineLabel.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview().inset(20)
            make.bottom.equalToSuperview().offset(-96)
        }
        let arrtText = NSMutableAttributedString(string: "https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&tn=62095104_17_oem_dg&wd=%E9%93%BE%E6%8E%A5%E7%A4%BA%rsv_sug4=6635")
        arrtText.addAttributes([.underlineStyle : 1,.underlineColor : UIColor.red], range: NSRange(location: 0, length: arrtText.length))
        
        lineLabel.attributedText = arrtText
        
        self.addSubview(cancelBtn)
        cancelBtn.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(30)
            make.height.equalTo(42)
            make.right.equalTo(self.snp.centerX).offset(-18)
            make.bottom.equalToSuperview().offset(-15)
        }
        
        self.addSubview(sendBtn)
        sendBtn.snp.makeConstraints { make in
            make.top.height.equalTo(cancelBtn)
            make.left.equalTo(cancelBtn.snp.right).offset(36)
            make.right.equalToSuperview().offset(-30)
        }
        
    }
}
