//
//  AboutUsItemView.swift
//  Lianger
//
//  Created by Qidi on 2023/8/11.
//

import UIKit

class AboutUsItemView: UIView {
    
    struct VM {
        var icon: String
        var title: String?
    }
    var didSeleteAction: (() ->Void)?
    private lazy var iconImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCMedium(size: 16)
        return label
    }()
    
    private lazy var rightIcon: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "arrow_right"))
        return imageView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = .clear
        self.showCorner(12, borderWidth: 1, borderColor: UIColor.greyD0)
        
        self.creartUI()
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapAction))
        
        self.addGestureRecognizer(tap)
        
    }
    
    @objc func tapAction() {
        self.didSeleteAction?()
    }
    
    var vm: VM? {
        didSet {
            guard let vm = vm else { return }
            iconImageView.image = UIImage(named: vm.icon)
            titleLabel.text = vm.title
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func creartUI() {
        self.addSubview(iconImageView)
        iconImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(16)
        }
        
        self.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(50)
        }
        
        self.addSubview(rightIcon)
        rightIcon.snp.makeConstraints { make in
            make.right.equalToSuperview().offset(-18)
            make.centerY.equalToSuperview()
        }
    }
    
    
}
