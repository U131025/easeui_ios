//
//  SystemMessageCell.swift
//  Lianger
//
//  Created by Qidi on 2023/7/29.
//

import UIKit

class SystemMessageCell: UITableViewCell {

    
    lazy var redView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.red
        view.showCorner(4)
        return view
    }()
  
    lazy var msgTitLaebl: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCBold(size: 17)
        label.textColor = UIColor.blackText
        label.numberOfLines = 2
        return label
    }()
//    lazy var msgLaebl: UILabel = {
//        let label = UILabel()
//        label.font = UIFont.PingFangSCMedium(size: 13)
//        label.textColor = UIColor.blackText
//        label.text = "The video appears to show some of..."
//        return label
//    }()
    
    lazy var timeLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.textColor = UIColor.blackText
        label.text = "15:35"
        label.numberOfLines = 2
        label.textAlignment = .center
        return label
    }()
    
    lazy var rightIcon: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "arrow_right"))
        return imageView
    }()
    
    var model: NoticeModel? {
        didSet {
            guard let model = model else { return }
            
            if model.status == 0 {
                self.redView.isHidden = false
                self.msgTitLaebl.snp.updateConstraints { make in
                    make.left.equalTo(46)
                }
                self.msgTitLaebl.textColor = UIColor.blackText
                
            } else {
                self.redView.isHidden = true
                self.msgTitLaebl.textColor = UIColor.grey99
                self.msgTitLaebl.snp.updateConstraints { make in
                    make.left.equalTo(22)
                }
            }
            if let date = Date.stringConvertDate(string: model.createTime) {
                if date.isToday() {
                    self.timeLabel.text = date.dateToFormatString(format: "HH:mm")
                } else {
                    self.timeLabel.text = model.createTime.replacingOccurrences(of: " ", with: "\n")
                }
            } else {
                self.timeLabel.text = ""
            }
            self.msgTitLaebl.text = model.noticeTitle
            
        }
    }
    

 
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    private func creartUI() {
        
        contentView.addSubview(redView)
        
        redView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(22)
            make.width.height.equalTo(8)
        }
        
        contentView.addSubview(msgTitLaebl)
        msgTitLaebl.snp.makeConstraints { make in
            make.left.equalTo(46)
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-135)
            
        }
        
//        contentView.addSubview(msgLaebl)
//
//        msgLaebl.snp.makeConstraints { make in
//            make.left.right.equalTo(msgTitLaebl)
//            make.top.equalTo(msgTitLaebl.snp.bottom).offset(10)
//        }
        
        contentView.addSubview(rightIcon)
        rightIcon.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-18)
            
        }
        
        contentView.addSubview(timeLabel)
        timeLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-35)
        }
        
    }

}
