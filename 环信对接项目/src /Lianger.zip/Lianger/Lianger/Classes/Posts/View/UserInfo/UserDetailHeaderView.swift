//
//  UserDetailHeaderView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/27.
//

import UIKit
import Kingfisher

class UserDetailHeaderView: UIView {
    
    var changeAvatarAction:(() -> Void)?

    lazy var iconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "me_defaut")
        return imageView
    }()
    
    lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCBold(size: 17)
        label.text = "Name01"
        return label
    }()
    lazy var suburbLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSCMedium(size: 14)
        label.text = "Suburb"
        return label
    }()
    
    lazy var editButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_edit"), for: .normal)
        button.addTarget(self, action: #selector(editAction), for: .touchUpInside)
        return button
    }()
   
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.creatUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func editAction() {
        self.changeAvatarAction?()
    }
    
    
    func updata() {
        if let avatar = UserInfoModel.shared.avatar {
            self.iconImageView.kf.setImage(with: URL(string: avatar),placeholder: UIImage(named: "me_defaut"))
        }
        self.nameLabel.text = UserInfoModel.shared.nickName
        self.suburbLabel.text = UserInfoModel.shared.zoneSName
    }
    
    private func creatUI()  {
        
        self.addSubview(iconImageView)
        iconImageView.snp.makeConstraints { make in
            make.left.equalTo(45)
            make.width.height.equalTo(80)
            make.top.equalTo(44)
        }
        self.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.left.equalTo(iconImageView.snp.right).offset(22)
            make.top.equalTo(iconImageView.snp.top).offset(20)
        }
        self.addSubview(suburbLabel)
        suburbLabel.snp.makeConstraints { make in
            make.left.equalTo(nameLabel)
            make.top.equalTo(nameLabel.snp.bottom).offset(4)
        }
        self.addSubview(editButton)
        editButton.snp.makeConstraints { make in
            make.width.height.equalTo(26)
            make.bottom.right.equalTo(iconImageView).offset(13)
        }
    }

}
