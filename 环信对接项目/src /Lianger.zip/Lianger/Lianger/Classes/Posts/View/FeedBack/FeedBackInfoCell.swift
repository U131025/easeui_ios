//
//  FeedBackInfoCell.swift
//  Lianger
//
//  Created by Qidi on 2023/7/28.
//

import UIKit

class FeedBackInfoCell: UITableViewCell {

    lazy var statusLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.textColor = UIColor.blackText
        label.text = "No reply"
        return label
    }()
    lazy var statusLine: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.hexColor(hex: 0xD9D9D9)
        return view
    }()
    
    lazy var timeLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.textColor = UIColor.grey99
        label.text = "20.Jan.2022 15:35"
        return label
    }()
    
    lazy var feedbackLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.textColor = UIColor.grey99
        label.numberOfLines = 0
        return label
    }()
    
    lazy var replyView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.greyF2
        return view
    }()
    lazy var replayLaebl: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCBold(size: 13)
        label.textColor = UIColor.blackText
        label.numberOfLines = 0
        return label
    }()
    lazy var replayTimeLaebl: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.textColor = UIColor.blackText
        label.text = "20.Jan.2022 15:35"
        return label
    }()
    
    
    var model: FeedBackModel? {
        didSet {
            guard let model = model else { return }
            
            if model.replyStatus == 0 {
                statusLabel.text = "No reply"
                statusLine.backgroundColor = UIColor.hexColor(hex: 0xD9D9D9)

            } else {
                statusLabel.text = "Replied"
                statusLine.backgroundColor = UIColor.mainYellow

            }
            timeLabel.text = model.createTime
            feedbackLabel.text = model.content
            
            if var replyContent = model.replyContent {
                self.replyView.isHidden = false
                let name = "Customer service reply: "
                replyContent = name + replyContent
                let arrtText = NSMutableAttributedString(string: replyContent)
                arrtText.addAttribute(.foregroundColor, value: UIColor.buttonYellow, range: NSRange(location: 0, length: name.count))
                self.replayLaebl.attributedText = arrtText
                self.replayTimeLaebl.text = model.replyTime
                self.replyView.snp.remakeConstraints { make in
                    make.left.right.equalToSuperview().inset(22)
                    make.top.equalTo(feedbackLabel.snp.bottom).offset(16)
                    make.bottom.lessThanOrEqualToSuperview().offset(-16)
                }
            } else {
                self.replyView.isHidden = true
                self.replyView.snp.remakeConstraints { make in
                    make.left.right.equalToSuperview().inset(22)
                    make.top.equalTo(feedbackLabel.snp.bottom).offset(16)
                    make.height.equalTo(0)
                }
            }
        }
    }

 
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    private func creartUI() {
        
        contentView.addSubview(statusLabel)
        statusLabel.snp.makeConstraints { make in
            make.left.equalTo(26)
            make.top.equalTo(16)
        }
        
        contentView.insertSubview(statusLine, belowSubview: statusLabel)
        statusLine.snp.makeConstraints { make in
            make.centerX.equalTo(statusLabel)
            make.width.equalTo(statusLabel).offset(8)
            make.height.equalTo(9)
            make.bottom.equalTo(statusLabel).offset(3)
        }
        
        contentView.addSubview(timeLabel)
        timeLabel.snp.makeConstraints { make in
            make.centerY.equalTo(statusLabel)
            make.right.equalToSuperview().offset(-40)
        }
        
        contentView.addSubview(feedbackLabel)
        feedbackLabel.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(22)
            make.top.equalToSuperview().offset(50)
            make.bottom.lessThanOrEqualToSuperview().offset(-16)
        }
        
        contentView.addSubview(replyView)
        replyView.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(22)
            make.top.equalTo(feedbackLabel.snp.bottom).offset(16)
            make.bottom.lessThanOrEqualToSuperview().offset(-16)
        }
        
        replyView.addSubview(replayLaebl)
        replayLaebl.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(20)
            make.top.equalTo(16)
        }
        
        replyView.addSubview(replayTimeLaebl)
        replayTimeLaebl.snp.makeConstraints { make in
            make.right.equalToSuperview().offset(-16)
            make.top.equalTo(replayLaebl.snp.bottom).offset(16)
            make.bottom.equalToSuperview().offset(-16)
        }
        
        
    }

}
