//
//  GiftListCell.swift
//  Lianger
//
//  Created by Qidi on 2023/8/23.
//

import UIKit

class GiftListCell: UITableViewCell {

    lazy var infoView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        view.showCorner(8, borderWidth: 1, borderColor: UIColor.greyD0)
        return view
    }()
    lazy var giftImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        return imageView
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCBold(size: 16)
        label.textColor = UIColor.blackText
        return label
    }()
    
    lazy var detailLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.textColor = UIColor.grey99
        label.numberOfLines = 2
        return label
    }()
    
    lazy var timeLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 14)
        label.textColor = UIColor.grey99
        return label
    }()
 
    
    var model: ColumnListModel? {
        didSet {
            guard let model = model else { return }
            if let pic = model.picture {
                giftImageView.kf.setImage(with: URL(string: pic))
                giftImageView.snp.updateConstraints { make in
                    make.height.equalTo(170)
                }
            } else{
                giftImageView.image = nil
                giftImageView.snp.updateConstraints { make in
                    make.height.equalTo(0)
                }
            }
            titleLabel.text = model.title
            detailLabel.text = model.subtitle
            
            if let createTime = model.createTime,let date = Date.stringConvertDate(string: createTime) {
                if date.isToday() {
                    self.timeLabel.text = date.dateToFormatString(format: "HH:mm")
                } else {
                    self.timeLabel.text = model.createTime
                }
            } else {
                self.timeLabel.text = ""
            }
        }
    }

 
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    private func creartUI() {
        
        contentView.addSubview(infoView)
        infoView.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(20)
            make.top.equalTo(16)
        }
        
        infoView.addSubview(giftImageView)
        giftImageView.snp.makeConstraints { make in
            make.left.top.right.equalToSuperview()
            make.height.equalTo(170)
        }
        
        infoView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(14)
            make.top.equalTo(giftImageView.snp.bottom)
            make.height.equalTo(35)
        }
        
        infoView.addSubview(detailLabel)
        detailLabel.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(14)
            make.top.equalTo(titleLabel.snp.bottom)
            make.bottom.equalToSuperview().offset(-10)
        }
        
        contentView.addSubview(timeLabel)
        timeLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(infoView.snp.bottom).offset(16)
            make.bottom.equalToSuperview()
        }
        
        
    }

}
