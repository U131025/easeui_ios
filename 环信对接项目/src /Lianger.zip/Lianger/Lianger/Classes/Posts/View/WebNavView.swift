//
//  WebNavView.swift
//  Lianger
//
//  Created by Qidi on 2023/9/4.
//

import UIKit

class WebNavView: UIView {

    lazy var backBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "nav_back"), for: .normal)
        button.addTarget(self, action: #selector(goBack), for: .touchUpInside)
        return button
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCSemibold(size: 17)
        label.textColor = UIColor.blackText
        label.numberOfLines = 0
        return label
    }()
    lazy var timeLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSCMedium(size: 13)
        return label
    }()
    
    lazy var statusLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.textColor = UIColor.blackText
        label.text = "Unread"
        return label
    }()
    lazy var statusLine: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.mainYellow
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.creatUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func goBack() {
        self.viewController().navigationController?.popViewController(animated: true)
    }
    
    
    func creatUI()  {
        
        self.addSubview(backBtn)
        backBtn.snp.makeConstraints { make in
            make.left.equalTo(16)
            make.width.height.equalTo(30)
            make.top.equalTo(7)
        }
        
        self.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.left.equalTo(50)
            make.right.equalToSuperview().offset(-16)
            make.top.equalTo(11)
        }
        
        self.addSubview(timeLabel)
        timeLabel.snp.makeConstraints { make in
            make.left.equalTo(50)
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
        }
        
        self.addSubview(statusLabel)
        statusLabel.snp.makeConstraints { make in
            make.right.equalToSuperview().offset(-50)
            make.centerY.equalTo(timeLabel)
        }
        
        self.insertSubview(statusLine, belowSubview: statusLabel)
        statusLine.snp.makeConstraints { make in
            make.centerX.equalTo(statusLabel)
            make.width.equalTo(statusLabel).offset(6)
            make.height.equalTo(9)
            make.bottom.equalTo(statusLabel).offset(3)
        }
        
    }

}
