//
//  AddWorksChooseCell.swift
//  Lianger
//
//  Created by Qidi on 2023/7/20.
//

import UIKit

class AddWorksChooseCell: UITableViewCell {
    lazy var iconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = UIColor.mainYellow
        imageView.showCorner(13.5)
        imageView.contentMode = .center
        return imageView
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 15)
        label.textColor = UIColor.grey99
        return label
    }()
    
    lazy var detailLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.buttonYellow
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.textAlignment = .right
        return label
    }()
    lazy var rightIcon: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "arrow_grey_down"))
        return imageView
    }()
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        if selected {
            titleLabel.textColor = UIColor.blackText
            rightIcon.image = UIImage(named: "arrow_down_black")
        } else {
            titleLabel.textColor = UIColor.grey99
            rightIcon.image = UIImage(named: "arrow_grey_down")
        }
    }
   
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    private func creartUI() {
        
        contentView.addSubview(iconImageView)
        iconImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.width.height.equalTo(27)
            make.left.equalTo(17)
        }
        contentView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(55)
        }
        
        contentView.addSubview(detailLabel)
        detailLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-52)
            make.left.greaterThanOrEqualTo(titleLabel.snp.right).offset(10)
        }
        contentView.addSubview(rightIcon)
        rightIcon.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-20)
        }
        
        
    }
}
