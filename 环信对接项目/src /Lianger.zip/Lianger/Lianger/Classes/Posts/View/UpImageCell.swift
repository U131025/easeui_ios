//
//  UpImageCell.swift
//  Lianger
//
//  Created by Qidi on 2023/7/20.
//

import UIKit

class UpImageCell: UICollectionViewCell {
    
    lazy var imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.showCorner(4)
        return imageView
    }()
    lazy var bgImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "add_image"))
        imageView.backgroundColor = UIColor.greyF2
        imageView.contentMode = .center
        imageView.showCorner(4)
        return imageView
    }()
    lazy var deleteButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_deleted_image"), for: .normal)
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.creatUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    private func creatUI()  {
        
        contentView.addSubview(bgImageView)
        bgImageView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        contentView.addSubview(imageView)
        imageView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        contentView.addSubview(deleteButton)
        deleteButton.snp.makeConstraints { make in
            make.width.height.equalTo(16)
            make.top.right.equalToSuperview()
        }
    }
    
}
