//
//  UserDetailCell.swift
//  Lianger
//
//  Created by Qidi on 2023/7/27.
//

import UIKit

class UserDetailCell: UITableViewCell {

    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 15)
        label.textColor = UIColor.blackText
        return label
    }()
    
    lazy var detailLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.buttonYellow
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.textAlignment = .right
        return label
    }()
    
    lazy var rightIcon: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "arrow_right"))
        return imageView
    }()
    lazy var bottomLine: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.greyE6
        return view
    }()
   
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    private func creartUI() {
        

        contentView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(45)
        }
        
        contentView.addSubview(rightIcon)
        rightIcon.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-45)
            make.width.equalTo(8)
        }
        
        contentView.addSubview(detailLabel)
        detailLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.greaterThanOrEqualTo(titleLabel.snp.right).offset(30)
            make.right.equalTo(rightIcon.snp.left).offset(-10)
        }
        
        contentView.addSubview(bottomLine)
        bottomLine.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(45)
            make.height.equalTo(1)
            make.bottom.equalToSuperview()
        }
        
    }

}
