//
//  AddressCell.swift
//  Lianger
//
//  Created by Qidi on 2023/7/28.
//

import UIKit

class AddressCell: UITableViewCell {

    lazy var infoView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.showCorner(8, borderWidth: 0.5, borderColor: UIColor.hexColor(hex: 0xD0D0D0))
        return view
    }()
    lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCBold(size: 17)
        label.textColor = UIColor.blackText
        label.text = "Name"
        return label
    }()
    
    lazy var phoneLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCMedium(size: 17)
        label.text = "13584685465"
        return label
    }()
    
    lazy var addressLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.text = "56 Darnley Street, Bradbrook, Victoria, Australia Bradbrook, Victoria, Australia,Darnley Stre..."
        label.numberOfLines = 2
        return label
    }()
    
    lazy var defaultLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.text = "Default"
        return label
    }()
    
    lazy var defaultLine: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.hexColor(hex: 0xDCFF4A)
        return view
    }()
    lazy var editButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "edit_address"), for: .normal)
        button.addTarget(self, action: #selector(editButtonAction(button:)), for: .touchUpInside)
        return button
    }()

    lazy var bottomLine: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.greyE6
        return view
    }()
   
    @objc func editButtonAction(button: UIButton) {
        
        let nextVc = EditAddressViewController()
        nextVc.addressModel = self.model
        nextVc.isEdit = true
        self.viewController().navigationController?.pushViewController(nextVc, animated: true)
        
    }
    
    override var frame: CGRect {
        didSet {
            var newFrame = frame
            newFrame.origin.y += 8
            newFrame.size.height -= 8
            super.frame = newFrame
        }
    }
    
    
    var model: UserAddressModel? {
        didSet {
            guard let model = model else { return }
            nameLabel.text = model.contactPerson
            phoneLabel.text = model.contactNumber
            if model.defaultStatus == 1 {
                self.defaultLine.isHidden = false
                self.defaultLabel.isHidden = false
                self.editButton.snp.remakeConstraints { make in
                    make.right.bottom.equalToSuperview().offset(-20)
                }
            } else {
                self.defaultLine.isHidden = true
                self.defaultLabel.isHidden = true
                self.editButton.snp.remakeConstraints { make in
                    make.right.equalToSuperview().offset(-20)
                    make.centerY.equalToSuperview()
                }
            }
            
            addressLabel.text = "\(model.zoneLName),\(model.zoneMName),\(model.zoneSName),\(model.detailedAddress)"
        }
    }
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    private func creartUI() {
     
        contentView.addSubview(infoView)
        infoView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        infoView.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.left.equalTo(12)
            make.top.equalTo(16)
    
        }
        infoView.addSubview(phoneLabel)
        phoneLabel.snp.makeConstraints { make in
            make.centerY.equalTo(nameLabel)
            make.left.equalTo(nameLabel.snp.right).offset(12)
            make.right.lessThanOrEqualToSuperview().offset(-80)
        }
        
        infoView.addSubview(addressLabel)
        
        addressLabel.snp.makeConstraints { make in
            make.left.equalTo(nameLabel)
            make.right.equalToSuperview().offset(-80)
            make.top.equalTo(40)
        }
        
        infoView.addSubview(editButton)
        editButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-18)
            make.right.equalToSuperview().offset(-20)
        }
        
        infoView.addSubview(defaultLabel)
        defaultLabel.snp.makeConstraints { make in
            make.centerY.equalTo(nameLabel)
            make.right.equalToSuperview().offset(-12)
        }
        
        infoView.insertSubview(defaultLine, belowSubview: defaultLabel)
        defaultLine.snp.makeConstraints { make in
            make.bottom.equalTo(defaultLabel).offset(4)
            make.width.equalTo(defaultLabel)
            make.height.equalTo(10)
            make.centerX.equalTo(defaultLabel)
        }
    }

}
