//
//  PostsNavView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/20.
//

import UIKit

class PostsNavView: UIView {

    var navButtonClickAction:((Int) -> Void)?
    
    var seleteBtn: UIButton!

    lazy var lineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black
        return view
    }()
    lazy var releaseBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_release"), for: .normal)
        button.tag = 14
        button.addTarget(self, action: #selector(navButtonClick(button:)), for: .touchUpInside)
        return button
    }()
    lazy var accountBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_account"), for: .normal)
        button.tag = 13
        button.addTarget(self, action: #selector(navButtonClick(button:)), for: .touchUpInside)
        button.showCorner(12)
        return button
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.creatUI()
        if let avatar = UserInfoModel.shared.avatar,avatar.isBlank == false {
            accountBtn.kf.setImage(with: URL(string: avatar), for: .normal,placeholder: UIImage(named: "icon_account"))
        } else {
            accountBtn.setImage(UIImage(named: "icon_account"), for: .normal)
        }
        
    }
    
    func userAcatarChange() {
        if let avatar = UserInfoModel.shared.avatar {
            accountBtn.kf.setImage(with: URL(string: avatar), for: .normal)
        } else {
            accountBtn.setImage(UIImage(named: "icon_account"), for: .normal)
        }
    }
  
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func creatUI()  {
        let titleArr = ["Home","Follow","Favorate"]
        let buttonH: CGFloat = 44
        var buttonWArr: [CGFloat] = []
        var buttonViewWidth = 30.0
        for title in titleArr {
            let width = title.getWidthWithFont(UIFont.systemFont(ofSize: 16, weight: .bold))
            buttonWArr.append(width)
            buttonViewWidth += width
        }
        let buttonView = UIView(frame: CGRect(x: (ScreenWidth - buttonViewWidth) / 2.0, y: 0, width: buttonViewWidth, height: 44))
        addSubview(buttonView)
        
        var buttonX = 0.0
        for i in 0..<titleArr.count {
            let button = UIButton.init(type: .custom)
            button.setTitle(titleArr[i], for: .normal)
            button.setTitleColor(UIColor.grey99, for: .normal)
            button.setTitleColor(UIColor.blackText, for: .disabled)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .bold)
            button.tag = 10 + i
            button.addTarget(self, action: #selector(navButtonClick(button:)), for: .touchUpInside)
            button.frame = CGRect(x: buttonX, y: 0, width: buttonWArr[i], height: buttonH)
            buttonX += buttonWArr[i] + 15.0
            buttonView.addSubview(button)
            if i == 0 {
                button.isEnabled = false
                seleteBtn = button
                lineView.frame = CGRect(x: 0, y: 35, width: button.width, height: 2)
                buttonView.addSubview(lineView)
            }
        }
        
        addSubview(releaseBtn)
        releaseBtn.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().offset(20)
        }
        addSubview(accountBtn)
        accountBtn.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-20)
            make.width.height.equalTo(24)
        }
        
    }
    
    
    
    @objc func navButtonClick(button: UIButton) {

        if button.tag < 13 {
            button.isEnabled = false
            seleteBtn.isEnabled = true
            seleteBtn = button
            self.lineView.isHidden = false
            UIView.animate(withDuration: 0.2) {
                self.lineView.frame = CGRect(x: button.frame.origin.x, y: 35, width: button.width, height: 2)
            }
        } else if button.tag == 13{

            seleteBtn.isEnabled = true
            self.lineView.isHidden = true
            seleteBtn = button

        }
        self.navButtonClickAction?(button.tag - 10)
    }

}
