//
//  UserInfoHeaderView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/20.
//

import UIKit

class UserInfoHeaderView: UIView {
    lazy var tapView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapUserIconAction))
        view.addGestureRecognizer(tap)
        return view
    }()

    lazy var iconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "me_defaut")
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCBold(size: 17)
        return label
    }()
    lazy var suburbLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSCMedium(size: 14)
        return label
    }()
   
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.creatUI()
        
    }
    
    func reloadData() {
        nameLabel.text = UserInfoModel.shared.nickName
        suburbLabel.text = UserInfoModel.shared.zoneSName
        
        if let avatar = UserInfoModel.shared.avatar {
            iconImageView.kf.setImage(with: URL(string: avatar),placeholder: UIImage(named: "me_defaut"))
        }
    }
    
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func tapUserIconAction() {
        let nextVc = UserDetailViewController()
        self.viewController().navigationController?.pushViewController(nextVc, animated: true)
    }
    
    
    private func creatUI()  {
        
        self.addSubview(iconImageView)
        iconImageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.width.height.equalTo(80)
            make.top.equalTo(30)
        }
        self.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(iconImageView.snp.bottom).offset(20)
            
        }
        self.addSubview(suburbLabel)
        suburbLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(nameLabel.snp.bottom).offset(4)
        }
        self.addSubview(tapView)
        tapView.snp.makeConstraints { make in
            make.width.height.equalTo(200)
            make.center.equalToSuperview()
        }
    }

}
