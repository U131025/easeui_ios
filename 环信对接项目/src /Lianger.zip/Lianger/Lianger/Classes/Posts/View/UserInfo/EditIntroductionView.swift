//
//  EditIntroductionView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/28.
//

import UIKit
import QMUIKit

class EditIntroductionView: UIView,QMUITextViewDelegate {
    
    var buttonClickBlock:((String?) -> Void)?
     

    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Introduction"
        label.font = UIFont.PingFangSCMedium(size: 23)
        label.textColor = UIColor.blackText
        return label
    }()
    lazy var countLabel: UILabel = {
        let label = UILabel()
        label.text = "0/500"
        label.font = UIFont.PingFangSCMedium(size: 13)
        label.textColor = UIColor.grey99
        return label
    }()
    
    lazy var textView: QMUITextView = {
        let textView = QMUITextView(frame: .zero)
        textView.tintColor = UIColor.inputTintColor
        textView.font = UIFont.PingFangSCMedium(size: 16)
        textView.placeholder = "Please put in Personal Introduction"
        textView.placeholderColor = UIColor.placeholdColor
        textView.delegate = self
        return textView
    }()
    
    private lazy var comfirmBtn: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("Save", for: .normal)
        button.setTitleColor(UIColor.buttonYellow, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 15)
        button.tag = 10
        button.addTarget(self, action: #selector(buttonClick(button:)), for: .touchUpInside)
        return button
    }()
    private lazy var cancelBtn: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("Cancel", for: .normal)
        button.setTitleColor(UIColor.grey99, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 15)
        button.tag = 20
        button.addTarget(self, action: #selector(buttonClick(button:)), for: .touchUpInside)
        return button
    }()
    
    
    
    @objc func buttonClick(button: UIButton) {
        
        self.buttonClickBlock?(textView.text)
    }
 
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        super.showCorner(25)
        self.creartUI()
    }

    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    private func creartUI() {
        
        
        self.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(50)
        }
        self.addSubview(textView)
        textView.snp.makeConstraints { make in
            make.top.equalTo(110)
            make.left.right.equalToSuperview().inset(36)
            make.height.equalTo(225)
        }
        self.addSubview(countLabel)
        countLabel.snp.makeConstraints { make in
            make.top.equalTo(textView.snp.bottom)
            make.right.equalTo(textView)
        }
        
        self.addSubview(cancelBtn)
        cancelBtn.snp.makeConstraints { make in
            make.width.equalTo(ScreenWidth * 0.5)
            make.height.equalTo(44)
            make.left.equalToSuperview()
            make.bottom.equalToSuperview().offset(-20 - UIDevice.xp_safeDistanceBottom())
        }
        
        self.addSubview(comfirmBtn)
        comfirmBtn.snp.makeConstraints { make in
            make.width.equalTo(ScreenWidth * 0.5)
            make.height.top.equalTo(cancelBtn)
            make.right.equalToSuperview()
        }
        
    }
    
    

    
    func textView(_ textView: QMUITextView!, shouldChangeTextIn range: NSRange, replacementText text: String!, originalValue: Bool) -> Bool {

        let string = textView.text + text
        let count = string.components(separatedBy: " ").count
        countLabel.text = "\(count)/500"
        if count >= 500 {
            return false
        } else {
            return true
        }
    }
   
}
