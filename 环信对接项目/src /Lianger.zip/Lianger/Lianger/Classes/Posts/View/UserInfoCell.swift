//
//  UserInfoCell.swift
//  Lianger
//
//  Created by Qidi on 2023/7/20.
//

import UIKit

class UserInfoCell: UITableViewCell {

    lazy var iconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = UIColor.hexColor(hex: 0xF1F1F1)
        imageView.showCorner(18)
        imageView.contentMode = .center
        return imageView
    }()
    lazy var iconLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.textAlignment = .center
        return label
    }()
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 15)
        label.textColor = UIColor.blackText
        return label
    }()
    
    lazy var countLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = UIColor.mainYellow
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSC(size: 12)
        label.textAlignment = .center
        label.showCorner(13)
        return label
    }()
    
    lazy var rightIcon: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "arrow_right"))
        return imageView
    }()
    
   
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .white
        self.creartUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    private func creartUI() {
        
        contentView.addSubview(iconImageView)
        
        iconImageView.snp.makeConstraints { make in
            make.width.height.equalTo(36)
            make.centerY.equalToSuperview()
            make.left.equalTo(47)
        }
        contentView.addSubview(iconLabel)
        iconLabel.snp.makeConstraints { make in
            make.center.equalTo(iconImageView)
            make.width.height.equalTo(36)
        }
        
        contentView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(iconImageView.snp.right).offset(12)
            make.right.lessThanOrEqualToSuperview().offset(-108)
        }
        
        contentView.addSubview(rightIcon)
        rightIcon.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-50)
        }
        
        contentView.addSubview(countLabel)
        countLabel.snp.makeConstraints { make in
            make.width.height.equalTo(26)
            make.centerY.equalToSuperview()
            make.right.equalTo(rightIcon.snp.left).offset(-12)
        }
        
    }

}
