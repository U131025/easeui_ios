//
//  GiftListViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/8/23.
//

import UIKit
import MCToast

class GiftListViewController: BaseViewController {

    //栏目类型
    var columnModel: ColumnModel!
    
    private let pageSize = 20
    private var dataArray: [ColumnListModel] = []
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.register(GiftListCell.self, forCellReuseIdentifier: "GiftListCell")
        tableView.uHead = URefreshNormalHeader.init(refreshingBlock: { [weak self] in
            self?.loadData()
        })
        tableView.uFoot = URefreshFooter.init(refreshingBlock: { [weak self] in
            self?.loadMoreData()
        })
        self.placeholdView.placeType(.nodata)
        tableView.backgroundView = self.placeholdView
        tableView.backgroundView?.isHidden = true
        tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: max(UIDevice.xp_safeDistanceBottom(), 16)))
        return tableView
    }()
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = self.columnModel.name
        self.showLine()
        self.creartUI()
        self.loadData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    
    override func loadData()  {
        var params = [String : Any]()
        params["pageSize"] = pageSize
        params["baseTime"] = "1970-01-01 00:00:00"
        params["columnId"] = self.columnModel.columnId
        ApiManager.getNewColumnList(params: params) { list,error in
            self.tableView.uHead.endRefreshing()
            if list != nil {
                self.dataArray = list!
                self.tableView.backgroundView?.isHidden = !self.dataArray.isEmpty
                if self.dataArray.count < self.pageSize { //无更多数据
                    self.tableView.uFoot.isHidden = true
                } else {
                    self.tableView.uFoot.isHidden = false
                    self.tableView.uFoot.state = .idle
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
        }
    }
    
    func loadMoreData() {
        var params = [String : Any]()
        params["baseTime"] = self.dataArray.last?.createTime
        params["columnId"] = self.columnModel.columnId
        params["pageSize"] = pageSize

        ApiManager.getColumnLoadmore(params: params) { list,error in
            self.tableView.uFoot.endRefreshing()
            if list != nil {
                self.dataArray.append(contentsOf: list!)
                if list!.count < self.pageSize {
                    self.tableView.uFoot.endRefreshingWithNoMoreData()
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
        }
    }
    
    
    private func creartUI() {
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(1)
        }
        
    }
    

}


extension GiftListViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataArray.count
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: GiftListCell = tableView.dequeueReusableCell(withIdentifier: "GiftListCell") as! GiftListCell
        if dataArray.count > indexPath.row {
            cell.model = dataArray[indexPath.row]
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let nextVc = GiftInfoViewController()
        if dataArray.count > indexPath.row {
            nextVc.newsId = self.dataArray[indexPath.row].newsId
        }
        self.navigationController?.pushViewController(nextVc, animated: true)
        
    }
 
    
}
