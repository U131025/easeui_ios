//
//  SystemMessageViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/29.
//

import UIKit
import MCToast

class SystemMessageViewController: BaseViewController {

    private let pageSize = 20
    private var dataArray: [NoticeModel] = []

    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.register(SystemMessageCell.self, forCellReuseIdentifier: "SystemMessageCell")
        tableView.uHead = URefreshNormalHeader.init(refreshingBlock: { [weak self] in
            self?.loadData()
        })
        tableView.uFoot = URefreshFooter.init(refreshingBlock: { [weak self] in
            self?.loadMoreData()
        })
        self.placeholdView.placeType(.nodata)
        tableView.backgroundView = self.placeholdView
        tableView.backgroundView?.isHidden = true
        tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 10))
        
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "System Message"
        self.showLine()
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalTo(1)
            make.bottom.equalToSuperview().offset(UIDevice.xp_safeDistanceBottom())
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.loadData()
    }
    
    override func loadData()  {
        var params = [String : Any]()
        params["pageSize"] = pageSize
        params["baseTime"] = "1970-01-01 00:00:00"
        params["userId"] = UserInfoModel.shared.userId
        ApiManager.getNewNoticeList(params: params) { list,error in
            self.tableView.uHead.endRefreshing()
            if list != nil {
                self.dataArray = list!
                self.tableView.backgroundView?.isHidden = !self.dataArray.isEmpty
                if self.dataArray.count < self.pageSize { //无更多数据
                    self.tableView.uFoot.isHidden = true
                } else {
                    self.tableView.uFoot.isHidden = false
                    self.tableView.uFoot.state = .idle
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
        }
    }
    
    func loadMoreData() {
        var params = [String : Any]()
        params["baseTime"] = self.dataArray.last?.createTime
        params["userId"] = UserInfoModel.shared.userId
        params["pageSize"] = pageSize

        ApiManager.getNoticeLoadmore(params: params) { list,error in
            self.tableView.uFoot.endRefreshing()
            if list != nil {
                self.dataArray.append(contentsOf: list!)
                if list!.count < self.pageSize {
                    self.tableView.uFoot.endRefreshingWithNoMoreData()
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
        }
    }

   

}

extension SystemMessageViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataArray.count
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: SystemMessageCell = tableView.dequeueReusableCell(withIdentifier: "SystemMessageCell") as! SystemMessageCell
        if dataArray.count > indexPath.row {
            cell.model = dataArray[indexPath.row]
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let nextVc = SystemMessageInfoViewController()
        if dataArray.count > indexPath.row {
            nextVc.noticeId = dataArray[indexPath.row].noticeId
        }
        self.navigationController?.pushViewController(nextVc, animated: true)
    }
 
    
}
