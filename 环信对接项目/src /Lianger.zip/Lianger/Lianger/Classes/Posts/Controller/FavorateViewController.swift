//
//  FavorateViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/8/10.
//

import UIKit
import MCToast
import MJRefresh

class FavorateViewController: BaseViewController {
    
    private var dataArray: [ArticleModel] = []
    private var pageSize = 20
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.register(ArticleCell.self, forCellReuseIdentifier: "ArticleCell")
        tableView.uHead = URefreshNormalHeader.init(refreshingBlock: { [weak self] in
            self?.loadData()
        })
        tableView.uFoot = URefreshFooter.init(refreshingBlock: { [weak self] in
            self?.loadMoreData()
        })
        self.placeholdView.title = "No favorate"
        self.placeholdView.placeType(.nodata)
        tableView.backgroundView = self.placeholdView
        tableView.backgroundView?.isHidden = true
        tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 10))

        return tableView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.top.bottom.equalToSuperview()
            make.width.equalTo(ScreenWidth)
        }
        
    }
 
    
    override func loadData()  {
        var params = [String : Any]()
        params["pageSize"] = pageSize
        params["baseTime"] = "1970-01-01 00:00:00"
        params["userId"] = UserInfoModel.shared.userId
        ApiManager.getNewsCollectionArticleList(params: params) { list,error in
            self.tableView.uHead.endRefreshing()
            if list != nil {
                self.dataArray = list!
                self.tableView.backgroundView?.isHidden = !self.dataArray.isEmpty
                if self.dataArray.count < self.pageSize { //无更多数据
                    self.tableView.uFoot.isHidden = true
                } else {
                    self.tableView.uFoot.isHidden = false
                    self.tableView.uFoot.state = .idle
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
            
        }
        
    }
    
    func loadMoreData() {
        var params = [String : Any]()
        params["baseTime"] = self.dataArray.last?.createTime
        params["userId"] = UserInfoModel.shared.userId
        params["pageSize"] = pageSize

        ApiManager.getMoreCollectionArticleList(params: params) { list,error in
            self.tableView.uFoot.endRefreshing()
            if list != nil {
                self.dataArray.append(contentsOf: list!)
                if list!.count < self.pageSize {
                    self.tableView.uFoot.endRefreshingWithNoMoreData()
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
            
        }
    }
    
    private func cancelCollectionArticle(index: Int) {
        if self.dataArray.count > index {
            let model = self.dataArray[index]
            ApiManager.collectionArticle(articleId: model.articleId!) { success, errorMsg in
                if success {
                    self.dataArray.remove(at: index)
                    self.tableView.reloadData()
                } else {
                    if let msg = errorMsg {
                        MCToast.mc_text(msg)
                    }
                }
            }
        }
        
    }
}


extension FavorateViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 134
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: ArticleCell = tableView.dequeueReusableCell(withIdentifier: "ArticleCell") as! ArticleCell
        cell.hiddenCount = true
        if self.dataArray.count > indexPath.row {
            cell.model = self.dataArray[indexPath.row]
        }
        return cell
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let delete = UIContextualAction(style: .destructive, title: "") { action, view, completionHandler in
            completionHandler(true)
            self.cancelCollectionArticle(index: indexPath.row)
        }
        delete.backgroundColor = UIColor.hexColor(hex: 0xFFE0E0)
        delete.image = UIImage(named: "icon_deleted")
        let configuration = UISwipeActionsConfiguration(actions: [delete])
        return configuration

    }

    //设置点击删除之后的操作
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {

        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let nextVc = ArticleDetailViewController()
        nextVc.articleId = self.dataArray[indexPath.row].articleId
        self.navigationController?.pushViewController(nextVc, animated: true)
    }
    
}

