//
//  EditAddressViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/29.
//

import UIKit
import TYAlertController
import MCToast

class EditAddressViewController: BaseViewController {
    
    var addressModel: UserAddressModel?
    var noticeId: String?
    var isEdit: Bool = false
    var canEdit: Bool = true
    var saveAddressBlock: (() ->Void)?
    private var zoneL: String?
    private var zoneM: String?
    private var zoneS: String?
    private var areaList: [AreaModel] = []
    private var isSaveAddress: Bool = false

    private lazy var addressView: CustomInputView = {
        let inputView = CustomInputView(frame: .zero,type: .selete, leftIcon: nil, placeholder: "Select Suburb")
        inputView.seletedBlock = { [weak self] in
            self?.chooseAddress()
        }
        return inputView
    }()
    
    private lazy var detailView: CustomInputView = {
        let inputView = CustomInputView(frame: .zero,type: .normal, leftIcon: nil, placeholder: "Please enter the detailed address")
        
        return inputView
    }()
    private lazy var detailLabel: UILabel = {
        let label = UILabel()
        label.text = "To ensure receipt of the goods, please enter as detailed address information as possible"
        label.numberOfLines = 0
        label.textColor = UIColor.buttonYellow
        label.font = UIFont.PingFangSCMedium(size: 13)
        return label
    }()
    
    private lazy var nameView: CustomInputView = {
        let inputView = CustomInputView(frame: .zero,type: .normal, leftIcon: nil, placeholder: "Contact Person")
        
        return inputView
    }()
    
    private lazy var phoneView: CustomInputView = {
        let inputView = CustomInputView(frame: .zero,type: .normal, leftIcon: nil, placeholder: "Contact Number",keyboardType: .numberPad)
        return inputView
    }()
    
    
    private lazy var chooseAddressView: ChooseAddressView = {
        let view = ChooseAddressView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 335+UIDevice.xp_safeDistanceBottom()))
        return view
    }()
    
    private lazy var setButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Default address", for: .normal)
        button.setTitleColor(UIColor.buttonYellow, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCMedium(size: 14)
        button.setImage(UIImage(named: "icon_nocheck"), for: .normal)
        button.setImage(UIImage(named: "icon_check"), for: .selected)
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: -10)
        button.addTarget(self, action: #selector(setDeafultAddress(button:)), for: .touchUpInside)
        return button
    }()
    
    private lazy var chooseButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Select address", for: .normal)
        button.setTitleColor(UIColor.buttonYellow, for: .normal)
        button.setImage(UIImage(named: "arrow_right_deep"), for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCMedium(size: 14)
        button.addTarget(self, action: #selector(chooseUserAddress(button:)), for: .touchUpInside)
        return button
    }()
    
    private lazy var addButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Add Address", for: .normal)
        button.setTitleColor(UIColor.blackText, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 18)
        button.addTarget(self, action: #selector(addAddressAction(button:)), for: .touchUpInside)
        button.backgroundColor = UIColor.mainYellow
        button.showCorner(30)
        return button
    }()
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Address"
        
        self.creartUI()
        self.loadAreaData()
  
        self.refreshView()
        
    }
    
    func refreshView() {
        if let model = self.addressModel {
            self.addressView.textValue = "\(model.zoneLName) \(model.zoneMName) \(model.zoneSName)"
            self.detailView.textValue = model.detailedAddress
            self.nameView.textValue = model.contactPerson
            self.phoneView.textValue = model.contactNumber
            self.setButton.isSelected = model.defaultStatus == 1 ? true : false
            self.isSaveAddress = model.defaultStatus == 1 ? true : false
            self.zoneL = model.zoneL
            self.zoneM = model.zoneM
            self.zoneS = model.zoneS

        }
        
        if self.noticeId != nil {
            if self.canEdit {
                self.chooseButton.isHidden = false
            } else {
                self.chooseButton.isHidden = true
            }
            self.setButton.setTitle("Save address", for: .normal)
        } else {
            self.setButton.setTitle("Default address", for: .normal)
            self.chooseButton.isHidden = true
        }
        self.setButton.isHidden = !canEdit
        self.addButton.isHidden = !canEdit
        self.view.isUserInteractionEnabled = canEdit
    }
    
    
    // MARK:  load
    func loadAreaData() {
        ApiManager.loadAreaTree { list, error in
            if list != nil {
                self.areaList = list!
            }
        }
    }
   
    
    
    @objc func chooseAddress() {
        let alertVc = TYAlertController(alert: self.chooseAddressView, preferredStyle: .actionSheet)
        self.chooseAddressView.areaList = self.areaList
        alertVc?.backgoundTapDismissEnable = true
        self.chooseAddressView.cancelBlock = {
            alertVc?.dismiss(animated: true)
        }
        self.chooseAddressView.okBlock = { [weak self] (stateIndex,cityIndex,suburbIndex) in
            guard let wSelf = self else { return }
            alertVc?.dismiss(animated: true)
            wSelf.setZoonId(stateIndex: stateIndex, cityIndex: cityIndex, suburbIndex: suburbIndex)
        }
        self.present(alertVc!, animated: true)
    }
    
    @objc func chooseUserAddress(button: UIButton) {
        let nextVc = AddressListViewController()
        nextVc.isChoose = true
        nextVc.chooseAddressComplect = { model in
            self.addressModel = model
            self.refreshView()
        }
        self.navigationController?.pushViewController(nextVc, animated: true)
    }
    
    @objc func addAddressAction(button: UIButton) {
        guard self.zoneS != nil else {
            MCToast.mc_text("Please select Suburb")
            return
        }
        guard let detailedAddress = self.detailView.textValue else {
            MCToast.mc_text("Please enter the detailed address")
            return
        }
        guard let contactPerson = self.nameView.textValue else {
            MCToast.mc_text("Please enter Contact Person")
            return
        }
        guard let contactNumber = self.phoneView.textValue else {
            MCToast.mc_text("Please enter the Contact Number")
            return
        }
        
        var params = [String : Any]()
        params["contactPerson"] = contactPerson
        params["contactNumber"] = contactNumber
        params["zoneL"] = self.zoneL
        params["zoneM"] = self.zoneM
        params["zoneS"] = self.zoneS
        params["detailedAddress"] = detailedAddress
        if let model = self.addressModel {
            params["id"] = model.id
        }
        if let noticeId = self.noticeId {
            params["noticeId"] = noticeId
            params["isSaveAddress"] = self.isSaveAddress ? 1 : 0
            ApiManager.addNoticeAddress(params: params) { success, errorMsg in
                if success {
                    self.saveAddressBlock?()
                    MCToast.mc_text("success",duration: 1.0) {
                        self.navigationController?.popViewController(animated: true)
                    }
                } else {
                    if let msg = errorMsg {
                        MCToast.mc_text(msg)
                    }
                }
            }
        } else if isEdit { //编辑地址
            params["defaultStatus"] = self.isSaveAddress ? 1 : 0
            ApiManager.editUserAddress(params: params) { success, errorMsg in
                if success {
                    MCToast.mc_text("success",duration: 1.0) {
                        self.navigationController?.popViewController(animated: true)
                    }
                } else {
                    if let msg = errorMsg {
                        MCToast.mc_text(msg)
                    }
                }
            }
        } else {
            params["defaultStatus"] = self.isSaveAddress ? 1 : 0
            ApiManager.addUserAddress(params: params) { success, errorMsg in
                if success {
                    MCToast.mc_text("success",duration: 1.0) {
                        self.navigationController?.popViewController(animated: true)
                    }
                } else {
                    if let msg = errorMsg {
                        MCToast.mc_text(msg)
                    }
                }
            }
        }
    }
    @objc func setDeafultAddress(button: UIButton) {
        button.isSelected = !button.isSelected
        self.isSaveAddress = button.isSelected
    }
    
    
    private func setZoonId(stateIndex: Int,cityIndex: Int,suburbIndex: Int) {
        var address = ""
        if self.areaList.count > stateIndex {
            let stateModel = self.areaList[stateIndex]
            self.zoneL = stateModel.id
            address = stateModel.areaName + " "
            
            if stateModel.children.count > cityIndex {
                let cityModel = stateModel.children[cityIndex]
                self.zoneM = cityModel.id
                address += cityModel.areaName + " "
                if cityModel.children.count > suburbIndex {
                    let suburbModel = cityModel.children[suburbIndex]
                    self.zoneS = suburbModel.id
                    address += suburbModel.areaName
                } else {
                    self.zoneS = nil
                }
                
            } else {
                self.zoneM = nil
            }
        } else {
            self.zoneL = nil
        }
        self.addressView.textValue = address
    }
    
    
    // MARK:  UI
    
    private func creartUI() {
        
        self.view.addSubview(addressView)
        addressView.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(60)
            make.height.equalTo(44)
            make.top.equalTo(55)
        }
        
        self.view.addSubview(detailView)
        detailView.snp.makeConstraints { make in
            make.left.right.height.equalTo(addressView)
            make.top.equalTo(addressView.snp.bottom).offset(25)
            
        }
        
        self.view.addSubview(detailLabel)
        detailLabel.snp.makeConstraints { make in
            make.left.right.equalTo(detailView).inset(8)
            make.top.equalTo(detailView.snp.bottom).offset(4)
        }

        self.view.addSubview(nameView)
        nameView.snp.makeConstraints { make in
            make.left.right.height.equalTo(addressView)
            make.top.equalTo(detailLabel.snp.bottom).offset(25)
        }
        
        self.view.addSubview(phoneView)
        phoneView.snp.makeConstraints { make in
            make.left.right.height.equalTo(addressView)
            make.top.equalTo(nameView.snp.bottom).offset(25)
        }
        
        self.view.addSubview(setButton)
        setButton.snp.makeConstraints { make in
            make.left.equalTo(phoneView)
            make.top.equalTo(phoneView.snp.bottom).offset(20)
        }
        self.view.addSubview(chooseButton)
        chooseButton.snp.makeConstraints { make in
            make.right.equalTo(phoneView)
            make.top.equalTo(phoneView.snp.bottom).offset(20)
        }
        chooseButton.layoutButtonWithEdgeInsetsStyle(style: .XZYButtonEdgeInsetsStyleRight, imageTitleSpace: 6)

        self.view.addSubview(addButton)
        addButton.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(25)
            make.height.equalTo(60)
            make.top.equalTo(phoneView.snp.bottom).offset(115)
        }
        
        
    }
    


}
