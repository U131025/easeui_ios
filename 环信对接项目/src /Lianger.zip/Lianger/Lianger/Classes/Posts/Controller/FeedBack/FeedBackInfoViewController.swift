//
//  FeedBackInfoViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/28.
//

import UIKit
import MCToast

class FeedBackInfoViewController: BaseViewController {

    private let pageSize = 20
    private var dataArray: [FeedBackModel] = []
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .singleLine
        tableView.separatorColor = UIColor.grey99
        tableView.separatorInset = UIEdgeInsets.zero
        tableView.delegate = self
        tableView.dataSource = self
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.register(FeedBackInfoCell.self, forCellReuseIdentifier: "FeedBackInfoCell")
        
        tableView.uHead = URefreshNormalHeader.init(refreshingBlock: { [weak self] in
            self?.loadData()
        })
        tableView.uFoot = URefreshFooter.init(refreshingBlock: { [weak self] in
            self?.loadMoreData()
        })
        self.placeholdView.title = "Post your first content."
        self.placeholdView.placeType(.nodata)
        tableView.backgroundView = self.placeholdView
        tableView.backgroundView?.isHidden = true
        tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 10))
        return tableView
    }()
    lazy var bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        let button = UIButton(type: .custom)
        button.setTitle("Feedback", for: .normal)
        button.setTitleColor(UIColor.blackText, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 18)
        button.addTarget(self, action: #selector(bottomButtonAction(button:)), for: .touchUpInside)
        button.backgroundColor = UIColor.mainYellow
        button.showCorner(30)
        view.addSubview(button)
        button.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.right.equalToSuperview().inset(25)
            make.height.equalTo(60)
        }
        
        let lineView = UIView()
        lineView.backgroundColor = UIColor.greyE6
        view.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(1)
        }
        return view
    }()
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Feedback"
        self.showLine()
        self.creartUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.loadData()
    }
    
    
    override func loadData()  {
        var params = [String : Any]()
        params["pageSize"] = pageSize
        params["baseTime"] = "1970-01-01 00:00:00"
        params["userId"] = UserInfoModel.shared.userId
        ApiManager.getNewsFeedbackList(params: params) { list,error in
            self.tableView.uHead.endRefreshing()
            if list != nil {
                self.dataArray = list!
                self.tableView.backgroundView?.isHidden = !self.dataArray.isEmpty
                if self.dataArray.count < self.pageSize { //无更多数据
                    self.tableView.uFoot.isHidden = true
                } else {
                    self.tableView.uFoot.isHidden = false
                    self.tableView.uFoot.state = .idle
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
        }
    }
    
    func loadMoreData() {
        var params = [String : Any]()
        params["baseTime"] = self.dataArray.last?.createTime
        params["userId"] = UserInfoModel.shared.userId
        params["pageSize"] = pageSize

        ApiManager.getFeedbackLoadmore(params: params) { list,error in
            self.tableView.uFoot.endRefreshing()
            if list != nil {
                self.dataArray.append(contentsOf: list!)
                if list!.count < self.pageSize {
                    self.tableView.uFoot.endRefreshingWithNoMoreData()
                }
                self.tableView.reloadData()
            } else {
                if let msg = error {
                    MCToast.mc_text(msg)
                }
            }
        }
    }
    
    
    
    
    @objc private func bottomButtonAction(button: UIButton) {
        let nextVc = FeedBackEditViewController()
        self.navigationController?.pushViewController(nextVc, animated: true)
    }

    private func creartUI() {
        
        self.view.addSubview(bottomView)
        bottomView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
            make.height.equalTo(88)
        }
       
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().offset(1)
            make.bottom.equalTo(bottomView.snp.top)
        }
        
    }
    

}


extension FeedBackInfoViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataArray.count
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: FeedBackInfoCell = tableView.dequeueReusableCell(withIdentifier: "FeedBackInfoCell") as! FeedBackInfoCell
        if dataArray.count > indexPath.row {
            cell.model = dataArray[indexPath.row]
        }
        return cell
    }
    
 
    
}
