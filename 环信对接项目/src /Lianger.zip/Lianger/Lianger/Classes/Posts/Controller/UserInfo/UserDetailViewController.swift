//
//  UserDetailViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/27.
//

import UIKit
import TYAlertController
import MCToast

class UserDetailViewController: BaseViewController {

    private var areaList: [AreaModel] = []
    private lazy var headerView: UserDetailHeaderView = {
        let header = UserDetailHeaderView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 160))
        header.changeAvatarAction = {
            self.changeAvatar()
        }
        return header
    }()
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.bounces = false
        tableView.contentInsetAdjustmentBehavior = .never

        tableView.register(UserDetailCell.self, forCellReuseIdentifier: "UserDetailCell")
        return tableView
    }()
    let titleArr = ["Name","Introduction","Suburb","Phone","Email","Address"]
    private var emailView: CustomInputView?
    private var phoneView: CustomInputView?

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.creatUI()
        self.loadAreaData()
        self.reloadData()

    }
    
    
    private func creatUI() {
        self.view.addSubview(tableView)
        self.tableView.tableHeaderView = headerView
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
    }
    
    func loadAreaData() {
        ApiManager.loadAreaTree { list, error in
            if list != nil {
                self.areaList = list!
            }
        }
    }
    
    func reloadData() {
        self.headerView.updata()
        
        self.tableView.reloadData()
    }
    

    // MARK:  修改个人信息
    
    private func changeAvatar() {
        let alertVc = UIAlertController(title: "Photo", message: "", preferredStyle: UIAlertController.Style.actionSheet)
        let action1 = UIAlertAction(title: "Camera", style: .default, handler: {_ in
            self.selectPicToUpload(type: 1)
        })
        let action2 = UIAlertAction(title: "Photo Library", style: .default, handler: {_ in
            self.selectPicToUpload(type: 2)
        })
      
        let action3 = UIAlertAction(title: "Cancel", style: .cancel)
        alertVc.addAction(action1)
        alertVc.addAction(action2)
        alertVc.addAction(action3)
        self.present(alertVc, animated: true, completion: nil)
    }
    private func updateAvatar(_ image: UIImage) {
        MCToast.mc_loading()
        ApiManager.changeUser(avatar: image) { sucess,msg in
            MCToast.mc_remove()
            if sucess {
                ApiManager.loadUserInfo() { status,error in
                    self.headerView.updata()
                    NotificationCenter.default.post(name: NotiKey.didUserAvatarChanged, object: nil)
                }
            } else {
                MCToast.mc_text("fail")
            }
        }
         
    }
    func selectPicToUpload(type: Int) {
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        if type == 1 {
            cameraPicker.sourceType = .camera
        } else {
            cameraPicker.sourceType = .photoLibrary
        }
        self.present(cameraPicker, animated: true, completion: nil)
    }
    
    private func changeUserName() {
        let nameTf = CustomInputView(frame: .zero,type: .normal, leftIcon: nil, placeholder: "New name")
        let alertView = CustomAlertViewController(title: "Name", message: nil, itemViews: [nameTf], itemHeight: 60,space: 75,comfirmText: "Save", cancelText: "Cancel")
        alertView.show()
        alertView.buttomClick = { isComfim in
            if isComfim ,let name = nameTf.textValue,name.isBlank == false{
                ApiManager.changeUser(nickName: name) { sucess,error in
                    if sucess {
                        alertView.hidden()
                        UserInfoModel.shared.nickName = name
                        self.reloadData()
                    } else {
                        MCToast.mc_text(error ?? "fail")
                    }
                    
                }
            } else {
                alertView.hidden()
            }
        }
        
    }
    private func changeUserIntroduction() {
        let editView = EditIntroductionView.init(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 465+UIDevice.xp_safeDistanceBottom()))
        let alertVc = TYAlertController(alert: editView, preferredStyle: .actionSheet)
        alertVc?.backgoundTapDismissEnable = true
        
        self.present(alertVc!, animated: true)

        editView.buttonClickBlock = { text in
            if let introduction = text,introduction.count > 0 {
                ApiManager.changeUser(introduction: introduction) { sucess,error in
                    UserInfoModel.shared.introduction = introduction
                    self.tableView.reloadData()
                }
            }
            alertVc?.dismiss(animated: true)
        }
    }
    private func changeUserSuburb() {
        
        let addressView = ChooseAddressView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 335+UIDevice.xp_safeDistanceBottom()))
        addressView.areaList = self.areaList

        let alertVc = TYAlertController(alert: addressView, preferredStyle: .actionSheet)
        alertVc?.backgoundTapDismissEnable = true
        addressView.cancelBlock = {
            alertVc?.dismiss(animated: true)
        }
        addressView.okBlock = { [weak self] (stateIndex,cityIndex,suburbIndex) in
            guard let wSelf = self else { return }
            wSelf.updateUserSuburb(stateIndex: stateIndex, cityIndex: cityIndex, suburbIndex: suburbIndex)
            alertVc?.dismiss(animated: true)
        }
        self.present(alertVc!, animated: true)
    }
    
    private func updateUserSuburb(stateIndex: Int,cityIndex: Int,suburbIndex: Int) {
        
        var params = [String : Any]()
        let stateModle = self.areaList[stateIndex]
        params["zoneL"] = stateModle.id
        if stateModle.children.count > cityIndex {
            let cityModel = stateModle.children[cityIndex]
            params["zoneM"] = cityModel.id
            if cityModel.children.count > suburbIndex {
                let suburbModel = cityModel.children[suburbIndex]
                params["zoneS"] = suburbModel.id
            }
        }
        ApiManager.changeUserArea(params: params) { sucess,errMsg in
            if sucess {
                ApiManager.loadUserInfo() { status,error in
                    self.reloadData()
                    NotificationCenter.default.post(name: NotiKey.didUserAreaChanged, object: nil)
                }
            } else {
                if let msg = errMsg {
                    MCToast.mc_text(msg)
                }
            }
        }

    }
    
    
    private func changeUserPhone() {
        let phoneView = CustomInputView(frame: .zero,type: .phone, leftIcon: nil, placeholder: "New Phone Number",maxLenght: 11,keyboardType: .numberPad)
        self.phoneView = phoneView
       let verCodeView = CustomInputView(frame: .zero,type: .verCode, leftIcon: nil, placeholder: "Verification code",maxLenght: 6,keyboardType: .numberPad)
        verCodeView.timingButton.addTarget(self, action: #selector(clickGetVerCodeBtn), for: .touchUpInside)
        let alertView = CustomAlertViewController(title: "Phone", message: nil, itemViews: [phoneView,verCodeView], itemHeight: 60,comfirmText: "Save", cancelText: "Cancel")
       
        alertView.show()
        alertView.buttomClick = { isComfim in
            if isComfim,let phone = phoneView.textValue,let code = verCodeView.textValue, phone.count > 0, code.count > 0{
                ApiManager.changeUser(phone: phone, code: code) { success, errorMsg in
                    if success {
                        alertView.hidden()
                        UserInfoModel.shared.phone = phone
                        self.reloadData()
                    } else {
                        MCToast.mc_text(errorMsg ?? "fail")
                    }
                }
            } else {
                alertView.hidden()
            }
        }
        
    }
    
    private func changeUserEmail() {
        let emailView = CustomInputView(frame: .zero,type: .verCode, leftIcon: nil, placeholder: "New Email")
        self.emailView = emailView
        emailView.timingButton.addTarget(self, action: #selector(clickGetMsgCodeBtn), for: .touchUpInside)

        let verCodeView = CustomInputView(frame: .zero,type: .normal, leftIcon: nil, placeholder: "Verification code",maxLenght: 6,keyboardType: .numberPad)

        let alertView = CustomAlertViewController(title: "Email", message: nil, itemViews: [emailView,verCodeView], itemHeight: 60,comfirmText: "Save", cancelText: "Cancel")
       
        alertView.show()
        alertView.buttomClick = { isComfim in
            if isComfim,let email = emailView.textValue,let code = verCodeView.textValue, email.count > 0{
                ApiManager.changeUser(email: email, code: code) { success, errorMsg in
                    if success {
                        alertView.hidden()
                        UserInfoModel.shared.email = email
                        self.reloadData()
                    } else {
                        MCToast.mc_text(errorMsg ?? "fail")
                    }
                    
                }
            } else {
                alertView.hidden()
            }
        }
        
    }
    
    @objc private func clickGetMsgCodeBtn() {
        if let email = self.emailView?.textValue {
            ApiManager.sendemailCode(email: email) { success, errorMsg in
                if success {
                    MCToast.mc_text("Verification code send")

                } else {
                    if let msg = errorMsg {
                        MCToast.mc_text(msg)
                    }
                }
            }
            
        } else {
            MCToast.mc_text("Please enter Email")
        }
    }
  
    @objc private func clickGetVerCodeBtn() {
        guard let mobile = self.phoneView?.textValue,mobile.isBlank == false else {
            MCToast.mc_text("Please enter Phone Number")
            return
        }
        ApiManager.sendVerCode(phonenumber: mobile) { success, errorMsg in
            if success {
                MCToast.mc_text("Verification code sent successfully")
            } else {
                if let msg = errorMsg {
                    MCToast.mc_text(msg)
                }
            }
        }
    }

}
extension UserDetailViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)

        let image = info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.originalImage)] as! UIImage
        self.updateAvatar(image)
        picker.dismiss(animated: true, completion: nil)
       
    }
}
fileprivate func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
    return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromUIImagePickerControllerInfoKey(_ input: UIImagePickerController.InfoKey) -> String {
    return input.rawValue
}




extension UserDetailViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleArr.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 57
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UserDetailCell = tableView.dequeueReusableCell(withIdentifier: "UserDetailCell") as! UserDetailCell
        cell.titleLabel.text = titleArr[indexPath.row]
        if indexPath.row == 0 {
            cell.detailLabel.text = UserInfoModel.shared.nickName
        } else if indexPath.row == 1 {
            cell.detailLabel.text = UserInfoModel.shared.introduction
        } else if indexPath.row == 2 {
            if let zoneLName = UserInfoModel.shared.zoneLName,let zoneMName = UserInfoModel.shared.zoneMName,let zoneSName = UserInfoModel.shared.zoneSName{
                cell.detailLabel.text = "\(zoneLName)-\(zoneMName)-\(zoneSName)"
            } else {
                cell.detailLabel.text = ""
            }
        } else if indexPath.row == 3 {
            cell.detailLabel.text = UserInfoModel.shared.phone
        } else if indexPath.row == 4 {
            cell.detailLabel.text = UserInfoModel.shared.email
        } else {
            cell.detailLabel.text = nil
        }
        return cell
    }
    
 
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            self.changeUserName()
        } else if indexPath.row == 1 {
            self.changeUserIntroduction()
        } else if indexPath.row == 2 {
            self.changeUserSuburb()
        } else if indexPath.row == 3 {
            self.changeUserPhone()
        } else if indexPath.row == 4 {
            self.changeUserEmail()
        } else if indexPath.row == 5 {
            let addressVc = AddressListViewController()
            
            self.navigationController?.pushViewController(addressVc, animated: true)
        }
        
    }
    
}
