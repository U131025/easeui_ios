//
//  SystemMessageInfoViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/29.
//

import UIKit
import WebKit
import MCToast

class SystemMessageInfoViewController: BaseViewController {
    
    var noticeId: String?
    
    private var model: NoticeInfoModel?
    private var addressModel: UserAddressModel?
    private lazy var webView : WKWebView = {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true //可以禁止弹出全屏  网页video标签要加上 playsinline 这个属性
        let web = WKWebView(frame: .zero, configuration: config)
        return web
    }()
    private var bottomButton: UIButton!
    lazy var bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        let button = UIButton(type: .custom)
        button.setTitle("Address", for: .normal)
        button.setTitleColor(UIColor.blackText, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 18)
        button.addTarget(self, action: #selector(bottomButtonAction(button:)), for: .touchUpInside)
        button.backgroundColor = UIColor.mainYellow
        button.showCorner(30)
        view.addSubview(button)
        button.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.right.equalToSuperview().inset(25)
            make.height.equalTo(60)
        }
        self.bottomButton = button
        let lineView = UIView()
        lineView.backgroundColor = UIColor.greyE6
        view.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(1)
        }
        return view
    }()

    lazy var headerView: WebNavView = {
        let view = WebNavView(frame: .zero)
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        self.creartUI()
        self.loadData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: false)

    }
    
    override func loadData() {
        guard let noticeId = self.noticeId else { return }

        ApiManager.getNoticeInfo(noticeId: noticeId, handler: { model, errorMsg in
            if model != nil {
                self.model = model
                self.reloadData()
            } else {
                if let msg = errorMsg {
                    MCToast.mc_text(msg)
                }
            }
        })
        
    }
    func loadUserDeafultAddress() {
        ApiManager.getUserDefaultAddress { model, errorMsg in
            self.addressModel = model
        }
    }

    
    private func reloadData() {
        guard let model = self.model else { return }
        self.navigationItem.title = model.noticeTitle
        var height = model.noticeTitle?.getHeightWithAttributes([.font : UIFont.PingFangSCSemibold(size: 17)] ,ScreenWidth - 66) ?? 22
        height += 48
        self.headerView.snp.updateConstraints { make in
            make.height.equalTo(height)
        }
        self.headerView.titleLabel.text = model.noticeTitle
        self.headerView.timeLabel.text = model.createTime
        if model.status == 0 {
            self.headerView.statusLabel.text = "Unread"
            self.headerView.statusLine.backgroundColor = UIColor.mainYellow
        } else {
            self.headerView.statusLabel.text = "Read"
            self.headerView.statusLine.backgroundColor = UIColor.greyD9
        }
        if model.isCollectAddress == 0 {
            self.bottomView.snp.updateConstraints { make in
                make.height.equalTo(0)
            }
            self.bottomView.isHidden = true
        } else {
            self.loadUserDeafultAddress()
            self.bottomButton.isEnabled = true
            
            if model.isExpired == 1 {
                
                ///已过期
                if let addressId = model.addressId,addressId.isEmpty == true {
                    self.bottomButton.isEnabled = false
                    // 未填写
                    self.bottomButton.titleLabel?.numberOfLines = 0
                    self.bottomButton.titleLabel?.textAlignment = .center
                    let arrtText = NSMutableAttributedString(string: "Address\n[Expired]")
                    arrtText.addAttributes([.font : UIFont.PingFangSCBold(size: 18),.foregroundColor : UIColor.grey99], range: NSRange(location: 0, length: 7))
                    arrtText.addAttributes([.font : UIFont.PingFangSCBold(size: 13),.foregroundColor : UIColor.blackText], range: NSRange(location: 7, length: arrtText.length - 7))
                    self.bottomButton.setAttributedTitle(arrtText, for: .normal)
                    self.bottomButton.backgroundColor = UIColor.greyE6
                } else {
                    self.bottomButton.setTitle("View Address", for: .normal)
                    self.bottomButton.setTitleColor(.white, for: .normal)
                    self.bottomButton.backgroundColor = UIColor.blackText
                }
                
            } else {
                if let addressId = model.addressId,addressId.isEmpty == false { //已填写
                    
                    self.bottomButton.setTitle("View Address", for: .normal)
                    self.bottomButton.setTitleColor(.white, for: .normal)
                    self.bottomButton.backgroundColor = UIColor.blackText
                } else {
                    self.bottomButton.setTitle("Address", for: .normal)
                    self.bottomButton.setTitleColor(UIColor.blackText, for: .normal)
                    self.bottomButton.backgroundColor = UIColor.mainYellow
                }
            }
            
            self.bottomView.snp.updateConstraints { make in
                make.height.equalTo(88)
            }
            self.bottomView.isHidden = false
        }
        
        guard let decodedData = Data(base64Encoded: model.noticeContent,options: NSData.Base64DecodingOptions.ignoreUnknownCharacters) else { return }
        let decodedString = NSString(data: decodedData, encoding: NSUTF8StringEncoding)! as String
//        let htmlStr = self.formatHtml(str: decodedString)
        
        self.webView.loadHTMLString(decodedString, baseURL: nil)
    }
    
    @objc dynamic func formatHtml(str: String) -> String {
        // 为图片路径添加domain
        let body = str
        let style = "<style type=\"text/css\">" +
                "html{margin:0;padding:20px 30px;}" +
                "body {" +
                "margin: 0;" +
                "padding: 0;" +
                "font-size: 20px;" +
                "}" +
                "img{" +
                "width: 100%;" +
                "height: auto;" +
                "display: block;" +
                "margin-left: auto;" +
                "margin-right: auto;" +
                "}" +
                "</style>"
        let headerString : String = "<header><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no'>\(style)</header>"
        let content = headerString + body
        
        return content
    }

    @objc private func bottomButtonAction(button: UIButton) {
        guard let model = self.model else { return }
        
        if let addressId = model.addressId, addressId.isEmpty == false { //已填写
            ApiManager.getNoticeAddressData(addressId: addressId) { model, errorMsg in
                if model != nil {
                    let nextVc = EditAddressViewController()
                    nextVc.noticeId = self.noticeId
                    nextVc.addressModel = model!
                    nextVc.canEdit = false
                    self.navigationController?.pushViewController(nextVc, animated: true)
                } else {
                    if let msg = errorMsg {
                        MCToast.mc_text(msg)
                    }
                }
            }
            
        } else {
            // 已过期未填写
            if model.isExpired == 1  { return }
            
            guard let noticeId = self.model?.noticeId else { return }
            let nextVc = EditAddressViewController()
            nextVc.noticeId = noticeId
            nextVc.addressModel = self.addressModel
            nextVc.saveAddressBlock = {
                self.loadData()
            }
            self.navigationController?.pushViewController(nextVc, animated: true)
        }
    }

    // MARK:  UI
    private func creartUI() {
        
        self.view.addSubview(headerView)
        headerView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().offset(UIDevice.xp_safeDistanceTop())
            make.height.equalTo(44)
        }
        self.view.addSubview(bottomView)
        bottomView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.height.equalTo(88)
            make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
        }
        self.bottomView.isHidden = true
        
        self.view.addSubview(webView)
        
        webView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.equalTo(bottomView.snp.top)
        }
        
    }
    
}
