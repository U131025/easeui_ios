//
//  UserInfoViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/20.
//

import UIKit

class UserInfoViewController: BaseViewController {

    private lazy var headerView: UserInfoHeaderView = {
        let header = UserInfoHeaderView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 210))
        return header
    }()
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.bounces = false
        tableView.contentInsetAdjustmentBehavior = .never

        tableView.register(UserInfoCell.self, forCellReuseIdentifier: "UserInfoCell")
        return tableView
    }()
    private var iconArr = ["me_message","me_feedback","me_about","me_signout"]
    private var titleArr = ["System Message","Feedback","About","Sign out"]
    private var giftArr: [ColumnModel] = []
    private var unreadCount: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.creatUI()
        self.loadColumnData()

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.headerView.reloadData()
        self.loadUnreadCount()
    }
    
    
    private func creatUI() {
        self.view.addSubview(tableView)
        self.tableView.tableHeaderView = headerView
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    func loadColumnData() {
        
        ApiManager.getColumnList { list, errorMsg in
            if list != nil {
                self.giftArr = list!
            }
            self.setUpTitleArray()
        }
    }
    func loadUnreadCount() {
        ApiManager.getNoticeUnreadCount { count, errorMsg in
            if let count = count {
                self.unreadCount = count
                self.tableView.reloadData()
            }
        }
    }
    
    
    private func setUpTitleArray() {
        
        for i in 0..<self.giftArr.count {
            let model = self.giftArr[i]
            if let name = model.name,let icon = model.icon {
                self.titleArr.insert(name, at: i+2)
                self.iconArr.insert(icon, at: i+2)

            }
        }
        self.tableView.reloadData()
        
    }
    func unicodeString(for code: Int) -> String? {
        guard let scalar = UnicodeScalar(code) else {
            return nil
        }
        return String(scalar)
    }


}

extension UserInfoViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleArr.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 56
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UserInfoCell = tableView.dequeueReusableCell(withIdentifier: "UserInfoCell") as! UserInfoCell
        cell.titleLabel.text = titleArr[indexPath.row]
        
        if indexPath.row == 0 && self.unreadCount > 0{
            cell.countLabel.isHidden = false
            cell.countLabel.text = "\(self.unreadCount)"
        } else {
            cell.countLabel.isHidden = true
        }
        if indexPath.row == self.titleArr.count - 1 {
            cell.iconImageView.backgroundColor = UIColor.hexColor(hex: 0xFFE7E7)
            cell.titleLabel.textColor = UIColor.hexColor(hex: 0xFE0000)
        } else {
            cell.iconImageView.backgroundColor = UIColor.hexColor(hex: 0xF1F1F1)
            cell.titleLabel.textColor = UIColor.blackText
        }
        if indexPath.row > 1 && indexPath.row < self.titleArr.count - 2 {
            cell.iconImageView.image = nil
            cell.iconLabel.isHidden = false
            let code = Int(self.iconArr[indexPath.row]) ?? 0
            cell.iconLabel.font = UIFont(name: "iconfont-menu", size: 15)
            cell.iconLabel.text = self.unicodeString(for: code)
        } else {
            cell.iconImageView.image = UIImage(named: iconArr[indexPath.row])
            cell.iconLabel.isHidden = true
        }
        
        
        return cell
    }
    
 
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            let nextVc = SystemMessageViewController()
            self.navigationController?.pushViewController(nextVc, animated: true)
        } else if indexPath.row == 1 {
            let nextVc = FeedBackInfoViewController()
            self.navigationController?.pushViewController(nextVc, animated: true)
        } else if indexPath.row == self.titleArr.count - 2 {
            let nextVc = AboutUsViewController()
            self.navigationController?.pushViewController(nextVc, animated: true)
        } else if indexPath.row == self.titleArr.count - 1 {
            let alertView = CustomAlertViewController.init(title: "Exit?", message: "Are you sure to exit?", itemViews: nil, comfirmText: "Sign out", cancelText: "Cancel",comfirmTextColor: UIColor.hexColor(hex: 0xFF3333))
            alertView.show()
            alertView.buttomClick = { isComfim in
                if isComfim {
                    ApiManager.logout { success, errorMsg in
                        let app = UIApplication.shared.delegate as! AppDelegate
                        app.restoreRootViewController( UINavigationController.init(rootViewController: LogInViewController()))
                    }
                }
                alertView.hidden()
            }
            
        } else {
            let nextVc = GiftListViewController()
            if self.giftArr.count > indexPath.row - 2 {
                nextVc.columnModel = self.giftArr[indexPath.row - 2]
            }
            self.navigationController?.pushViewController(nextVc, animated: true)
        }
        
    }
    
}
