//
//  AddWorksViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/20.
//

import UIKit
import QMUIKit
import ZLPhotoBrowser
import TYAlertController
import MCToast

class AddWorksViewController: BaseViewController {
    
    private var channelModel: ChannelModel?
    private var areaList: [AreaModel] = []

    private var categoryL: CategoryModel?
    private var categoryS: CategoryModel?
    private var zoneL: String?
    private var zoneM: String?
    private var zoneS: String?
    private var address: String?
    private var imageArr: [UIImage] = []
    private var imageDicArr: [[String : Any]] = []

    private lazy var backSV: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.backgroundColor = .white
        scrollView.contentInsetAdjustmentBehavior = .never
        return scrollView
    }()
    private let svContentView: UIView = UIView()

    private lazy var textView: QMUITextView = {
        let textView = QMUITextView(frame: .zero)
        textView.placeholderColor = UIColor.placeholdColor
        textView.placeholder = "Please enter content"
        textView.tintColor = UIColor.inputTintColor
        textView.textColor = UIColor.blackText
        textView.font = UIFont.PingFangSCMedium(size: 15)
        textView.delegate = self
        textView.isEditable = true
        return textView
    }()
    private lazy var countLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSC(size: 13)
        label.textAlignment = .right
        label.text = "0/1000"
        return label
    }()
    private lazy var photosLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackText
        label.font = UIFont.PingFangSCBold(size: 17)
        label.text = "Photos"
        return label
    }()
    private lazy var imageCountLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSCMedium(size: 15)
        label.text = "(0/5)"
        return label
    }()
    private lazy var collectionView: UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize(width: 86, height: 86)
        flowLayout.minimumLineSpacing = 10
        flowLayout.minimumInteritemSpacing = 10
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: flowLayout)
        collectionView.backgroundColor = .clear
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.showsVerticalScrollIndicator = false
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.contentInsetAdjustmentBehavior = .never
        collectionView.register(UpImageCell.self, forCellWithReuseIdentifier: UpImageCell.description())
        collectionView.isScrollEnabled = false
        return collectionView
    }()
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.isScrollEnabled = false
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.rowHeight = 48
        tableView.register(AddWorksChooseCell.self, forCellReuseIdentifier: "AddWorksChooseCell")
        return tableView
    }()
    private var assets: [PHAsset] = []
    lazy var photoPicker: ZLPhotoPreviewSheet = {
        let config = ZLPhotoConfiguration.default()
        config.allowSelectImage = true
        config.allowSelectVideo = false
        config.allowSelectGif = false
        config.allowSelectLivePhoto = false
        config.allowSelectOriginal = false
        config.cropVideoAfterSelectThumbnail = true
        config.allowEditVideo = true
        config.allowMixSelect = false
        config.maxSelectCount = 5
        let photoPicker = ZLPhotoPreviewSheet()
        photoPicker.selectImageBlock = { [weak self] (images, assets, _) in
            guard let self = self else { return }
            self.assets = assets
            self.imageArr = images
            self.refeshCollectionView()
        }
        return photoPicker
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
      
        self.showLine()
        self.creartUI()
        self.loadData()
        self.loadAreaData()
    }
    
    
    // MARK:  请求
    override func loadData() {
        ApiManager.getChannelList() { model,errMsg in
            self.channelModel = model
        }
    }
    func loadAreaData() {
        ApiManager.loadAreaTree { list, error in
            if list != nil {
                self.areaList = list!
            }
        }
    }

    // MARK:  Action
    func refeshCollectionView() {
        let count = imageArr.count
        let imageWith:CGFloat = CGFloat(86 * (count + 1) + 10 * count)
        if imageWith > ScreenWidth - 20 {
            collectionView.snp.updateConstraints { make in
                make.height.equalTo(86 * 2 + 10)
            }
        } else {
            collectionView.snp.updateConstraints { make in
                make.height.equalTo(86)
            }
        }
        self.imageCountLabel.text = "\(count)/5"
        self.collectionView.reloadData()
        
    }
    @objc func deleteImage(button: UIButton) {
        let index = button.tag
        if imageArr.count > index {
            imageArr.remove(at: index)
            self.refeshCollectionView()
        }
        
    }
    @objc func postAction() {
        
        if let content = self.textView.text {
            if content.isBlank == true {
                MCToast.mc_text("Please enter content")
                return
            } else if content.getWordCount() > 1000 {
                MCToast.mc_text("content exceed")
                return
            }
            
        }
        
        if self.zoneS == nil {
            MCToast.mc_text("Please select Suburb")
            return
        }
        if self.categoryL == nil {
            MCToast.mc_text("Please select category L")
            return
        }
        if self.categoryS == nil {
            MCToast.mc_text("Please select category S")
            return
        }
        
        if self.imageArr.count > 0 {
            self.upImage()
        } else {
            self.postArticle()
        }
  
    }
    private func postArticle() {
        var params = [String : Any]()
        params["content"] = self.textView.text
        params["channelLId"] = self.categoryL!.chId
        params["channelSId"] = self.categoryS!.chId
        
        params["zoneL"] = self.zoneL
        params["zoneM"] = self.zoneM
        params["zoneS"] = self.zoneS
        if !self.imageDicArr.isEmpty {
            var imageUrlArr: [String] = []
            self.imageDicArr.forEach {
                imageUrlArr.append($0["url"] as! String)
            }
            params["banner"] = imageUrlArr.joined(separator: ",")
        }
        ApiManager.addNewArticle(params: params) { sucess,errMsg in
            if sucess {
                MCToast.mc_text("sucess",callback:{
                    NotificationCenter.default.post(name: NotiKey.didPostArticle, object: nil)
                    self.navigationController?.popViewController(animated: true)
                })
            
            } else {
                if let msg = errMsg {
                    MCToast.mc_text(msg)
                }
            }
        }
    }
    
    private func upImage() {
        
        let queue = DispatchQueue(label: "myQueue", attributes: DispatchQueue.Attributes.concurrent)
        let group = DispatchGroup()
        MCToast.mc_loading()
        for i in 0..<self.imageArr.count {
            group.enter()
            let image = self.imageArr[i]
            queue.async {
                UpLoadManager.upLoadOss(image: image) { status, imageUrl in
                    group.leave()
                    if let url = imageUrl {
                        let dic:[String : Any] = ["url" : url, "index" : i]
                        self.imageDicArr.append(dic)
                    }
                }
            }
        }

        group.notify(queue: queue) {
            DispatchQueue.main.async {
                MCToast.mc_remove()
                self.imageDicArr.sort { dic1, dic2 in
                    let index1 = dic1["index"] as! Int
                    let index2 = dic2["index"] as! Int
                    return index1 < index2
                }
                self.postArticle()
            }
        }
        
    }
    
    private func setZoonId(stateIndex: Int,cityIndex: Int,suburbIndex: Int) {
        var address = ""
        if self.areaList.count > stateIndex {
            let stateModel = self.areaList[stateIndex]
            self.zoneL = stateModel.id
            address = stateModel.areaName + " "
            
            if stateModel.children.count > cityIndex {
                let cityModel = stateModel.children[cityIndex]
                self.zoneM = cityModel.id
                address += cityModel.areaName + " "
                if cityModel.children.count > suburbIndex {
                    let suburbModel = cityModel.children[suburbIndex]
                    self.zoneS = suburbModel.id
                    address += suburbModel.areaName
                } else {
                    self.zoneS = nil
                }
                
            } else {
                self.zoneM = nil
            }
        } else {
            self.zoneL = nil
        }
        self.address = address
        self.tableView.reloadData()
    }
    
    
    // MARK:  UI
    private func creartUI() {
        self.setUpNavBar()
        self.view.addSubview(self.backSV)
        self.backSV.addSubview(self.svContentView)
        self.generateSVContentView()
        self.backSV.snp.makeConstraints { make in
            make.left.width.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(1)
        }
        self.svContentView.snp.makeConstraints { make in
            make.edges.width.equalToSuperview()
        }

    }
    private func generateSVContentView() {
        self.svContentView.addSubview(textView)
        textView.snp.makeConstraints { make in
            make.left.top.right.equalToSuperview().inset(20)
            make.height.equalTo(210)
        }
        self.svContentView.addSubview(countLabel)
        countLabel.snp.makeConstraints { make in
            make.right.equalToSuperview().offset(-20)
            make.top.equalTo(textView.snp.bottom)
        }
        let headerView = UIView()
        self.svContentView.addSubview(headerView)
        headerView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.height.equalTo(60)
            make.top.equalTo(textView.snp.bottom).offset(50)
        }
        headerView.addSubview(photosLabel)
        photosLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(20)
        }
        headerView.addSubview(imageCountLabel)
        imageCountLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.equalTo(photosLabel.snp.right).offset(8)
        }
        
        self.svContentView.addSubview(collectionView)
        collectionView.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(20)
            make.top.equalTo(headerView.snp.bottom)
            make.height.equalTo(86)
        }
        self.svContentView.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.height.equalTo(144)
            make.top.equalTo(collectionView.snp.bottom).offset(12)
        }
        
        
        self.svContentView.snp.makeConstraints { make in
            make.bottom.equalTo(self.tableView).offset(max(UIDevice.xp_safeDistanceBottom(), 20))
        }
        
    }
    
    func setUpNavBar() {
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "icon_close"), style: .plain, target: self, action: #selector(self.goBack))
        let postBtn = UIButton(type: .custom)
        postBtn.setTitle("Post", for: .normal)
        postBtn.setTitleColor(UIColor.blackText, for: .normal)
        postBtn.titleLabel?.font = UIFont.PingFangSCMedium(size: 15)
        postBtn.backgroundColor = UIColor.mainYellow
        postBtn.showCorner(17)
        postBtn.size = CGSize(width: 80, height: 34)
        postBtn.addTarget(self, action: #selector(postAction), for: .touchUpInside)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: postBtn)
        
    }

    

}


extension AddWorksViewController: QMUITextViewDelegate {
    func textView(_ textView: QMUITextView!, shouldChangeTextIn range: NSRange, replacementText text: String!, originalValue: Bool) -> Bool {
        let string = textView.text + text
        let count = string.getWordCount()
        countLabel.text = "\(count)/1000"
        if count > 1000 {
            return false
        }
        return true

    }
}

extension AddWorksViewController: UICollectionViewDelegateFlowLayout,UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArr.count == 5 ? 5 : imageArr.count + 1
    }
    
   
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell: UpImageCell = collectionView.dequeueReusableCell(withReuseIdentifier: UpImageCell.description(), for: indexPath) as! UpImageCell
        if imageArr.count == indexPath.row {
            cell.bgImageView.isHidden = false
            cell.imageView.isHidden = true
            cell.deleteButton.isHidden = true
        } else {
            cell.bgImageView.isHidden = true
            cell.imageView.isHidden = false
            cell.deleteButton.isHidden = false
            cell.imageView.image = imageArr[indexPath.row]
            cell.deleteButton.tag = indexPath.row
            cell.deleteButton.addTarget(self, action: #selector(deleteImage(button:)), for: .touchUpInside)
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if imageArr.count < 5 && imageArr.count == indexPath.row {
            self.photoPicker.showPhotoLibrary(sender: self)
        }
        
        
    }
    
}
extension AddWorksViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: AddWorksChooseCell = tableView.dequeueReusableCell(withIdentifier: "AddWorksChooseCell") as! AddWorksChooseCell
        if indexPath.row == 0 {
            cell.iconImageView.image = UIImage(named: "icon_address")
            cell.titleLabel.text = "Suburb"
            cell.detailLabel.text = self.address
        } else if indexPath.row == 1 {
            cell.iconImageView.image = UIImage(named: "icon_category")
            cell.titleLabel.text = "Category L"
            cell.detailLabel.text = self.categoryL?.chName
        } else {
            cell.iconImageView.image = UIImage(named: "icon_category")
            cell.titleLabel.text = "Category S"
            cell.detailLabel.text = self.categoryS?.chName
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            let addressView = ChooseAddressView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: 335+UIDevice.xp_safeDistanceBottom()))
            addressView.areaList = self.areaList
            let alertVc = TYAlertController(alert: addressView, preferredStyle: .actionSheet)
            alertVc?.backgoundTapDismissEnable = true
            addressView.cancelBlock = {
                alertVc?.dismiss(animated: true)
            }
            addressView.okBlock = { [weak self] (stateIndex,cityIndex,suburbIndex) in
                guard let wSelf = self else { return }
                wSelf.setZoonId(stateIndex: stateIndex, cityIndex: cityIndex, suburbIndex: suburbIndex)
                alertVc?.dismiss(animated: true)
            }
            self.present(alertVc!, animated: true)
            
        } else if indexPath.row == 1{
            guard let channelModel = self.channelModel else { return }
            var dataArr: [String] = []
            for model in channelModel.CategoryL {
                dataArr.append(model.chName)
            }
            let sheetView = CustomSheetView(frame: .zero, title: "", dataArr: dataArr)
            sheetView.buttonClick = { index in
                self.categoryL = channelModel.CategoryL[index]
                self.tableView.reloadData()
            }
            sheetView.show()
        } else {
            guard let channelModel = self.channelModel else { return }
            var dataArr: [String] = []
            for model in channelModel.CategoryS {
                dataArr.append(model.chName)
            }
            let sheetView = CustomSheetView(frame: .zero, title: "", dataArr: dataArr)
            sheetView.buttonClick = { index in
                self.categoryS = channelModel.CategoryS[index]
                self.tableView.reloadData()
            }
            sheetView.show()
        }
    }
    
}
