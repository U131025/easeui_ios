//
//  GiftInfoViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/8/23.
//

import UIKit
import WebKit
import MCToast

class GiftInfoViewController: BaseViewController {
    
    var newsId: String?
    
    private var model: ColumnListModel?
    
    private lazy var webView : WKWebView = {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true //可以禁止弹出全屏  网页video标签要加上 playsinline 这个属性
        let web = WKWebView(frame: .zero, configuration: config)
        return web
    }()
   
    lazy var headerView: WebNavView = {
        let view = WebNavView(frame: .zero)
        return view
    }()
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        self.creartUI()
        self.loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: false)

    }
    
    
    override func loadData() {
        guard let newsId = self.newsId else { return }

        ApiManager.getColumnNews(newsId: newsId, handler: { model, errorMsg in
            if model != nil {
                self.model = model
                self.reloadData()
            } else {
                if let msg = errorMsg {
                    MCToast.mc_text(msg)
                }
            }
        })
        
    }
    
    private func reloadData() {
        guard let model = self.model else { return }
        self.headerView.statusLine.isHidden = true
        self.headerView.statusLabel.isHidden = true
        self.headerView.titleLabel.text = model.title
        self.headerView.timeLabel.text = model.createTime
        
        var height = model.title?.getHeightWithAttributes([.font : UIFont.PingFangSCSemibold(size: 17)] ,ScreenWidth - 66) ?? 22
        height += 48
        self.headerView.snp.updateConstraints { make in
            make.height.equalTo(height)
        }
        guard let decodedData = Data(base64Encoded: model.content,options: NSData.Base64DecodingOptions.ignoreUnknownCharacters) else { return }
        let decodedString = NSString(data: decodedData, encoding: NSUTF8StringEncoding)! as String
//        let htmlStr = self.formatHtml(str: decodedString)

        self.webView.loadHTMLString(decodedString, baseURL: nil)
        
    }

    
    @objc dynamic func formatHtml(str: String) -> String {
        // 为图片路径添加domain
        let body = str
        let style = "<style type=\"text/css\">" +
                "html{margin:0;padding:0 30px;}" +
                "body {" +
                "margin: 0;" +
                "padding: 0;" +
                "font-size: 20px;" +
                "}" +
                "img{" +
                "width: 100%;" +
                "height: auto;" +
                "display: block;" +
                "margin-left: auto;" +
                "margin-right: auto;" +
                "}" +
                "</style>"
        let headerString : String = "<header><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no'>\(style)</header>"
        let content = headerString + body
        
        return content
    }
    
    // MARK:  UI
    
    private func creartUI() {
        
        self.view.addSubview(headerView)
        headerView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(UIDevice.xp_safeDistanceTop())
            make.left.right.equalToSuperview()
            make.height.equalTo(64)
        }
        self.view.addSubview(webView)
        webView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.equalToSuperview()
        }
        
    }
    
}
