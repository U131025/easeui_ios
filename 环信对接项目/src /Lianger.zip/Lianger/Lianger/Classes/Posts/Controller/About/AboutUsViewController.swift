//
//  AboutUsViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/8/11.
//

import UIKit

class AboutUsViewController: BaseViewController {

    private lazy var logoImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "app_logo"))
        return imageView
    }()
    
    lazy var versionLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSC(size: 15)
        return label
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.creartUI()
    }
    

    private func didSeleteItem(index: Int) {
        
        let nextVc = CustomWebViewController(type: WebLoadType(rawValue: index)!)
        
        self.navigationController?.pushViewController(nextVc, animated: true)
        
    }
  
    
    private func creartUI() {
        
        self.view.addSubview(logoImageView)
        logoImageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(40)
        }
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
        versionLabel.text = "Version \(version)"
        self.view.addSubview(versionLabel)
        versionLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(logoImageView.snp.bottom).offset(25)
        }
        
        let registrationItem = AboutUsItemView(frame: .zero)
        registrationItem.vm = AboutUsItemView.VM(icon: "policy_icon",title: "Registration Agreement")
        self.view.addSubview(registrationItem)
        registrationItem.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(25)
            make.height.equalTo(70)
            make.top.equalTo(versionLabel.snp.bottom).offset(40)
        }
        registrationItem.didSeleteAction = {
            self.didSeleteItem(index: 1)
        }
        
        let privacyItem = AboutUsItemView(frame: .zero)
        privacyItem.vm = AboutUsItemView.VM(icon: "policy_icon",title: "Privacy Policy")
        self.view.addSubview(privacyItem)
        privacyItem.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(25)
            make.height.equalTo(70)
            make.top.equalTo(registrationItem.snp.bottom).offset(12)
        }
        privacyItem.didSeleteAction = {
            self.didSeleteItem(index: 2)
        }
        
        let aboutItem = AboutUsItemView(frame: .zero)
        aboutItem.vm = AboutUsItemView.VM(icon: "about_icon",title: "About us")
        self.view.addSubview(aboutItem)
        aboutItem.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(25)
            make.height.equalTo(70)
            make.top.equalTo(privacyItem.snp.bottom).offset(12)
        }
        
        aboutItem.didSeleteAction = {
            self.didSeleteItem(index: 3)
        }
    }

}
