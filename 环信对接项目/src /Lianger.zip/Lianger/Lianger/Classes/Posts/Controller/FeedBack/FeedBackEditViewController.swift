//
//  FeedBackEditViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/28.
//

import UIKit
import QMUIKit
import MCToast

class FeedBackEditViewController: BaseViewController {

    private lazy var textView: QMUITextView = {
        let textView = QMUITextView(frame: .zero)
        textView.placeholderColor = UIColor.placeholdColor
        textView.placeholder = "Content text"
        textView.tintColor = UIColor.inputTintColor
        textView.textColor = UIColor.blackText
        textView.font = UIFont.PingFangSCMedium(size: 15)
        textView.delegate = self
        textView.isEditable = true
        return textView
    }()
    private lazy var countLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSC(size: 13)
        label.textAlignment = .right
        label.text = "0/500"
        return label
    }()
    lazy var bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        let button = UIButton(type: .custom)
        button.setTitle("Post", for: .normal)
        button.setTitleColor(UIColor.blackText, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 18)
        button.addTarget(self, action: #selector(bottomButtonAction(button:)), for: .touchUpInside)
        button.backgroundColor = UIColor.mainYellow
        button.showCorner(30)
        view.addSubview(button)
        button.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.right.equalToSuperview().inset(25)
            make.height.equalTo(60)
        }
        
        let lineView = UIView()
        lineView.backgroundColor = UIColor.greyE6
        view.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(1)
        }
        return view
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.showLine()
        self.creartUI()
    }
    
    
    @objc private func bottomButtonAction(button: UIButton) {
        
        let content = textView.text
        if content == nil || content!.isBlank {
            MCToast.mc_text("Please enter content")
        } else {
            ApiManager.addFeedback(params: ["content" : content!]) { success, errorMsg in
                if success {
                    MCToast.mc_text("sucess",duration: 1) {
                        self.navigationController?.popViewController(animated: true)
                    }
                } else {
                    if let msg = errorMsg {
                        MCToast.mc_text(msg)
                    }
                }
                
            }
            
        }
    }

    private func creartUI() {
        
        self.view.addSubview(bottomView)
        bottomView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
            make.height.equalTo(88)
        }
       
        self.view.addSubview(textView)
        textView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview().inset(20)
            make.bottom.equalTo(bottomView.snp.top).offset(-30)
        }
        
        self.view.addSubview(countLabel)
        countLabel.snp.makeConstraints { make in
            make.right.equalToSuperview().offset(-20)
            make.top.equalTo(textView.snp.bottom)
        }
        
    }



}


extension FeedBackEditViewController: QMUITextViewDelegate {
    func textView(_ textView: QMUITextView!, shouldChangeTextIn range: NSRange, replacementText text: String!, originalValue: Bool) -> Bool {

        let string = textView.text + text
        
        let count = string.getWordCount()
        
        countLabel.text = "\(count)/500"
        
        if count > 500 {
            return false
        }
        return true

    }
}
