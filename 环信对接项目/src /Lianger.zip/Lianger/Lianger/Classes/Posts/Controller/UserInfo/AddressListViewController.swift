//
//  AddressListViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/28.
//

import UIKit
import MCToast

class AddressListViewController: BaseViewController {

    var isChoose: Bool = false
    var chooseAddressComplect: ((_ model: UserAddressModel) -> Void)?
    
    private var addressList: [UserAddressModel] = []
    private lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.bounces = false
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.register(AddressCell.self, forCellReuseIdentifier: "AddressCell")
        self.placeholdView.placeType(.nodata)
        tableView.backgroundView = self.placeholdView
        return tableView
    }()
    
    lazy var bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    lazy var addButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Add Address", for: .normal)
        button.setTitleColor(UIColor.blackText, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 18)
        button.setImage(UIImage(named: "icon_release"), for: .normal)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: -5, bottom: 0, right: 0)
        button.addTarget(self, action: #selector(addAddressAction(button:)), for: .touchUpInside)
        button.backgroundColor = UIColor.mainYellow
        button.showCorner(30)
        return button
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.title = "Address"
        self.showLine()
        self.creartUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.loadData()
    }
    
    override func loadData() {
        ApiManager.getUserAddressList { list, errorMsg in
            if list != nil && list!.count > 0 {
                self.tableView.backgroundView?.isHidden = true
                self.addressList = list!
                self.tableView.reloadData()
            } else {
                self.tableView.backgroundView?.isHidden = false
            }
        }
        
    }
    
    func deleteAddressAction(index: Int) {
        if self.addressList.count > index {
            let model = self.addressList[index]
            let params = ["ids" : [model.id!]]
            ApiManager.deleteUserAddress(params: params) { success, errorMsg in
                if success {
                    self.loadData()
                } else {
                    if let msg = errorMsg {
                        MCToast.mc_text(msg)
                    }
                }
                
            }
            
        }
    }
    

    @objc func addAddressAction(button: UIButton) {
        
        let addVc = EditAddressViewController()
        self.navigationController?.pushViewController(addVc, animated: true)
        
    }
    
        
    private func creartUI() {
        
        self.view.addSubview(bottomView)
        bottomView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
            make.height.equalTo(88)
        }
        bottomView.addSubview(addButton)
        addButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.left.right.equalToSuperview().inset(25)
            make.height.equalTo(60)
        }
        
        let lineView = UIView()
        lineView.backgroundColor = UIColor.greyE6
        bottomView.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(1)
        }
        
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(10)
            make.top.equalToSuperview().offset(1)
            make.bottom.equalTo(bottomView.snp.top)
        }
        
    }
    
   
    
    

}


extension AddressListViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.addressList.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 94
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: AddressCell = tableView.dequeueReusableCell(withIdentifier: "AddressCell") as! AddressCell
        if self.addressList.count > indexPath.row {
            cell.model = self.addressList[indexPath.row]
        }
        return cell
    }
    

    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let delete = UIContextualAction(style: .normal, title: "") { action, view, completionHandler in
            self.deleteAddressAction(index: indexPath.row)
            completionHandler(true)
        }
        delete.backgroundColor = UIColor.hexColor(hex: 0xFFE0E0)
        delete.image = UIImage(named: "icon_deleted")
        let configuration = UISwipeActionsConfiguration(actions: [delete])
        
        return configuration
        
    }
    
    //设置点击删除之后的操作
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            
        } else if editingStyle == .insert {
            
        }
    }
    
 
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if self.isChoose {
            self.chooseAddressComplect?(self.addressList[indexPath.row])
            self.navigationController?.popViewController(animated: true)
        }
    
    }
    
}
