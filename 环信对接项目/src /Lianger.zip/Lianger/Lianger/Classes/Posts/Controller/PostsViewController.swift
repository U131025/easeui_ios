//
//  PostsViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/7.
//

import UIKit

class PostsViewController: BaseViewController {

    private lazy var navView: PostsNavView = {
        let navView = PostsNavView(frame: .zero)
        return navView
    }()
    private var currentIndex: Int = 0
    private lazy var vcScrollView: UIScrollView = {
        let scroll = UIScrollView.init(frame:.zero)
        scroll.delegate = self
        scroll.backgroundColor = UIColor.clear
        scroll.showsVerticalScrollIndicator = false
        scroll.showsHorizontalScrollIndicator = false
        scroll.isPagingEnabled = true
        scroll.isScrollEnabled = false
        scroll.bounces = false
        scroll.contentSize = CGSize.init(width: ScreenWidth * CGFloat(self.children.count), height: 0)
        return scroll
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
        self.creatUI()
        NotificationCenter.default.addObserver(self, selector: #selector(userAvatarChange), name: NotiKey.didUserAvatarChanged, object: nil)

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        
        if self.children.count > self.currentIndex {
            let childVc: BaseViewController = self.children[self.currentIndex] as! BaseViewController
            childVc.loadData()
        }
       
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: false)

    }
    @objc func userAvatarChange() {
        self.navView.userAcatarChange()
    }
    
    fileprivate func setUpChildViewController() {
        //home
        let cityVc = HomePostViewController()

        self.addChild(cityVc)
        //Follow
        let suburbVc = FollowPostViewController()

        self.addChild(suburbVc)

        //Favorate
        let favorateVc = FavorateViewController()

        self.addChild(favorateVc)

        //userInfo
        let userVc = UserInfoViewController()

        self.addChild(userVc)
        
    }

    

    ///
    func creatUI() {
        self.view.addSubview(navView)
        navView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.height.equalTo(UIDevice.xp_navigationBarHeight())
            make.top.equalTo(UIDevice.xp_safeDistanceTop())
        }
        navView.navButtonClickAction = { [weak self] index in
            guard let self = self else { return }
            self.navButtonClick(index: index)
        }
        setUpChildViewController()

        self.view.addSubview(vcScrollView)
        vcScrollView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalTo(navView.snp.bottom)
            make.height.equalTo(ScreenHeight - UIDevice.xp_navigationFullHeight() - UIDevice.xp_tabBarFullHeight())

        }
        self.scrollViewDidEndScrollingAnimation(vcScrollView)
     
        
    }

    func navButtonClick(index: Int) {
        self.currentIndex = index
        if index < 4 {
            var offset:CGPoint = vcScrollView.contentOffset
            offset.x = CGFloat(index) * ScreenWidth
            vcScrollView.setContentOffset(offset, animated: true)
            let baseVc: BaseViewController = self.children[index] as! BaseViewController
            if index < 3 {
                baseVc.loadData()
            }
        } else if index == 4 {
            let nextVc = AddWorksViewController()
            self.navigationController?.pushViewController(nextVc, animated: true)
        }
        
    }

    

}

extension PostsViewController: UIScrollViewDelegate {
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        if scrollView.isEqual(vcScrollView){
            let index:Int = Int(scrollView.contentOffset.x / ScreenWidth)
            let childVc = self.children[index]
            childVc.view.frame = CGRect.init(x: scrollView.contentOffset.x, y: 0, width: ScreenWidth, height: vcScrollView.frame.size.height)
            scrollView.addSubview(childVc.view)
        }
    }
    
}
