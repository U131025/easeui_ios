//
//  PostsModels.swift
//  Lianger
//
//  Created by Qidi on 2023/8/9.
//

import UIKit

class ChannelModel:BaseModel {
    
    //
    var CategoryL: [CategoryModel] = []
    //
    var CategoryS: [CategoryModel] = []
    
}


class CategoryModel: BaseModel {
    
    //
    var chId: String?
    //
    var chName: String = ""
    //
    var categoryId: Int?
    //
    var status: Int?
    //
    var isChoose: Bool = false
}



class WebModel: BaseModel {
    ///
    var id: String?
    ///类型
    var type: String?
    ///标题
    var title: String = ""
    ///内容
    var content: String = ""
}


class FeedBackModel: BaseModel {
    ///主键ID
    var id: String?
    ///反馈用户ID
    var userId: String?
    ///回复状态（0未回复 1已回复）
    var replyStatus: Int = 0
    ///内容
    var content: String = ""
    ///创建时间
    var createTime: String = ""
    ///回复内容
    var replyContent: String?
    ///后台回复用户ID
    var adminReplyUserId: String?
    ///后台回复用户名
    var adminReplyUserName: String?
    ///回复时间
    var replyTime: String?
    ///反馈用户昵称
    var nickName: String?
    ///反馈用户手机号
    var phone: String?
    ///反馈用户邮箱
    var email: String?
}


class NoticeModel: BaseModel {
    ///主键ID
    var noticeId: String?
    ///创建时间
    var createTime: String = ""
    ///标题
    var noticeTitle: String?
    ///已读标识（0未读 1已读）
    var status: Int = 0
}
class NoticeInfoModel: BaseModel {
    ///主键ID
    var noticeId: String?
    ///创建时间
    var createTime: String = ""
    ///标题
    var noticeTitle: String?
    ///内容（需base64解码）
    var noticeContent: String = ""
    ///是否需要收集收货地址（0否 1是）
    var isCollectAddress: Int = 0
    ///是否已到截止日期（0否 1是）
    var isExpired: Int = 0
    ///用户ID
    var userId: String?
    ///已读标识（0未读 1已读）
    var status: Int = 0
    ///公告的地址ID
    var addressId: String?
    
}


class UserAddressModel: BaseModel {
    ///主键ID
    var id: String?
    ///用户ID
    var userId: String?
    ///联系人
    var contactPerson: String?
    ///联系号码
    var contactNumber: String?
    ///大区域
    var zoneL: String?
    ///中区域
    var zoneM: String?
    ///小区域
    var zoneS: String?
    ///大区域名称
    var zoneLName: String = ""
    ///中区域名称
    var zoneMName: String = ""
    ///小区域名称
    var zoneSName: String = ""
    ///详细地址
    var detailedAddress: String = ""
    ///默认地址状态（0否 1是）
    var defaultStatus: Int = 0
    
}

class ColumnModel: BaseModel {
    ///主键ID
    var columnId: String?
    ///名称
    var name: String?
    ///icon图标
    var icon: String?
    ///状态值 来源字典：app_column_status
    var status: Int = 0
}

class ColumnListModel: BaseModel {
    ///主键ID
    var newsId: String?
    ///栏目类型
    var columnId: String?
    ///标题
    var title: String?
    ///副标题
    var subtitle: String?
    ///封面图
    var picture: String?
    ///封面图对象存储主键
    var ossId: String?
    ///内容
    var content: String = ""
    ///创建时间
    var createTime: String?

}

