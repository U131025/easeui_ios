//
//  CustomSheetView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/28.
//

import UIKit

class CustomSheetView: UIView {

    var buttonClick: ((Int) -> Void)?
    private var title: String = ""
    private var dataArr: [String] = []
    private var currentValue: String = ""
    private var contentHeight: CGFloat = 298 + UIDevice.xp_safeDistanceBottom()
    private var seletedIndex: Int = 0

    private lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 20
        view.layer.masksToBounds = true
        return view
    }()
    private lazy var comfirmBtn: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("OK", for: .normal)
        button.setTitleColor(UIColor.buttonYellow, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 15)
        button.tag = 10
        button.addTarget(self, action: #selector(buttonClick(button:)), for: .touchUpInside)
        return button
    }()
    private lazy var cancelBtn: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("Cancel", for: .normal)
        button.setTitleColor(UIColor.grey99, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 15)
        button.layer.cornerRadius = 4
        button.layer.masksToBounds = true
        button.tag = 20
        button.addTarget(self, action: #selector(buttonClick(button:)), for: .touchUpInside)
        return button
    }()
    
    private lazy var pickerView: UIPickerView = {
        let picker = UIPickerView.init(frame: .zero)
        picker.delegate = self
        picker.dataSource = self
        return picker
    }()

    init(frame: CGRect,title: String,dataArr: [String],contentHeight: CGFloat = 0,currentValue: String = "") {
        super.init(frame: UIScreen.main.bounds)
        self.backgroundColor = UIColor(r: 0, g: 0, b: 0, a: 0.3)
        self.title = title
        let tap: UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(closeClick))
        tap.delegate = self
        self.addGestureRecognizer(tap)
        if contentHeight > 0 {
            self.contentHeight = contentHeight
        }
        self.currentValue = currentValue
        self.creartUI()
        self.dataArr = dataArr
        let row:Int = dataArr.firstIndex(of: currentValue) ?? 0
        
        self.pickerView.selectRow(row, inComponent: 0, animated: true)
        self.pickerView.reloadAllComponents()
    }
    
    private func creartUI() {
        contentView.frame = CGRect(x: 0, y: ScreenHeight, width: ScreenWidth, height: contentHeight)
        self.addSubview(contentView)

        contentView.addSubview(cancelBtn)
        cancelBtn.snp.makeConstraints { make in
            make.left.top.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(0.5)
            make.height.equalTo(70)
        }
        contentView.addSubview(comfirmBtn)
        comfirmBtn.snp.makeConstraints { make in
            make.right.top.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(0.5)
            make.height.equalTo(70)
        }
        let lineView = UIView()
        lineView.backgroundColor = UIColor.greyE6
        contentView.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().offset(70)
            make.height.equalTo(1)
        }

        contentView.addSubview(pickerView)
        pickerView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().offset(71)
            make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
        }

        
    }
    
    
    func show() {
        UIApplication.shared.keyWindow?.addSubview(self)
        UIView.animate(withDuration: 0.25) {
            self.contentView.transform = CGAffineTransform.init(translationX: 0, y: -self.contentHeight)
        }
    }
    @objc func closeClick() {
        UIView.animate(withDuration: 0.25) {
            self.contentView.transform = CGAffineTransform.identity
        } completion: { (Completion) in
            self.removeFromSuperview()
        }
    }
    @objc func buttonClick(button: UIButton) {
        if button.tag == 10 {
            buttonClick?(seletedIndex)
        }
        self.closeClick()
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


extension CustomSheetView: UIPickerViewDelegate,UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.dataArr.count
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 48.0
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 16)
        label.textAlignment = .center
        label.text = self.dataArr[row]
        return label
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.seletedIndex = row
    }
}
extension CustomSheetView: UIGestureRecognizerDelegate {
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        let point: CGPoint = touch.location(in: self)
        if point.y > ScreenHeight - contentHeight {
            return false
        } else {
            return true
        }
    }
}
