//
//  CustomSheetViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/8/9.
//

import UIKit

class CustomSheetViewController: UIViewController {

    var buttomClick: ((Bool) -> Void)?

    private lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        view.layer.masksToBounds = true
        return view
    }()
    private lazy var comfirmBtn: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("OK", for: .normal)
        button.setTitleColor(UIColor.buttonYellow, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 15)
        button.tag = 10
        button.addTarget(self, action: #selector(buttonClick(button:)), for: .touchUpInside)
        return button
    }()
    private lazy var cancelBtn: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("Cancel", for: .normal)
        button.setTitleColor(UIColor.grey99, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 15)
        button.layer.cornerRadius = 4
        button.layer.masksToBounds = true
        button.tag = 20
        button.addTarget(self, action: #selector(buttonClick(button:)), for: .touchUpInside)
        return button
    }()
    
    private lazy var pickerView: UIPickerView = {
        let picker = UIPickerView.init(frame: .zero)
        picker.delegate = self
        picker.dataSource = self
        return picker
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    

    func show(in parentVC: UIViewController? = nil, animated: Bool = false) {
        self.modalPresentationStyle = .overFullScreen
        if let parentVC = parentVC {
            parentVC.present(self, animated: animated)
        } else if let window = UIApplication.shared.keyWindow,let vc = window.rootViewController {
            vc.present(self, animated: animated)
        }
    }

    
    @objc func buttonClick(button: UIButton) {
        if button.tag == 10 {
            buttomClick?(true)
        } else {
            buttomClick?(false)
        }
        self.dismiss(animated: false)
    }
    
    private func creartUI() {
       
    }
    
    
    

    
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
    
    
}
extension CustomSheetViewController: UIPickerViewDelegate,UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 10
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 48.0
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 16)
        label.textAlignment = .center
        
        return label
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
    }
}
