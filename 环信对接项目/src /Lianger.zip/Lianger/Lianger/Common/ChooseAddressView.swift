//
//  ChooseAddressView.swift
//  Lianger
//
//  Created by Qidi on 2023/7/19.
//

import UIKit
import MCToast

class ChooseAddressView: UIView {

    var cancelBlock:(() -> Void)?
    var okBlock:((_ stateIndex: Int,_ cityIndex: Int,_ suburbIndex: Int) -> Void)?
    
    private lazy var headerView: UIView = {
        let view = UIView()
        return view
    }()
    private lazy var cancelBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Cancel", for: .normal)
        button.setTitleColor(UIColor.grey98, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSC(size: 15)
        button.addTarget(self, action:#selector(cancelAction), for: .touchUpInside)
        return button
    }()
    private lazy var okBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("OK", for: .normal)
        button.setTitleColor(UIColor.buttonYellow, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSC(size: 15)
        button.addTarget(self, action:#selector(comfirmAction), for: .touchUpInside)
        return button
    }()
    private lazy var lineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.greyE6
        return view
    }()
    private lazy var stateLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 19)
        label.textColor = UIColor.blackText
        label.textAlignment = .center
        label.text = "State"
        return label
    }()
    private lazy var cityLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 19)
        label.textColor = UIColor.blackText
        label.textAlignment = .center
        label.text = "City"
        return label
    }()
    private lazy var suburbLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 19)
        label.textColor = UIColor.blackText
        label.textAlignment = .center
        label.text = "Suburb"
        return label
    }()
    private lazy var pickerView: UIPickerView = {
        let picker = UIPickerView.init(frame: .zero)
        picker.delegate = self
        picker.dataSource = self
        return picker
    }()
    private lazy var stateYellowView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackText
        return view
    }()
    private lazy var cityYellowView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackText
        return view
    }()
    private lazy var suburbYellowView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackText
        return view
    }()
    
    private var fisrtArray: [AreaModel] = []
    private var secondArray: [AreaModel] = []
    private var threeArray: [AreaModel] = []
    private var fisrtIndex: Int = 0
    private var secondIndex: Int = 0
    private var threeIndex: Int = 0


    var areaList: [AreaModel]? {
        didSet {
            guard let areaList = areaList else { return }
            self.fisrtArray = areaList
            self.calculatePickerData()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.creatUI()
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:  Action
    
    @objc private func cancelAction() {
        self.cancelBlock?()
    }
    @objc private func comfirmAction() {
        if self.threeArray.isEmpty {
            MCToast.mc_text("Please Select Suburb")
            return
        }
        self.okBlock?(fisrtIndex,secondIndex,threeIndex)
    }
    func calculatePickerData() {
        if self.fisrtArray.isEmpty { return }
        self.secondArray.removeAll()
        self.threeArray.removeAll()
        let fisrtModel = self.fisrtArray[fisrtIndex]
        self.secondArray = fisrtModel.children

        if secondArray.count > secondIndex {
            let secondModel = self.secondArray[secondIndex]
            self.threeArray = secondModel.children
        }
       
    }
    // MARK:  ui
    private func creatUI() {
        self.extCorner(rect: CGRect(x: 0, y: 0, width: ScreenWidth, height: 335+UIDevice.xp_safeDistanceBottom()),corners: UIRectCorner(rawValue: UIRectCorner.topLeft.rawValue | UIRectCorner.topRight.rawValue), radii: 25)
        self.addSubview(headerView)
        headerView.snp.makeConstraints { make in
            make.left.top.right.equalToSuperview()
            make.height.equalTo(70)
        }
        let buttonW = (ScreenWidth - 34) / 2.0
        headerView.addSubview(cancelBtn)
        cancelBtn.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.width.equalTo(buttonW)
            make.left.equalToSuperview().offset(17)
        }
        
        headerView.addSubview(okBtn)
        okBtn.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.width.equalTo(buttonW)
            make.right.equalToSuperview().offset(-17)
        }
        self.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalTo(headerView.snp.bottom)
            make.height.equalTo(1)
        }
        let labelW = ScreenWidth / 3.0
        self.addSubview(stateLabel)
        stateLabel.snp.makeConstraints { make in
            make.width.equalTo(labelW)
            make.top.equalTo(lineView.snp.bottom).offset(20)
        }
        self.insertSubview(stateYellowView, belowSubview: stateLabel)
        stateYellowView.snp.makeConstraints { make in
            make.centerX.equalTo(stateLabel)
            make.bottom.equalTo(stateLabel).offset(2)
            make.height.equalTo(2)
            make.width.equalTo(46)
        }
        
        self.addSubview(cityLabel)
        cityLabel.snp.makeConstraints { make in
            make.top.equalTo(stateLabel)
            make.width.equalTo(labelW)
            make.left.equalTo(stateLabel.snp.right)
        }
        
        self.insertSubview(cityYellowView, belowSubview: cityLabel)
        cityYellowView.snp.makeConstraints { make in
            make.centerX.equalTo(cityLabel)
            make.bottom.equalTo(cityLabel).offset(2)
            make.height.equalTo(2)
            make.width.equalTo(35)
        }
        
        self.addSubview(suburbLabel)
        suburbLabel.snp.makeConstraints { make in
            make.top.equalTo(stateLabel)
            make.width.equalTo(labelW)
            make.left.equalTo(cityLabel.snp.right)
        }
        self.insertSubview(suburbYellowView, belowSubview: suburbLabel)
        suburbYellowView.snp.makeConstraints { make in
            make.centerX.equalTo(suburbLabel)
            make.bottom.equalTo(suburbLabel).offset(2)
            make.height.equalTo(2)
            make.width.equalTo(62)
        }
        
        self.addSubview(pickerView)
        pickerView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalTo(lineView.snp.bottom).offset(44)
            make.bottom.equalToSuperview().offset(-UIDevice.xp_safeDistanceBottom())
        }
        
    }
    
    

}


extension ChooseAddressView: UIPickerViewDelegate,UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 3
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if component == 0 {
            return self.fisrtArray.count
        } else if component == 1{
            return self.secondArray.count
        } else {
            return self.threeArray.count
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 48.0
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 16)
        label.textAlignment = .center
        if component == 0 {
            if self.fisrtArray.count > row {
                label.text = self.fisrtArray[row].areaName
            }
        } else if component == 1 {
            if self.secondArray.count > row {
                label.text = self.secondArray[row].areaName
            }
        } else {
            if self.threeArray.count > row {
                label.text = self.threeArray[row].areaName
            }
        }
        return label
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0 {
            self.fisrtIndex = row
            self.secondIndex = 0
            self.threeIndex = 0
            self.calculatePickerData()
            self.pickerView.reloadAllComponents()
            self.pickerView.selectRow(0, inComponent: 1, animated: false)
            self.pickerView.selectRow(0, inComponent: 2, animated: false)
        } else if component == 1 {
            self.secondIndex = row
            self.threeIndex = 0
            self.calculatePickerData()
            self.pickerView.reloadComponent(1)
            self.pickerView.reloadComponent(2)
            self.pickerView.selectRow(0, inComponent: 2, animated: false)
        } else {
            self.threeIndex = row
            self.calculatePickerData()
            self.pickerView.reloadComponent(2)
        }
    }
}
