//
//  URefresh.swift
//  HuaHuiEmployeesProject
//
//  Created by huahui on 2021/11/15.
//

import UIKit
import MJRefresh


extension UIScrollView {
    var uHead: MJRefreshHeader {
        get { return mj_header! }
        set { mj_header = newValue }
    }
    var uFoot: MJRefreshFooter {
        get { return mj_footer! }
        set { mj_footer = newValue }
    }
}

class URefreshNormalHeader: MJRefreshNormalHeader {
    override func prepare() {
        super.prepare()
        lastUpdatedTimeLabel?.textColor = UIColor.grey99
        lastUpdatedTimeLabel?.font = UIFont.PingFangSC(size: 12)
        stateLabel?.font = UIFont.PingFangSC(size: 12)
        stateLabel?.textColor = UIColor.grey99
//        setTitle("", for: .idle)
//        setTitle("", for: .pulling)
//        setTitle("", for: .refreshing)
//        setTitle("", for: .willRefresh)
//        setTitle("", for: .noMoreData)
    }
}

class URefreshFooter: MJRefreshAutoNormalFooter {
    override func prepare() {
        super.prepare()
        stateLabel?.font = UIFont.PingFangSC(size: 12)
        stateLabel?.textColor = UIColor.grey99
        
        setTitle("Click or pull up to load more", for: .idle)
    }
}

class URefreshAutoHeader: MJRefreshHeader {}

class URefreshAutoFooter: MJRefreshAutoFooter {}
