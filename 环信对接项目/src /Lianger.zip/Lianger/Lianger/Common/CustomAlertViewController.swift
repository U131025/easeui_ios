//
//  CustomAlertViewController.swift
//  Lianger
//
//  Created by Qidi on 2023/8/9.
//

import UIKit

class CustomAlertViewController: UIViewController {
    
    var buttomClick: ((Bool) -> Void)?
    private var titleText: String?
    private var message: String?
    private var tipImage: String?
    private var comfirmText: String?
    private var cancelText: String?
    private var itemViews: [UIView]?
    private var itemHeight: CGFloat = 0
    private var space: CGFloat = 28

    private lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        view.layer.masksToBounds = true
        return view
    }()
    private lazy var tipsImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCBold(size: 23)
        label.textAlignment = .center
        label.textColor = UIColor.blackText
        label.numberOfLines = 0
        return label
    }()
    private lazy var contentLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.PingFangSCMedium(size: 15)
        label.textAlignment = .center
        label.textColor = UIColor.grey99
        label.numberOfLines = 0
        return label
    }()
    private lazy var comfirmBtn: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("Comfirm", for: .normal)
        button.setTitleColor(UIColor.buttonYellow, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 15)
        button.tag = 10
        button.addTarget(self, action: #selector(buttonClick(button:)), for: .touchUpInside)
        return button
    }()
    private lazy var cancelBtn: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("Cancel", for: .normal)
        button.setTitleColor(UIColor.grey99, for: .normal)
        button.titleLabel?.font = UIFont.PingFangSCBold(size: 15)
        button.layer.cornerRadius = 4
        button.layer.masksToBounds = true
        button.tag = 20
        button.addTarget(self, action: #selector(buttonClick(button:)), for: .touchUpInside)
        return button
    }()
    
    private lazy var stackView: UIStackView = {
        let view = UIStackView()
        view.axis = .vertical
        view.alignment = .fill
        view.distribution = .fillEqually
        return view
    }()
    

    func addItem(items: [UIView]) {
        for view in items {
            self.stackView.addArrangedSubview(view)
        }
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    init(title: String?, message: String?,itemViews: [UIView]?,itemHeight: CGFloat = 50.0,space: CGFloat = 28.0,comfirmText: String?,cancelText:String?,comfirmTextColor: UIColor = UIColor.buttonYellow) {
        super.init(nibName: nil, bundle: nil)
        
        self.view.backgroundColor = UIColor(r: 0, g: 0, b: 0, a: 0.3)
        self.titleText = title
        self.message = message
        self.itemViews = itemViews
        self.itemHeight = itemHeight
        self.space = space
        self.comfirmText = comfirmText
        self.cancelText = cancelText
        self.comfirmBtn.setTitleColor(comfirmTextColor, for: .normal)
        self.setUpSubViews()

    }
    
    private func setUpSubViews () {
        var contentHeight:CGFloat = 0
        let contentWidth = ScreenWidth - 2.0 * self.space
        self.view.addSubview(contentView)
        contentView.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.equalTo(contentWidth)
            make.height.equalTo(270)
        }
       
        contentView.addSubview(titleLabel)
        titleLabel.text = titleText
       
        titleLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(45)
            make.left.right.equalToSuperview().inset(20)
        }
        contentHeight += (titleText?.getHeightWithAttributes([.font : UIFont.PingFangSCBold(size: 23)], 225))! + 25
 
        if message != nil {
            contentView.addSubview(contentLabel)
            contentLabel.text = message
            contentLabel.snp.makeConstraints { make in
                make.top.equalTo(titleLabel.snp.bottom).offset(30)
                make.left.right.equalToSuperview().inset(12)
            }
            contentHeight += (message?.getHeightWithAttributes([.font : UIFont.PingFangSCMedium(size: 15)], 241))! + 8
        }
        
        if let itemViews = self.itemViews {
            contentView.addSubview(stackView)
            stackView.snp.makeConstraints { make in
                make.centerY.equalToSuperview()
                make.left.right.equalToSuperview().inset(20)
                make.height.equalTo(CGFloat(itemViews.count) * itemHeight)
            }
            
            for view in itemViews {
                stackView.addArrangedSubview(view)
            }
            contentHeight += CGFloat(itemViews.count) * itemHeight + 60
        }
        
        let lineView = UIView()
        lineView.backgroundColor = UIColor.placeholdColor
        contentView.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.height.equalTo(1)
            make.bottom.equalToSuperview().offset(-50)
        }
        
        if cancelText != nil {
            contentView.addSubview(cancelBtn)
            cancelBtn.setTitle(cancelText, for: .normal)
            cancelBtn.snp.makeConstraints { make in
                make.left.bottom.equalToSuperview()
                make.width.equalToSuperview().multipliedBy(0.5)
                make.height.equalTo(50)
            }
            contentView.addSubview(comfirmBtn)
            comfirmBtn.setTitle(comfirmText, for: .normal)
            comfirmBtn.snp.makeConstraints { make in
                make.right.bottom.equalToSuperview()
                make.width.equalToSuperview().multipliedBy(0.5)
                make.height.equalTo(50)
            }
            let columLineView = UIView()
            columLineView.backgroundColor = UIColor.placeholdColor
            contentView.addSubview(columLineView)
            columLineView.snp.makeConstraints { make in
                make.centerX.equalToSuperview()
                make.width.equalTo(1)
                make.bottom.equalToSuperview()
                make.height.equalTo(50)
            }
        } else {
            contentView.addSubview(comfirmBtn)
            comfirmBtn.setTitle(comfirmText, for: .normal)
            comfirmBtn.snp.makeConstraints { make in
                make.left.right.bottom.equalToSuperview()
                make.height.equalTo(50)
            }
        }
        contentHeight += 80
        if contentHeight > 270 {
            contentView.snp.updateConstraints { make in
                make.height.equalTo(contentHeight)
            }
        }
        
    }
    func show(in parentVC: UIViewController? = nil, animated: Bool = false) {
        self.modalPresentationStyle = .overFullScreen
        if let parentVC = parentVC {
            parentVC.present(self, animated: animated)
        } else if let window = UIApplication.shared.keyWindow,let vc = window.rootViewController {
            vc.present(self, animated: animated)
        }
    }
    
    func hidden() {
        self.dismiss(animated: false)
    }

    
    @objc func buttonClick(button: UIButton) {
        if button.tag == 10 {
            buttomClick?(true)
        } else {
            buttomClick?(false)
        }
    }

    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    

}
