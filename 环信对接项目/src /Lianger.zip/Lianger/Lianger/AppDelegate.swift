//
//  AppDelegate.swift
//  Lianger
//
//  Created by Cheng on 2023/7/4.
//

import UIKit
import IQKeyboardManagerSwift
import SwiftyUserDefaults
import MCToast
import HyphenateChat
import EaseIMKit
import MJRefresh

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {


    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        MJRefreshConfig.default.languageCode = "en"

        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.enableAutoToolbar = true
        IQKeyboardManager.shared.shouldShowToolbarPlaceholder = false
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        
        self.window = UIWindow.init(frame: UIScreen.main.bounds)
        self.window?.backgroundColor = UIColor.white
        if #available(iOS 13.0, *) {
            self.window!.overrideUserInterfaceStyle = .light
        } else {
            // Fallback on earlier versions
        }
        if let launchScreen = UIStoryboard(name: "LaunchScreen", bundle: nil).instantiateInitialViewController() {
            window?.rootViewController = launchScreen
        }
        
        if #available(iOS 15.0, *) {
            UITableView.appearance().sectionHeaderTopPadding = 0
        } else {
            // Fallback on earlier versions
        }
        UITableView.appearance().contentInsetAdjustmentBehavior = .never
        
        ///用户信息
        ApiManager.loadUserInfo() { sucess, errMsg in
            if sucess { //初始化IM
//                ApiManager.ImLogin { success, errorMsg in
//                    if sucess {
//                    }
//                }
            } else {
                Defaults.userToken = ""
            }
            self.setUpWindow()
        }
        /// 环信初始化
        initEMConfig()
                
        if Defaults.userToken.isEmpty == false {
            EaseIMHelper.shared.login()
        }
           
        return true
    }
    /// 环信初始化
    func initEMConfig() {
        EaseIMHelper.shared.initSDK()
    }
          
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        
        let deviceTokenStr = deviceToken.map { String(format: "%02.2hhx", arguments: [$0]) }.joined()
        print("deviceTokenStr:" + deviceTokenStr)
        
        DispatchQueue.main.async {
            if let error = EMClient.shared().bindDeviceToken(deviceToken) {
                print("error:" + error.errorDescription)
            } else {
                print("deviceToken 绑定成功")
            }
        }
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("deviceToken 失败成功")
    }
        
    func applicationDidEnterBackground(_ application: UIApplication) {
        EMClient.shared().applicationDidEnterBackground(application)
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        EMClient.shared().applicationWillEnterForeground(application)
    }
    
    private func setUpWindow()  {
       
        if Defaults.userToken.isEmpty {
            let maskvc = BaseNavigationController(rootViewController: LogInViewController())
            self.window?.rootViewController = maskvc
        } else {
            let maskvc = BaseTabBarController()
            self.window?.rootViewController = maskvc
        }
        self.window!.makeKeyAndVisible()
    }
    
    
    func restoreRootViewController( _ newVC:UIViewController)  {
        let animation:()->() = {
            self.window!.rootViewController = newVC
        }
        UIView.transition(with: self.window! , duration: TimeInterval(0.5) , options: UIView.AnimationOptions.transitionFlipFromTop , animations: animation, completion: nil)
    }


}


extension AppDelegate {
    func configToast() {
        // 1. 配置Toast弹出过程中的交互类型（MCToastRespond：禁止交互，导航栏下禁止交互，允许交互）
        MCToastConfig.shared.respond = MCToast.MCToastRespond.respond
        
        // 2. 配置Toast核心区域（黑色区域）
        // 颜色
        MCToastConfig.shared.background.color = UIColor.black
        // 大小
        MCToastConfig.shared.background.size = CGSize(width: 120, height: 120)
        
        
        // 3. 配置状态Toast（成功，失败，警告等状态）的Icon
        MCToastConfig.shared.icon.size = CGSize(width: 50, height: 50)
//        MCToastConfig.shared.icon.successImage = UIImage(named: "你成功状态的Icon")
//        MCToastConfig.shared.icon.failureImage = UIImage(named: "你失败状态的Icon")
//        MCToastConfig.shared.icon.warningImage = UIImage(named: "你警告状态的Icon")

        
        // 4. 配置文字
        MCToastConfig.shared.text.font = UIFont.systemFont(ofSize: 15)
        MCToastConfig.shared.text.textColor = UIColor.white
        MCToastConfig.shared.text.offset = (UIScreen.main.bounds.size.height / 2 - 120 - 150)

        
        // 5. 配置间距
        // 外边距（toast距离屏幕边的最小边距
        MCToastConfig.shared.spacing.margin = 55
        // 内边距（toast和其中的内容的最小边距）
        MCToastConfig.shared.spacing.padding = 15
        
        
        // 6. 设置自动隐藏的时长
        MCToastConfig.shared.duration = 30
    }
}
