//
//  BasePlaceholdView.swift
//  HuaHuiEmployeesProject
//
//  Created by huahui on 2021/12/15.
//

import UIKit

enum PlaceType {
    case nodata
    case noNetwork
}

class BasePlaceholdView: UIView {
    var title: String?
    
    lazy var imageView: UIImageView = {
        let imageView = UIImageView.init(image: UIImage(named: "no_network"))
        return imageView
    }()
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.grey99
        label.font = UIFont.PingFangSCMedium(size: 14)
        label.textAlignment = .center
        label.text = "The current Suburb has been offline."
        return label
    }()
//    lazy var detailLabel: UILabel = {
//        let label = UILabel()
//        label.textColor = greyTextColor
//        label.font = UIFont.PingFangSC(size: 14)
//        label.textAlignment = .center
//        label.text = "网络不给力，请检查您的网络设置"
//        return label
//    }()
//    lazy var refreshButton: UIButton = {
//        let button = UIButton.init(type: .custom)
//        button.setTitle("刷新一下", for: .normal)
//        button.setTitleColor(blackTextColor, for: .normal)
//        button.titleLabel?.font = UIFont.PingFangSC(size: 16)
//        button.layer.cornerRadius = 22
//        button.layer.masksToBounds = true
//        button.layer.borderWidth = 1
//        button.layer.borderColor = UIColor(r: 202, g: 204, b: 209, a: 0.5).cgColor
//        return button
//    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.greyF2
        setUpSubViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func setUpSubViews() {
        addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
        }
        addSubview(imageView)
        imageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(titleLabel.snp.top).offset(-44)
        }
//        addSubview(detailLabel)
//        detailLabel.snp.makeConstraints { make in
//            make.centerX.equalToSuperview()
//            make.top.equalTo(titleLabel.snp.bottom).offset(12)
//        }
//        addSubview(refreshButton)
//        refreshButton.snp.makeConstraints { make in
//            make.centerX.equalToSuperview()
//            make.width.equalTo(166)
//            make.height.equalTo(44)
//            make.top.equalTo(titleLabel.snp.bottom).offset(75)
//        }
    }
    
    func placeType(_ type: PlaceType) {
        switch type {
        case .nodata:
            imageView.image = UIImage(named: "no_data")
            titleLabel.text = self.title ?? "No content"
        case .noNetwork:
            imageView.image = UIImage(named: "no_network")
            titleLabel.text = "The current Suburb has been offline."
        }
    }

}
