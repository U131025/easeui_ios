//
//  BaseTabBarController.swift
//  Lianger
//
//  Created by Qidi on 2023/7/17.
//

import UIKit

class BaseTabBarController: UITabBarController,UITabBarControllerDelegate {

    lazy var redView: UIView = {
        let redView = UIView()
        redView.backgroundColor = .red
        redView.showCorner(4)
        return redView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tabBar.tintColor = UIColor.black
        if #available(iOS 15.0, *) {
            // 不设置的话一开始tabbar背景可能是透明的
            self.tabBar.scrollEdgeAppearance = UITabBarAppearance()
        }
        
        let homeVc = BaseNavigationController(rootViewController: HomeInfoViewController())
        homeVc.tabBarItem = UITabBarItem(title: "", image: UIImage(named: "tabbar_1_normal.png"), selectedImage: UIImage(named: "tabbar_1_seleted.png")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal))

        let postsVc = BaseNavigationController(rootViewController: PostsViewController())
        postsVc.tabBarItem = UITabBarItem(title: "", image: UIImage(named: "tabbar_2_normal.png"), selectedImage: UIImage(named: "tabbar_2_seleted.png")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal))

        let messageVc = BaseNavigationController(rootViewController: MessageViewController())
        messageVc.tabBarItem = UITabBarItem(title: "", image: UIImage(named: "tabbar_3_normal.png"), selectedImage: UIImage(named: "tabbar_3_seleted.png")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal))
        self.viewControllers = [homeVc,postsVc,messageVc]

        self.tabBar.addSubview(redView)
        let right = (ScreenWidth / 3.0) / 2.0 - 18
        
        redView.snp.makeConstraints { make in
            make.top.equalTo(6)
            make.right.equalToSuperview().offset(-right)
            make.width.height.equalTo(8)
        }
        redView.isHidden = true
    }


}
