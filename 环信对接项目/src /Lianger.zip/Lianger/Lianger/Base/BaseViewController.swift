//
//  BaseViewController.swift
//  Lianger
//
//  Created by Cheng on 2023/7/6.
//

import UIKit

class BaseViewController: UIViewController {

    lazy var placeholdView: BasePlaceholdView = {
        let placeholdView = BasePlaceholdView.init(frame: .zero)
        return placeholdView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.edgesForExtendedLayout = UIRectEdge(rawValue: 0)
        automaticallyAdjustsScrollViewInsets = false
        self.setupNaviBar()
        
        NotificationCenter.default.addObserver(self, selector: #selector(didNetworkStatusChange(_:)), name: NotiKey.didNetworkStatusChange, object: nil)

    }
    
    private func setupNaviBar() {
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        self.navigationItem.hidesBackButton = true
        if self.navigationController != nil && (self.navigationController?.viewControllers.count)! > 1 {
            let button = UIButton(type: .custom)
            button.setImage(UIImage(named: "nav_back"), for: .normal)
            button.addTarget(self, action: #selector(goBack), for: .touchUpInside)
            button.size = CGSize(width: 30, height: 30)
            let backItem = UIBarButtonItem(customView: button)
            self.navigationItem.leftBarButtonItem = backItem
        }
    }
    func showLine() {
        let lineView = UIView()
        lineView.backgroundColor = UIColor.greyE6
        self.view.addSubview(lineView)
        lineView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.height.equalTo(1)
            make.top.equalToSuperview()
        }
    }
    

    // MARK: action
    
    @objc func goBack() {
        if let navi = self.navigationController {
            navi.popViewController(animated: true)
        }else {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    func loadData() {
        
    }
    
    @objc private func didNetworkStatusChange(_ noti: Notification) {
        guard let isReachable = noti.object as? Bool else { return }
        guard isReachable else { return }
        self.showNoNetWorkPlaceholde()
    }
    
    
    func showNoNetWorkPlaceholde()  {
        placeholdView.frame = self.view.bounds
        placeholdView.placeType(.noNetwork)
        placeholdView.removeFromSuperview()
        placeholdView.isHidden = false
        self.view.addSubview(placeholdView)
    }
    func hiddenPlaceholde() {
        placeholdView.isHidden = true
        placeholdView.removeFromSuperview()
    }
    
    deinit {
        print(NSStringFromClass(self.classForCoder) + " had deinit")
        NotificationCenter.default.removeObserver(self)
    }
    

}
