//
//  BaseNavigationController.swift
//  Shop
//
//  Created by UH on 2020/9/13.
//  Copyright © 2020 Aos. All rights reserved.
//

import UIKit

class BaseNavigationController: UINavigationController ,UINavigationControllerDelegate{
    
    var isAllowedPanBackGesture: Bool = true

    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        self.basicInit()
        self.addPanBackGesture()
    }
    
    func basicInit() {
        self.navigationBar.tintColor = UIColor.black
        self.navigationBar.barTintColor = UIColor.white
        self.navigationBar.backgroundColor = UIColor.white

        if #available(iOS 15.0, *) {
            let naviAppearance = UINavigationBar.appearance().standardAppearance
            naviAppearance.backgroundColor = UIColor.white
            naviAppearance.titleTextAttributes = [
                NSAttributedString.Key.font: UIFont.PingFangSCSemibold(size: 17),
                NSAttributedString.Key.foregroundColor: UIColor.black
            ]
            self.navigationController?.navigationBar.standardAppearance = naviAppearance
            self.navigationController?.navigationBar.scrollEdgeAppearance = naviAppearance
            
        }else {
            self.navigationBar.barStyle = .default
            self.navigationBar.isTranslucent = false
            UINavigationBar.appearance().barStyle = .default
            self.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font: UIFont.PingFangSCSemibold(size: 17)]
            self.navigationBar.shadowImage = UIImage()
        }
    }
    
    func addPanBackGesture() {
        self.interactivePopGestureRecognizer?.delegate = self
//        let target = self.interactivePopGestureRecognizer?.delegate
//        let panGR = UIScreenEdgePanGestureRecognizer(target: target!, action: Selector(("handleNavigationTransition:")))
//        panGR.edges = .left
//        panGR.delegate = self
//        self.view.addGestureRecognizer(panGR)
//        self.interactivePopGestureRecognizer?.isEnabled = false
    }

    
    // MARK: UIGestureRecognizerDelegate
    
    override func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        return self.children.count > 1 && self.isAllowedPanBackGesture
    }
    
    // MARK: override
    
    override func pushViewController(_ viewController: UIViewController, animated: Bool) {
        if children.count > 0 {
            viewController.hidesBottomBarWhenPushed = true
        }
        super.pushViewController(viewController, animated: animated)
    }

    override func setViewControllers(_ viewControllers: [UIViewController], animated: Bool) {
        super.setViewControllers(viewControllers, animated: animated)
    }

}
