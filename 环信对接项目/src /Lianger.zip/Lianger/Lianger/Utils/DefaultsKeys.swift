//
//  DefaultsKeys.swift
//  Lianger
//
//  Created by Qidi on 2023/8/7.
//

import UIKit
import SwiftyUserDefaults

extension DefaultsKeys {
    
    /// 登录用户token
    var userToken: DefaultsKey<String> { .init("userToken", defaultValue: "") }
    
    var Language: DefaultsKey<String> { .init("TeachAppLanguage", defaultValue: "en") }

    var readIds: DefaultsKey<[String]> { .init("readIds", defaultValue: []) }

    
}
