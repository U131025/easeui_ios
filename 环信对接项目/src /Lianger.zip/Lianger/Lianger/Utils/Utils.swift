//
//  Utils.swift
//  Lianger
//
//  Created by Qidi on 2023/8/10.
//

import UIKit

class Utils: NSObject {
    
    static func convertNumberText(count: Int) -> String {
        
        if count < 1000 {
            return "\(count)"
        } else {
            return String(format: "%.1f", CGFloat(Double(count) / 1000.0) )
        }
    }

}
