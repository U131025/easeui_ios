//
//  NotiKey.swift
//  Lianger
//
//  Created by Qidi on 2023/8/7.
//

import UIKit

struct NotiKey {
    
    static let didNetworkStatusChange = Notification.Name(rawValue: "NotiKey.didNetworkStatusChange")


    static let didLogout = Notification.Name(rawValue: "NotiKey.didLogout")

    static let didPostArticle = Notification.Name(rawValue: "NotiKey.didPostArticle")

    static let didUserAreaChanged = Notification.Name(rawValue: "NotiKey.didUserAreaChanged")
    static let didUserAvatarChanged = Notification.Name(rawValue: "NotiKey.didUserAvatarChanged")

    static let onRecvMessages = Notification.Name(rawValue: "NotiKey.onRecvMessages")

    
}
