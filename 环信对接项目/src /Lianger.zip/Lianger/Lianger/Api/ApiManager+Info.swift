//
//  ApiManager+Info.swift
//  Lianger
//
//  Created by Qidi on 2023/8/7.
//

import UIKit
import Alamofire
import SwiftyJSON

extension ApiManager {
        
    /// 文章首页查询列表：最新
    static func loadNewArticle(params: Parameters?,handler: ListHandler<ArticleModel>?){
        ApiSession.req(stPath: ApiPath.Info.loadNew, dtPara: params,call: { json in
            let models:[ArticleModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, ArticleModel.self) as! [ArticleModel]
           handler?(models,nil)
            
        }) { error in
            handler?(nil, error?.message)
        }
        
    }
    
    /// 文章首页查询列表：更多
    static func loadMoreArticle(params: Parameters?,handler: ListHandler<ArticleModel>?){
        ApiSession.req(stPath: ApiPath.Info.loadmore, dtPara: params,call: { json in
            let models:[ArticleModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, ArticleModel.self) as! [ArticleModel]
           handler?(models,nil)
            
        }) { error in
            handler?(nil, error?.message)
        }
        
    }
    
}
