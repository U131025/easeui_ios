//
//  ApiManager.swift
//  Lianger
//
//  Created by Qidi on 2023/8/7.
//

import UIKit
import Alamofire
import SwiftyUserDefaults
import SwiftyJSON

class ApiManager: NSObject {
    
    static func startNetworkListening() {
        NetworkReachabilityManager.default?.startListening(onUpdatePerforming: { (status) in
            NotificationCenter.default.post(name: NotiKey.didNetworkStatusChange, object: ApiManager.isReachable)
        })
    }
    
    static var isReachable: Bool? {
        return NetworkReachabilityManager.default?.isReachable
    }
    
    typealias SuccessHandler = (_ success: Bool, _ errorMsg: String?)->()
    typealias ModelHandler<T> = (_ model: T?, _ errorMsg: String?)->()
    typealias ListHandler<T> = (_ list: [T]?, _ errorMsg: String?)->()

    
    
    /// 登录
    static func login(mobile: String, msgCode: String,handler: SuccessHandler?) {
        var reqData: [String: Any] = [:]
        reqData["phone"] = mobile
        reqData["smsCode"] = msgCode

        ApiSession.req(stPath: ApiPath.User.login, dtPara: reqData,call: { json in
            let token = json["data"]["access_token"].string
            if token == nil {
                handler?(false, "Login Fail")
                return
            }
            
            // 环信用户数据
            let hxUser = json["data"]["hxUser"].rawString()!.mapToModel(HXUserModel.self)
            hxUser?.save()
            
            Defaults.userToken = token!
            let model = JsonUtil.jsonToModel(json["data"]["user"].rawString()!, UserInfoModel.self) as! UserInfoModel
            model.hxUserName = hxUser?.hxUserName
            
            UserInfoModel.shared.sharedUserInfoModel(userInfoModel: model)
            
            
            
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
        
    }
    
    /// 用户注册
    static func register(params: Parameters?,handler: SuccessHandler?) {
        
        ApiSession.req(stPath: ApiPath.User.register, dtPara: params,call: { json in
            
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
        
    }
    
    /// 登出方法
    static func logout(handler: SuccessHandler?) {
        ApiSession.req(stPath: ApiPath.User.logout,methodType: .delete, dtPara: nil,call: { json in
            Defaults.userToken = ""
            UserInfoModel.shared.sharedUserInfoModel(userInfoModel: UserInfoModel())
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
    }
    
    /// 个人信息
    static func loadUserInfo(handler: SuccessHandler?) {
        
        ApiSession.req(stPath: ApiPath.User.userInfo, methodType: .get,dtPara: nil,call: { json in
            let model = JsonUtil.jsonToModel(json["data"]["user"].rawString()!, UserInfoModel.self) as! UserInfoModel
            UserInfoModel.shared.sharedUserInfoModel(userInfoModel: model)
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
        
    }
    
    /// 修改用户昵称
    static func changeUser(nickName: String,handler: SuccessHandler?) {
        var reqData: [String: Any] = [:]
        reqData["nickName"] = nickName
        ApiSession.req(stPath: ApiPath.User.nickname, methodType: .put,dtPara: reqData,call: { json in
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
        
    }
    
    /// 邮箱验证码
    static func sendemailCode(email: String,handler: SuccessHandler?) {
        var reqData: [String: Any] = [:]
        reqData["email"] = email
        ApiSession.req(stPath: ApiPath.User.emailCode, methodType: .post,dtPara: reqData,call: { json in
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
    }
    /// 修改手机号码
    static func changeUser(phone: String,code: String,handler: SuccessHandler?) {
        var reqData: [String: Any] = [:]
        reqData["phone"] = phone
        reqData["code"] = code
        ApiSession.req(stPath: ApiPath.User.phone, methodType: .put,dtPara: reqData,call: { json in
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
        
    }
    /// 修改email
    static func changeUser(email: String,code: String,handler: SuccessHandler?) {
        var reqData: [String: Any] = [:]
        reqData["email"] = email
        reqData["code"] = code
        ApiSession.req(stPath: ApiPath.User.email, methodType: .put,dtPara: reqData,call: { json in
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
        
    }
    
    
    /// 修改简介
    static func changeUser(introduction: String,handler: SuccessHandler?) {
        var reqData: [String: Any] = [:]
        reqData["introduction"] = introduction
        ApiSession.req(stPath: ApiPath.User.introduction, methodType: .put,dtPara: reqData,call: { json in
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
        
    }
    
    /// 修改用户区域
    static func changeUserArea(params: Parameters?,handler: SuccessHandler?) {
        ApiSession.req(stPath: ApiPath.User.area, methodType: .put,dtPara: params,call: { json in
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
    }
    /// 修改头像
    static func changeUser(avatar: UIImage,handler: SuccessHandler?) {
        UpLoadManager.upLoadUserAvatar(image: avatar) { sucess, msg in
            handler?(sucess,msg)
        }
    }
    
    /// 地址信息
    static func loadAreaTree(handler: ListHandler<AreaModel>?) {
        ApiSession.req(stPath: ApiPath.areaTree, methodType: .get,encoding: URLEncoding.default,dtPara: ["status" : 0],showTost: false,call: { json in
            let models:[AreaModel] = JsonUtil.jsonArrayToModel(json["data"].rawString()!, AreaModel.self) as! [AreaModel]
            handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
        
    }
    /// 查询信息分类列表
    static func getChannelList(handler: ModelHandler<ChannelModel>?) {
        ApiSession.req(stPath: ApiPath.channelList, methodType: .get,dtPara: nil,showTost: false,call: { json in
            let model:ChannelModel = JsonUtil.jsonToModel(json["data"].rawString()!, ChannelModel.self) as! ChannelModel
            handler?(model,nil)
        }) { error in
            handler?(nil, error?.message)
        }
        
    }
    
    /// 获取文章信息详细信息
    static func getArticleDetail(articleId: String, handler: ModelHandler<ArticleDetailModel>?) {
        let path = ApiPath.articleDetail + articleId
        ApiSession.req(stPath: path, methodType: .get,dtPara: nil,call: { json in
            let model:ArticleDetailModel = JsonUtil.jsonToModel(json["data"].rawString()!, ArticleDetailModel.self) as! ArticleDetailModel
            handler?(model,nil)
        }) { error in
            handler?(nil, error?.message)
        }
        
    }
    
    ///获取隐私协议详细信息
    static func getPrivacy(handler: ModelHandler<WebModel>?) {
        ApiSession.req(stPath: ApiPath.privacy, methodType: .get,dtPara: nil,showTost: false,call: { json in
            let model:WebModel = JsonUtil.jsonToModel(json["data"].rawString()!, WebModel.self) as! WebModel
            handler?(model,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    ///获取平台服务协议详细信息
    static func getPlatform(handler: ModelHandler<WebModel>?) {
        ApiSession.req(stPath: ApiPath.platform, methodType: .get,dtPara: nil,showTost: false,call: { json in
            let model:WebModel = JsonUtil.jsonToModel(json["data"].rawString()!, WebModel.self) as! WebModel
            handler?(model,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    ///获取关于我们详细信息
    static func getAbout(handler: ModelHandler<WebModel>?) {
        ApiSession.req(stPath: ApiPath.about, methodType: .get,dtPara: nil,showTost: false,call: { json in
            let model:WebModel = JsonUtil.jsonToModel(json["data"].rawString()!, WebModel.self) as! WebModel
            handler?(model,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    ///查询用户地址列表
    static func getUserAddressList(handler: ListHandler<UserAddressModel>?) {
        ApiSession.req(stPath: ApiPath.User.addressList, methodType: .get,dtPara: nil,showTost: false,call: { json in
            let models:[UserAddressModel] = JsonUtil.jsonArrayToModel(json["data"].rawString()!, UserAddressModel.self) as! [UserAddressModel]
            handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    ///获取默认地址
    static func getUserDefaultAddress(handler: ModelHandler<UserAddressModel>?) {
        ApiSession.req(stPath: ApiPath.User.defaultAddress, methodType: .get,dtPara: nil,showTost: false,call: { json in
            let model:UserAddressModel = JsonUtil.jsonToModel(json["data"].rawString()!, UserAddressModel.self) as! UserAddressModel
            handler?(model,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    /// 新增用户地址
    static func addUserAddress(params: Parameters?,handler: SuccessHandler?) {
        ApiSession.req(stPath: ApiPath.User.userAddress, methodType: .post,dtPara: params,call: { json in
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
        
    }
    /// 修改用户地址
    static func editUserAddress(params: Parameters?,handler: SuccessHandler?) {
        ApiSession.req(stPath: ApiPath.User.userAddress, methodType: .put,dtPara: params,call: { json in
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
        
    }
    /// 删除用户地址
    static func deleteUserAddress(params: Parameters?,handler: SuccessHandler?) {
        ApiSession.req(stPath: ApiPath.User.userAddress, methodType: .delete,dtPara: params,call: { json in
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
        
    }

    
    /// 根据字典类型查询字典数据信息
    static func getDicDataType(dicType: String,handler: ListHandler<DictTypeModel>?) {
        let path = ApiPath.dicDataType + dicType
        ApiSession.req(stPath: path, methodType: .get,dtPara: nil,call: { json in
            let models:[DictTypeModel] = JsonUtil.jsonArrayToModel(json["data"].rawString()!, DictTypeModel.self) as! [DictTypeModel]
            handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
        
    }
    
    ///获取用户信息
    static func getUserInfo(userId: String,handler: ModelHandler<UserModel>?) {
        let path = ApiPath.userInfo + userId
        ApiSession.req(stPath: path, methodType: .get,dtPara: nil,call: { json in
            let model:UserModel = JsonUtil.jsonToModel(json["data"].rawString()!, UserModel.self) as! UserModel
            handler?(model,nil)
        }) { error in
            handler?(nil, error?.message)
        }
        
    }
    ///短信验证码
    static func sendVerCode(phonenumber: String,handler: SuccessHandler?) {
        ApiSession.req(stPath: ApiPath.verCode, methodType: .post,dtPara: ["phonenumber" : phonenumber],call: { json in
            handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
        
    }
    ///系统消息未读数量
    static func getNoticeUnreadCount(handler: ((_ count: Int?, _ errorMsg: String?)->())?) {
        ApiSession.req(stPath: ApiPath.noticeUnread, methodType: .get,dtPara: nil,call: { json in
            let count = json["data"].int
            handler?(count,nil)
        }) { error in
            handler?(nil, error?.message)
        }
        
    }
    
}
