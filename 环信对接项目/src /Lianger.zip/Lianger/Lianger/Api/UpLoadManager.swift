//
//  UpLoadManager.swift
//  Lianger
//
//  Created by Qidi on 2023/8/9.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftyUserDefaults


class UpLoadManager: NSObject {
    
    static func upLoadUserAvatar(image: UIImage,handler:@escaping (_ status: Bool, _ imageUrl: String) -> Void){
        let url = ApiPath.baseURL + ApiPath.User.avatar
        let imgData = image.jpegData(compressionQuality: 0.5)!
        var reqHeader: HTTPHeaders = [:]
        if !Defaults.userToken.isEmpty {
            reqHeader["Authorization"] = "Bearer \(Defaults.userToken)"
        }
        Alamofire.AF.upload(multipartFormData: { multipartFormData in
            
            multipartFormData.append(imgData, withName:"avatarfile",fileName:"avatar.jpeg", mimeType: "image/jpeg")
        
        }, to: url, method: .post,headers: reqHeader).response { result in
            
            guard let data = result.value else {
                print("===================\n请求: \(url)\n)\n错误: \(result.error?.localizedDescription ?? "")\n===================")
                handler(false,result.error?.localizedDescription ?? "")
                return
            }
            let json = JSON(data as Any)
            if json.null != nil {
                handler(false,"upload fail")
            } else {
                if json["code"].int == 200 {
                    handler(true,"")
                } else {
                    handler(false,"")
                }
            }
        }
        
    }
    
    static func upLoadOss(image: UIImage,handler:@escaping (_ status: Bool, _ imageUrl: String?) -> Void){
        let url = ApiPath.baseURL + ApiPath.oss
        let imgData = image.jpegData(compressionQuality: 0.5)!
        var reqHeader: HTTPHeaders = [:]
        if !Defaults.userToken.isEmpty {
            reqHeader["Authorization"] = "Bearer \(Defaults.userToken)"
        }
        Alamofire.AF.upload(multipartFormData: { multipartFormData in
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyyMMddHHmmss"
            formatter.locale = NSLocale.system
            let time = formatter.string(from: Date())
            let fileName = time + ".jpeg"
            multipartFormData.append(imgData, withName:"file",fileName: fileName, mimeType: "image/jpeg")
        
        }, to: url, method: .post,headers: reqHeader).response { result in

            guard let data = result.value else {
                print("===================\n请求: \(url)\n)\n错误: \(result.error?.localizedDescription ?? "")\n===================")
                handler(false,result.error?.localizedDescription ?? "")
                return
            }
            let json = JSON(data as Any)
            if json.null != nil {
                handler(false,"upload fail")
            } else {
                if json["code"].int == 200 {
                    let imageUrl = json["data"]["imgUrl"].string
                    handler(true,imageUrl)
                } else {
                    let msg = json["msg"].string
                    handler(false,msg)
                }
            }
        }
        
    }
    
    
    
}



