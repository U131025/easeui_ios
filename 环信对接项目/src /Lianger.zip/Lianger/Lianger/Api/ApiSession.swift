//
//  ApiSession.swift
//  Lianger
//
//  Created by Qidi on 2023/7/7.
//

import Alamofire
import UIKit
import SwiftyJSON
import SwiftyUserDefaults
import MCToast
 
class ApiSession {
    
    static var isShowNetLog = true
    
    static func req(stPath:String, methodType:HTTPMethod = .post, encoding: ParameterEncoding = JSONEncoding.default, dtPara:[String: Any]?,showTost:Bool = true,call:@escaping (JSON)->(), errorHandler: ((_ errorMsg: ApiError?)->())?) {
        let stServer = ApiPath.baseURL + stPath

        if isShowNetLog {
            print("请求=>\(stServer)")
        }
        if showTost {
            MCToast.mc_loading()
        }
        
        func callIt(_ js:JSON ,resp:HTTPURLResponse? ) {
            if isShowNetLog {
                #if DEBUG
                    print("请求成功: \(stPath)")
                    print("参数: \(dtPara ?? ["":""])")
                    print("返回数据: \(js)")
                #endif
            }
            var error: ApiError?
            // 退出登录 和 查用户信息，
            if stPath.contains(ApiPath.User.logout) {
                error = ApiError(code: -99,message: nil)
            } else {
                error = self.basicParserResultJson(ret: js, path: stPath)
            }
            if let error = error {
                errorHandler?(error)
            }else {
                call(js)
            }
        }
        
        var reqHeader: HTTPHeaders = [:]
        if !Defaults.userToken.isEmpty {
            reqHeader["Authorization"] = "Bearer \(Defaults.userToken)"
        }
        print("请求头----",reqHeader)
        AF.request(stServer, method: methodType, parameters: dtPara, encoding: encoding, headers: reqHeader).responseJSON { response in
            if showTost{
                MCToast.mc_remove()
            }
            guard let data = response.value else {
                print("===================\n请求: \(stServer)\n参数: \(dtPara ?? ["":""])\n错误: \(response.error?.localizedDescription ?? "")\n===================")
                errorHandler?(ApiError.unknown)
                return
            }
            let json = JSON(data)
            if json.null != nil {
                print("===================\n请求: \(stServer)\n参数: \(dtPara ?? ["":""])\n错误: json转换失败\n===================")
                errorHandler?(ApiError.analysisFail)
            }else {
                callIt(json, resp: response.response)
            }
        }
    }
    
    /// 防止重复出现踢出弹窗
    static var isRequiredAlertShowed: Bool = false
    
    /// 返回数据基础处理
    static func basicParserResultJson(ret:JSON?, path: String?) -> ApiError? {
        guard let code = ret?["code"].int else {
         
            return ApiError.unknown
        }
        if code == 200 || code == 0 { return nil }
        let errorMsg = ret?["msg"].string
        if code == 401 {
            // -1: 登录过期
            Defaults.userToken = ""
            ApiSession.dealWithInvalidToken(ApiError(code: code, message: errorMsg))
        }
        return ApiError(code: code, message: errorMsg ?? ApiError.unknown.message)
        
    }
    
    static func dealWithInvalidToken(_ error: ApiError) {

        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate, let popVC = appDelegate.window?.rootViewController else { return }
        guard ApiSession.isRequiredAlertShowed == false else { return }
        ApiSession.isRequiredAlertShowed = true
       
        NotificationCenter.default.post(name: NotiKey.didLogout, object: nil)
        appDelegate.restoreRootViewController(UINavigationController.init(rootViewController: LogInViewController()))
        ApiSession.isRequiredAlertShowed = false
    }
    
}

