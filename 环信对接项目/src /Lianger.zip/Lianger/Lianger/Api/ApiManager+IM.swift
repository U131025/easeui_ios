//
//  ApiManager+IM.swift
//  Lianger
//
//  Created by Qidi on 2023/8/23.
//

import UIKit
import Alamofire
import SwiftyJSON

extension ApiManager {
    
    
    ///IM登录
    static func ImLogin(handler: SuccessHandler?){
        ApiSession.req(stPath: ApiPath.IM.login, dtPara: nil,call: { json in
           handler?(true,nil)

        }) { error in
            handler?(false, error?.message)
        }
        
    }
    
    ///IM同步最近会话
    static func getMessageConversation(params: Parameters?,handler: ListHandler<MessageModel>?){
        ApiSession.req(stPath: ApiPath.IM.conversation, dtPara: params,call: { json in
            let models:[MessageModel] = JsonUtil.jsonArrayToModel(json["data"].rawString()!, MessageModel.self) as! [MessageModel]
            handler?(models,nil)

        }) { error in
            handler?(nil, error?.message)
        }
        
    }
    
    ///获取某频道消息
    static func getMessagesync(params: Parameters?,handler: ListHandler<ChatMessageModel>?){
        ApiSession.req(stPath: ApiPath.IM.messagesync, dtPara: params,call: { json in
            let models:[ChatMessageModel] = JsonUtil.jsonArrayToModel(json["data"]["messages"].rawString()!, ChatMessageModel.self) as! [ChatMessageModel]
            handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
        
    }
   
    ///获取某频道消息
    static func getChannelMessagesync(params: Parameters?,handler: ModelHandler<ChannelMessageModel>?){
        ApiSession.req(stPath: ApiPath.IM.messagesync, dtPara: params,call: { json in
            let model: ChannelMessageModel = JsonUtil.jsonToModel(json["data"].rawString()!, ChannelMessageModel.self) as! ChannelMessageModel
            handler?(model,nil)
        }) { error in
            handler?(nil, error?.message)
        }
        
    }
    
}

