//
//  ChatInfo.swift
//  Lianger
//
//  Created by Qidi on 2023/8/30.
//

import UIKit

class ChatInfo: NSObject {
    ///服务器的IP
    static let ip = "3.104.87.77"
    ///端口
    static let port:UInt16 = 5100

    
}
