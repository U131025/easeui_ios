//
//  ApiError.swift
//  Lianger
//
//  Created by Qidi on 2023/7/7.
//

import UIKit

struct ApiError {
    var code: Int
    var message: String?
}

extension ApiError {
    
    static let getTokenFailure = ApiError(code: 400001, message: "获取token失败")
    static let invalidToken = ApiError(code: 400002, message: "登录过期")

    /// 无网络
    static let noNetwork = ApiError(code: -999, message: "无网络")
    /// 未知错误
    static let unknown = ApiError(code: -99999, message: "连接失败，请稍后再试")
    /// 解析失败
    static let analysisFail = ApiError(code: -99998, message: "数据格式出错")
    
}
