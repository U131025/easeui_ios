//
//  ApiManager+Post.swift
//  Lianger
//
//  Created by Qidi on 2023/8/9.
//

import UIKit
import Alamofire
import SwiftyJSON

extension ApiManager {
    
    ///新增文章信息
    static func addNewArticle(params: Parameters?,handler: SuccessHandler?){
        ApiSession.req(stPath: ApiPath.post.newsArticle, dtPara: params,call: { json in
           handler?(true,nil)

        }) { error in
            handler?(false, error?.message)
        }
        
    }
    
    ///查询用户发布文章信息列表：最新
    static func getNewsArticleList(params: Parameters?,handler: ListHandler<ArticleModel>?){
        ApiSession.req(stPath: ApiPath.post.loadnew, dtPara: params,call: { json in
            let models:[ArticleModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, ArticleModel.self) as! [ArticleModel]
           handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
        
    }
    ///查询用户发布文章信息列表：更多
    static func getMoreNewsArticleList(params: Parameters?,handler: ListHandler<ArticleModel>?){
        ApiSession.req(stPath: ApiPath.post.loadmore, dtPara: params,call: { json in
            let models:[ArticleModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, ArticleModel.self) as! [ArticleModel]
           handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
        
    }
    ///删除文章
    static func deleteArticle(articleId: String,handler: SuccessHandler?){
        let path =  ApiPath.post.delete + articleId
        ApiSession.req(stPath:path ,methodType: .delete, dtPara: nil,call: { json in
           handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
        
    }
    
    ///查询关注的用户发表的文章列表：最新
    static func getNewsFollowArticleList(params: Parameters?,handler: ListHandler<ArticleModel>?){
        ApiSession.req(stPath: ApiPath.post.followLoadnew, dtPara: params,call: { json in
            let models:[ArticleModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, ArticleModel.self) as! [ArticleModel]
           handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    ///查询关注的用户发表的文章列表：更多
    static func getMoreFollowNewsArticleList(params: Parameters?,handler: ListHandler<ArticleModel>?){
        ApiSession.req(stPath: ApiPath.post.followLoadmore, dtPara: params,call: { json in
            let models:[ArticleModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, ArticleModel.self) as! [ArticleModel]
           handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    ///关注/取消关注用户
    static func followUser(userId: String,handler: SuccessHandler?){
        ApiSession.req(stPath: ApiPath.post.followUser, dtPara: ["userId" : userId],call: { json in
           handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
    }
    
    ///查询用户收藏文章信息列表：最新
    static func getNewsCollectionArticleList(params: Parameters?,handler: ListHandler<ArticleModel>?){
        ApiSession.req(stPath: ApiPath.post.collectionLoadnew, dtPara: params,call: { json in
            let models:[ArticleModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, ArticleModel.self) as! [ArticleModel]
           handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    ///查询用户收藏文章信息列表：更多
    static func getMoreCollectionArticleList(params: Parameters?,handler: ListHandler<ArticleModel>?){
        ApiSession.req(stPath: ApiPath.post.collectionLoadmore, dtPara: params,call: { json in
            let models:[ArticleModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, ArticleModel.self) as! [ArticleModel]
           handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    ///文章收藏/取消收藏
    static func collectionArticle(articleId: String,handler: SuccessHandler?){
        ApiSession.req(stPath: ApiPath.post.collectionArticle, dtPara: ["articleId" : articleId],call: { json in
           handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
    }
    
    ///查询文章评论总数
    static func getArticleCommentCount(articleId: String,handler: ((Int, String?)->())?){
        let path = ApiPath.post.articleCommentCount + articleId
        ApiSession.req(stPath: path,methodType: .get, dtPara: nil,showTost: false,call: { json in
            let count = json["data"].int ?? 0
            handler?(count,nil)
        }) { error in
            handler?(0, error?.message)
        }
    }
    
    ///查询文章评论列表：更多
    static func getArticleCommentLoadmore(params: Parameters?,handler: ListHandler<ArticleCommentModel>?){
        ApiSession.req(stPath: ApiPath.post.articleCommentLoadmore, dtPara: params,call: { json in
            let models:[ArticleCommentModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, ArticleCommentModel.self) as! [ArticleCommentModel]
           handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    ///新增文章评论
    static func addArticleComment(params: Parameters?,handler: SuccessHandler?){
        ApiSession.req(stPath: ApiPath.post.articleAddComment, dtPara: params,call: { json in
           handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
    }
    
    
    ///查询意见反馈列表：最新
    static func getNewsFeedbackList(params: Parameters?,handler: ListHandler<FeedBackModel>?){
        ApiSession.req(stPath: ApiPath.post.feedbackLoadnew, dtPara: params,call: { json in
            let models:[FeedBackModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, FeedBackModel.self) as! [FeedBackModel]
           handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    ///查询意见反馈列表：更多
    static func getFeedbackLoadmore(params: Parameters?,handler: ListHandler<FeedBackModel>?){
        ApiSession.req(stPath: ApiPath.post.feedbackLoadmore, dtPara: params,call: { json in
            let models:[FeedBackModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, FeedBackModel.self) as! [FeedBackModel]
            handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    ///新增意见反馈
    static func addFeedback(params: Parameters?,handler: SuccessHandler?){
        ApiSession.req(stPath: ApiPath.post.addFeedback, dtPara: params,call: { json in
           handler?(true,nil)
        }) { error in
            handler?(false, error?.message)
        }
    }
    
    
    ///系统公告列表：最新
    static func getNewNoticeList(params: Parameters?,handler: ListHandler<NoticeModel>?){
        ApiSession.req(stPath: ApiPath.post.noticeLoadnew, dtPara: params,call: { json in
            let models:[NoticeModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, NoticeModel.self) as! [NoticeModel]
           handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }

    ///系统公告列表：更多
    static func getNoticeLoadmore(params: Parameters?,handler: ListHandler<NoticeModel>?){
        ApiSession.req(stPath: ApiPath.post.noticeLoadmore, dtPara: params,call: { json in
            let models:[NoticeModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, NoticeModel.self) as! [NoticeModel]
            handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    ///系统公告详细信息
    static func getNoticeInfo(noticeId: String,handler: ModelHandler<NoticeInfoModel>?){
        let path = ApiPath.post.noticeInfo + noticeId
        ApiSession.req(stPath: path,methodType: .get, dtPara: nil,call: { json in
            let model: NoticeInfoModel = JsonUtil.jsonToModel(json["data"].rawString()!, NoticeInfoModel.self) as! NoticeInfoModel
            handler?(model,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    ///新增公告收货地址
    static func addNoticeAddress(params: Parameters?,handler: SuccessHandler?){
        ApiSession.req(stPath: ApiPath.post.addAddress, dtPara: params,call: { json in
            let msg = json["msg"].string
            handler?(true,msg)
        }) { error in
            handler?(false, error?.message)
        }
    }
    
    ///获取公告收货地址详细信息
    static func getNoticeAddressData(addressId: String,handler: ModelHandler<UserAddressModel>?){
        let path = ApiPath.post.addAddress + "/" + addressId
        ApiSession.req(stPath: path,methodType: .get, dtPara: nil,call: { json in
            let model: UserAddressModel = JsonUtil.jsonToModel(json["data"].rawString()!, UserAddressModel.self) as! UserAddressModel
            handler?(model,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    
    ///查询自定义栏目列表
    static func getColumnList(handler: ListHandler<ColumnModel>?){
        ApiSession.req(stPath: ApiPath.post.columnList,methodType: .get, dtPara: nil,call: { json in
            let models:[ColumnModel] = JsonUtil.jsonArrayToModel(json["data"].rawString()!, ColumnModel.self) as! [ColumnModel]
            handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    ///获取栏目资讯详细信息
    static func getColumnNews(newsId: String,handler: ModelHandler<ColumnListModel>?){
        ApiSession.req(stPath: ApiPath.post.columnNews + newsId,methodType: .get, dtPara: nil,call: { json in
            let model: ColumnListModel = JsonUtil.jsonToModel(json["data"].rawString()!, ColumnListModel.self) as! ColumnListModel
            handler?(model,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    ///查询栏目资讯列表：最新
    static func getNewColumnList(params: Parameters?,handler: ListHandler<ColumnListModel>?){
        ApiSession.req(stPath: ApiPath.post.columnLoadnew, dtPara: params,call: { json in
            let models:[ColumnListModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, ColumnListModel.self) as! [ColumnListModel]
           handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }

    ///查询栏目资讯列表：更多
    static func getColumnLoadmore(params: Parameters?,handler: ListHandler<ColumnListModel>?){
        ApiSession.req(stPath: ApiPath.post.columnLoadmore, dtPara: params,call: { json in
            let models:[ColumnListModel] = JsonUtil.jsonArrayToModel(json["rows"].rawString()!, ColumnListModel.self) as! [ColumnListModel]
            handler?(models,nil)
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
}
