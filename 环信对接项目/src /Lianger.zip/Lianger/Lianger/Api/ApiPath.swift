//
//  ApiPath.swift
//  Lianger
//
//  Created by Qidi on 2023/7/7.
//

import UIKit

class ApiPath: NSObject {
    
#if DEBUG

    static let baseURL = "http://3.104.87.77/prod-api"

    static let H5Url = "http://mobile.dev.huahuihr.com"


#else
    
    static let baseURL = "http://3.104.87.77/prod-api"
    static let H5Url = "https://m-hr.mingzhongdata.com"

#endif
    
    //地址信息
    static let areaTree = "/news/area/tree"
    //查询信息分类列表
    static let channelList = "/news/channel/list"
    ///获取文章信息详细信息
    static let articleDetail = "/news/article/"
    ///获取用户信息
    static let userInfo = "/news/user/"

    ///图片上传
    static let oss = "/news/file/image"
    
    ///获取隐私协议详细信息
    static let privacy = "/news/about/privacy"
    ///获取平台服务协议详细信息
    static let platform = "/news/about/platform"
    ///获取关于我们详细信息
    static let about = "/news/about/about"
    
    ///根据字典类型查询字典数据信息
    static let dicDataType = "/system/dict/data/type/"
    
    ///短信验证码
    static let verCode = "/resource/app/sms/code"
    ///系统消息未读数量
    static let noticeUnread = "/news/notice/unread"
    
    
    struct User {
        ///登录
        static let login = "/user/login"
        ///用户注册
        static let register = "/user/register"
        ///登出方法
        static let logout = "/user/logout"        
        ///用户信息
        static let userInfo = "/news/user/profile"
        ///修改 用户昵称
        static let nickname = "/news/user/profile/nickname"
        ///修改 用户简介
        static let introduction = "/news/user/profile/introduction"
        ///修改用户区域
        static let area = "/news/user/profile/area"
        ///修改 用户头像
        static let avatar = "/news/user/profile/avatar"
        ///邮箱验证码
        static let emailCode = "/resource/app/email/code"
        ///修改email
        static let email = "/news/user/profile/email"
        ///修改手机号码
        static let phone = "/news/user/profile/phone"
        
        ///查询用户地址列表
        static let addressList = "/news/address/list"
        ///新增用户地址 修改用户地址 删除用户地址
        static let userAddress = "/news/address"
       
        ///获取默认地址
        static let defaultAddress = "/news/address/default"
        
    }
    
    
    struct Info {
        static let loadNew = "/news/article/home/loadnew"
        static let loadmore = "/news/article/home/loadmore"

    }
    
    struct post {
        ///新增文章信息
        static let newsArticle = "/news/article"
        ///查询用户发布文章信息列表：最新
        static let loadnew = "/news/article/list/loadnew"
        ///查询用户发布文章信息列表：更多
        static let loadmore = "/news/article/list/loadmore"
        ///删除文章信息
        static let delete = "/news/article/"

        ///查询关注的用户发表的文章列表：最新
        static let followLoadnew = "/news/user/follow/list/loadnew"
        ///查询关注的用户发表的文章列表：更多
        static let followLoadmore = "/news/user/follow/list/loadmore"
        ///关注/取消关注用户
        static let followUser = "/news/user/follow"
        
        
        ///查询用户收藏文章信息列表：最新
        static let collectionLoadnew = "/news/article/collection/list/loadnew"
        ///查询用户收藏文章信息列表：更多
        static let collectionLoadmore = "/news/article/collection/list/loadmore"
        ///文章收藏/取消收藏
        static let collectionArticle = "/news/article/collection"
        
        ///查询文章评论总数
        static let articleCommentCount = "/news/article/comment/"
        ///查询文章评论列表：更多
        static let articleCommentLoadmore = "/news/article/comment/list/loadmore"
        ///新增文章评论
        static let articleAddComment = "/news/article/comment"
        
        
        ///查询意见反馈列表：最新
        static let feedbackLoadnew = "/news/feedback/list/loadnew"
        ///查询意见反馈列表：更多
        static let feedbackLoadmore = "/news/feedback/list/loadmore"
        ///新增意见反馈
        static let addFeedback = "/news/feedback"
        
        
        ///系统公告列表：最新
        static let noticeLoadnew = "/news/notice/list/loadnew"
        ///系统公告列表：更多
        static let noticeLoadmore = "/news/notice/list/loadmore"
        ///系统公告详细信息
        static let noticeInfo = "/news/notice/"
        ///新增公告收货地址
        static let addAddress = "/news/notice/dddress"
        
        ///查询自定义栏目列表
        static let columnList = "/news/column/list"
        ///获取栏目资讯详细信息
        static let columnNews = "/news/column/news/"
        ///查询栏目资讯列表：最新
        static let columnLoadnew = "/news/column/news/list/loadnew"
        ///查询栏目资讯列表：更多
        static let columnLoadmore = "/news/column/news/list/loadmore"
    }
    
    struct IM {
        ///IM登录
        static let login = "/news/wkim/login"
        ///IM同步最近会话
        static let conversation = "/news/wkim/conversation/sync"
        ///获取某频道消息
        static let messagesync = "/news/wkim/channel/messagesync"
        
    }
    
    

}
