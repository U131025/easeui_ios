//
//  ApiManager+Search.swift
//  Lianger
//
//  Created by 屋联-神兽 on 2023/9/21.
//

import Foundation
import Alamofire
import SwiftyJSON

extension ApiManager {
    
    static func searchUser(params: Parameters?, handler: ModelHandler<PageRespondModel<ArticleCommentModel>>?) {
        
        ApiSession.req(stPath: ApiPath.Search.user, dtPara: params,call: { json in
            
            if let model = json.rawString()!.mapToModel(RespondModel<PageRespondModel<ArticleCommentModel>>.self) {
                if let data = model.data {
                    handler?(data, nil)
                } else {
                    handler?(nil, model.msg)
                }
            }
            
        }) { error in
            handler?(nil, error?.message)
        }
    }
    
    static func searchArticle(params: Parameters?, handler: ModelHandler<PageRespondModel<ArticleModel>>?) {
        
        ApiSession.req(stPath: ApiPath.Search.article, dtPara: params,call: { json in
            
            if let model = json.rawString()!.mapToModel(RespondModel<PageRespondModel<ArticleModel>>.self) {
                if let data = model.data {
                    handler?(data, nil)
                } else {
                    handler?(nil, model.msg)
                }
            }
            
        }) { error in
            handler?(nil, error?.message)
        }
    }
}
